# Gaslager Cross‑Platform

Gaslager ist eine eigenständig betreibbare Lagerverwaltung für Original-Ersatzteile von RMG-/Honeywell-Gasdruckreglern und Piloten. Das Paket enthält:

- eine responsive Weboberfläche für Windows, Android und iPhone/iPad,
- einen zentralen FastAPI-Server mit PostgreSQL,
- eine native Android-App mit Kamera-Barcode-Scanner,
- die bereits erstellte native iPhone-/iPad-App mit lokaler Offline-Datenbank,
- ein wiederholt ausführbares Ubuntu-Installationsskript mit Sicherung vor Updates,
- tägliche automatische Backups,
- CSV-Import und -Export für die Barcode-Stammliste sowie prüfbaren CSV-/XLSX-Import der Mehrfachverwendung.

SAP und IH2Go sind in der ausgelieferten Konfiguration deaktiviert. Ein- und Ausgänge, Aufträge, Bestände, Schubladen, Barcodes, Mindestbestände und Dokumente funktionieren ohne Fremdsystem.

Weboberfläche und Android-App greifen auf denselben Ubuntu-Serverbestand zu. Die
native iOS-App unter `ios/` arbeitet in dieser Version bewusst lokal/offline;
für direkten Zugriff auf den zentralen Bestand kann die Weboberfläche auch auf
dem iPhone/iPad verwendet werden. Eine spätere native iOS-Serversynchronisierung
bleibt dadurch eine klar getrennte Erweiterung.

## Schnellinstallation auf Ubuntu Server

Voraussetzungen: Ubuntu Server 22.04/24.04/26.04, Internetzugang während der ersten Installation, mindestens 4 GB RAM und ausreichend freier Speicher für Handbücher und Backups.

1. ZIP auf den Ubuntu-Server kopieren und entpacken.
2. Im entpackten Ordner ausführen:

   ```bash
   sudo bash deploy/install-ubuntu.sh --plan
   sudo bash deploy/install-ubuntu.sh
   ```

3. Das Skript installiert Docker Engine und Docker Compose, erzeugt sichere Zufallskennwörter, startet alle Dienste, richtet Autostart sowie Backups ein und zeigt die Webadresse an.
4. Unter Windows die ausgegebene Adresse, zum Beispiel `http://192.168.1.50:8080`, in Edge, Chrome oder Firefox öffnen.
5. Die einmalig erzeugten Zugangsdaten stehen zusätzlich nur für `root` lesbar in `/root/gaslager-zugang.txt`.

Das Skript kann für Updates erneut ausgeführt werden. Datenbank, PDFs und `.env` bleiben dabei erhalten.
Bei einer neuen PC-Installation liegen Datenbank, PDFs, Backups und Exporte unter `/srv/gaslager` (oder unter dem gewählten Datenpfad). Ein Upgrade einer früheren Installation belässt deren Docker-Volumes unverändert.

## Funktionsumfang

- Ein- und Ausgang per Originalbarcode, manueller Eingabe oder Teileauswahl
- Android-Kamerascan für Code 128/39/93, Codabar, EAN, ITF, UPC, QR, Data Matrix, PDF417 und Aztec
- mehrere Originalbarcodes pro Ersatzteil
- Etikettenvorschau und Druck für bestätigte Barcodearten und Rohwerte
- getrennte Felder für Hersteller-Artikelnummer und gerätespezifische Ersatzteilnummer
- ein Ersatzteil kann mehreren Reglern/Piloten zugeordnet sein
- jede Schublade gehört genau zu einem Regler- oder Pilottyp
- 66 vorbelegte öffentlich belegte Regler- und Pilottypen (42 Regler, 24 Piloten)
- 71 vorbelegte offizielle Herstellerlinks, darunter vier direkte Broschüren
- individuelle Mindestbestände und je Artikel aktivierbare Warnung
- lokale Android-Benachrichtigung nach einer Buchung auf/unter den Grenzwert
- Android-Offlinemodus für Bestand, Barcode-Suche, Aufträge und Buchungen
- manueller Synchronisationsbutton mit Warteschlange und Schutz vor Doppelbuchungen
- optionaler Android-Servermodus mit eingebetteter Weboberfläche und SQLite-Datenbank
- Betrieb über den Handy-Hotspot ohne Internetverbindung; Windows- und Android-Geräte greifen per Browser zu
- RMG-Mehrfachverwendungsliste aus allen freigegebenen Regler-/Pilotzuordnungen
- zentrale Warnliste im Web-Dashboard
- Standalone-Aufträge mit Kunde, Equipmentnummer, Technischem Platz und Gerätetyp
- passende Ersatzteilliste je Auftragsgerät
- Sperre bei Entnahme eines nicht zum Auftragsgerät zugeordneten Teils
- Schutz vor negativen Beständen und doppelt vergebenen Barcodes
- PDF-Ablage und offizielle Herstellerlinks je Gerätetyp
- Upload von Handbüchern und PDF-Mehrfachverwendungslisten in der Weboberfläche
- CSV-/XLSX-Import von Mehrfachverwendungs-Zuordnungen mit Vorschau, Fehlerbericht und expliziter Bestätigung
- vollständiger CSV-Export einschließlich Barcodes, Zuordnungen und Bestand

## Wichtig zu Originalbarcodes

Die Anwendung erfindet keine Herstellerdaten. Eine Artikel- oder Ersatzteilnummer lässt sich nicht zuverlässig durch einen allgemeinen Algorithmus in den „richtigen Originalbarcode“ umwandeln. Ein Beispiel kann Barcodeart und Prüfziffernlogik erkennen helfen, beweist aber nicht, welche Nutzdaten Honeywell/RMG für andere Teile codiert.

Der sichere Ablauf ist:

1. Barcode auf Originalverpackung oder freigegebener Herstellerliste scannen.
2. Rohwert, Barcodeart, Original-Artikelnummer und gerätespezifische Ersatzteilnummer zusammen speichern.
3. Etiketten nur aus diesem belegten Rohwert nachbilden.
4. Vor produktiver Verwendung Scan gegen das Original testen.

Für einen gespeicherten Barcode zeigt die Ersatzteilansicht eine Vorschau und
die Schaltfläche **Etikett drucken**, sobald eine unterstützte Barcodeart
hinterlegt ist. Unterstützt werden Code 128/39/93, GS1-128, EAN-13/-8, UPC-A/-E,
ITF/ITF-14, Codabar, QR, GS1-QR, Data Matrix, GS1 Data Matrix, PDF417 und Aztec.

Die leere [Barcode-Stammliste](templates/RMG_Honeywell_Barcode-Stammliste.csv) kann in Excel bearbeitet und in der Weboberfläche unter **Einstellungen** importiert werden. Der Export aus der Weboberfläche ist zugleich die aktuelle Barcode-Liste des gesamten Lagers.

Zusätzlich enthält `templates/RMG_Honeywell_Barcode-Stammliste_SAP.xlsx` eine
formatierte Excel-Arbeitsmappe mit Eingabezeilen, Auswahllisten, Prüfübersicht
und den optionalen SAP-Feldern. Die Referenzliste aller 66 vorbelegten
Gerätetypen liegt in `templates/RMG_Honeywell_Geraetetypen.csv`.

## Android-App

Das Android-Studio-Projekt liegt in `android/`. Voraussetzungen: Android Studio mit JDK 17 und Android SDK 36.

1. Ordner `android` in Android Studio öffnen.
2. Gradle-Synchronisierung abwarten.
3. **Build → Build APK(s)** wählen oder im Terminal `gradlew.bat assembleDebug` unter Windows ausführen.
4. Die erzeugte APK aus `android/app/build/outputs/apk/debug/` auf dem Gerät installieren.
5. Entweder die vom Ubuntu-Installer ausgegebene Serveradresse eintragen oder **Dieses Handy als Server** wählen.

Das Android-Gerät muss den Ubuntu-Server im selben LAN/VPN erreichen können. Für Internetzugriff muss vorab HTTPS eingerichtet werden.

Nach der ersten erfolgreichen Synchronisierung arbeitet die Android-App auch ohne Verbindung weiter. Offline erfasste Ein- und Ausgänge werden lokal vorgemerkt und mit **Sync** übertragen. Unter **Teile → Mehrfachverwendung** werden ausschließlich Ersatzteile mit mindestens zwei hinterlegten, freigegebenen Regler-/Pilotzuordnungen angezeigt.

### Android als eigenständiger Hotspot-Server

Ab Version 1.2 kann das Android-Gerät den vollständigen Lagerbetrieb selbst übernehmen. Dazu in der Anmeldung **Dieses Handy als Server** wählen, über die angebotene Schaltfläche den Android-Hotspot einschalten und anschließend die in den Servereinstellungen angezeigte Adresse auf den verbundenen Geräten öffnen. Benutzer ist `admin`; der zufällig erzeugte sechsstellige Zugangscode wird ausschließlich in der App angezeigt.

Mobilfunkdaten und eine WLAN-Internetverbindung dürfen ausgeschaltet bleiben. Katalog, Barcodes, Bestände, Buchungen, Mindestbestände, Schubladen, Aufträge, Regler-/Pilotzuordnungen, Mehrfachverwendungsliste, Sicherung und Weboberfläche liegen lokal auf dem Handy. Nur externe Hersteller-Webseiten benötigen Internet; die lokale Lagerfunktion nicht. Details stehen in [Android-Servermodus](android/SERVERMODUS.md).

## Verwaltung und Betrieb

```bash
# Zustand
cd /opt/gaslager && sudo docker compose ps

# Protokolle
cd /opt/gaslager && sudo docker compose logs --tail=200

# Neustart
sudo systemctl restart gaslager

# Backup sofort ausführen
sudo systemctl start gaslager-backup.service
```

Automatische Backups werden täglich gegen 02:30 Uhr unter `/srv/gaslager/backups` abgelegt; alte Sicherungen werden nicht automatisch gelöscht. Details zu Upload, Wiederherstellung, Netzwerk und Updates stehen in [Installation und Betrieb](docs/INSTALLATION.md).

## Herstellerunterlagen

Die Ersteinrichtung verknüpft jeden Katalogtyp mit einer offiziellen Honeywell-Produktübersicht bzw. dem deutschen Dokumentarchiv. Für HON 402, HON 503, HON 630 und HON 650 werden zusätzlich direkte Broschürenlinks angelegt. Eigene freigegebene PDFs lassen sich über die Weboberfläche hochladen und anschließend auch in Android öffnen.

Unter **Unterlagen** lassen sich PDFs je Regler oder Pilot hochladen. Eine Herstellerliste als PDF dient dort der Archivierung; für auswählbare Mehrfachverwendung unter **Einstellungen → Mehrfachverwendung hochladen** die CSV-/Excel-Datei erst prüfen und dann übernehmen. Eine originale Herstellerliste wird nicht im Paket mitgeliefert und keine Zuordnung ohne belegte Daten erfunden.

Offizielle Startpunkte:

- [Honeywell Regler und Sicherheitseinrichtungen](https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories)
- [Honeywell Piloten](https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories/pilot-for-gas-pressure-regulators)
- [Honeywell Original-Ersatzteile](https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories/regulators-and-safety-accessories-spare-parts/spare-parts-regulators-and-safety-accessories)
- [Honeywell Gas Technologies Dokumentarchiv](https://www.hongastec.de/service/download-dokumente)

Herstellerunterlagen können sich ändern. Original-Artikelnummer, Ausführung, Nennweite, Baujahr und Fabriknummer müssen mit Typenschild und freigegebener Stückliste abgeglichen werden.

## Optionale SAP-/IH2Go-Vorbereitung

Die neutrale Bridge ist bereits unter `/api/gaslager/v1/` vorbereitet; sie löst im Standalone-Modus keine externe Synchronisierung aus. Die produktive Anbindung erfordert die kundenspezifische IH2Go-/SAP-Schnittstellendokumentation, Systemadressen, Authentifizierung, Werk/Lagerort, Bewegungsarten und fachliche Abnahme. Siehe [optionale Integration](docs/SAP_IH2GO_OPTIONAL.md).

## Technischer Aufbau

- `server/`: FastAPI, SQLAlchemy, PostgreSQL/SQLite-kompatibles Datenmodell
- `app/`, `components/`: Next.js-Weboberfläche
- `android/`: Kotlin, Jetpack Compose, CameraX und ML Kit
- `ios/`: SwiftUI-/SwiftData-App für den lokalen Offline-Betrieb
- `deploy/`: Ubuntu-Installer, Nginx, systemd und Backup
- `templates/`: CSV-Vorlagen

Die Web-API-Dokumentation ist nach der Installation unter `/api/docs` erreichbar.

## Sicherheit

- Der Installer generiert Datenbank-, JWT- und Admin-Zugangsdaten zufällig.
- Die API ist ohne Anmeldung nur am Health-Endpunkt erreichbar.
- PDFs werden als PDF geprüft und größenbegrenzt gespeichert.
- HTTP ist ausschließlich für ein vertrauenswürdiges lokales Netz vorgesehen.
- Für standortübergreifenden oder öffentlichen Zugriff: VPN oder Reverse Proxy mit gültigem HTTPS-Zertifikat verwenden.
- `.env`, Backups und `/root/gaslager-zugang.txt` nicht per E-Mail oder Chat weitergeben.
