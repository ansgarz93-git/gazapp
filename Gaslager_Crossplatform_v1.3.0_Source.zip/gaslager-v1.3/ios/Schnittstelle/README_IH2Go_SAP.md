# IH2Go-/SAP-Anbindung von Gaslager

## Zielbild

Gaslager übernimmt offene IH2Go-/SAP-Aufträge. Jeder Auftrag enthält Kunde,
technisches Objekt (Equipment bzw. Technischer Platz) und den konkreten
RMG-/Honeywell-Regler- oder Pilottyp. Die App filtert den lokalen Teilekatalog
über die gerätespezifischen Ersatzteilzuordnungen. Nicht kompatible Barcodes
werden bei einer auftragsbezogenen Entnahme blockiert.

Eine Entnahme erzeugt sofort eine lokale, unveränderlich referenzierte Buchung
und anschließend einen Eintrag in der Offline-Warteschlange. Die Middleware
bestätigt die Verarbeitung mit einer SAP-Materialbelegnummer. Die
`idempotency_key` muss serverseitig eindeutig behandelt werden, damit ein Retry
keine Doppelbuchung erzeugt.

## Betriebsarten

1. **Live:** Die kundenspezifische Middleware implementiert
   `IH2Go_Gaslager_OpenAPI.yaml`. Basis-URL, Pfade, Mandant, Werk, Lagerort und
   Bewegungsarten werden in der App konfiguriert. Das Bearer-Token liegt nur im
   iOS-Schlüsselbund.
2. **Dateiaustausch:** Aufträge werden als JSON im selben Schema importiert;
   Buchungen werden als CSV exportiert. Das ist ohne Serverentwicklung sofort
   testbar.

## Empfohlene Feldzuordnung

| Gaslager | IH2Go/SAP-Bedeutung |
| --- | --- |
| `order_number` | Instandhaltungs-/Serviceauftrag |
| `customer_number` | Kundennummer bzw. Business Partner |
| `equipment_number` | Technisches Objekt/Equipment |
| `functional_location` | Technischer Platz |
| `equipment_type` | Exakte lokale Regler-/Pilotbezeichnung |
| `material_number` | SAP-Materialnummer des Originalersatzteils |
| `plant` | Werk |
| `storage_location` | Lagerort |
| `material_document` | Rückgemeldeter SAP-Materialbeleg |

## Vor dem Produktivbetrieb verbindlich klären

- eingesetzte IH2Go-Version und von Convista freigegebener Integrationsweg;
- SAP ECC oder S/4HANA sowie freigegebene API/BAPI-/OData-Services;
- Zuordnung Auftrag → Kunde → Equipment/Technischer Platz → Reglertyp;
- SAP-Materialnummer je Originalartikel und Mengeneinheit;
- Werk, Lagerort und erlaubte Bewegungsarten für Ein- und Ausgang;
- Berechtigung, CSRF-/OAuth-Verfahren, VPN und Zertifikatskette;
- fachliche Behandlung von Storno, Rückgabe, Charge und Seriennummer;
- ob der SAP-Bestand oder der mobile Bestand führend ist.

Die Beispielwerte in `IH2Go_Auftraege_Beispiel.json` sind deutlich mit
`DEMO-` gekennzeichnet und dürfen nicht als Produktivdaten übernommen werden.
