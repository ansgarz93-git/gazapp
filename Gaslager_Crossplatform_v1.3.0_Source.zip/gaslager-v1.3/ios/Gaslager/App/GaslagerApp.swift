import SwiftUI
import SwiftData
import UserNotifications
import UIKit

@main
struct GaslagerApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    private let modelContainer: ModelContainer = {
        let schema = Schema([
            EquipmentType.self,
            Drawer.self,
            SparePart.self,
            PartBarcode.self,
            PartCompatibility.self,
            StockMovement.self,
            TechnicalDocument.self,
            SAPWorkOrder.self,
            SAPOrderComponent.self,
            SAPMaterialMapping.self,
            SAPSyncQueueItem.self
        ])

        do {
            return try ModelContainer(
                for: schema,
                configurations: [ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)]
            )
        } catch {
            fatalError("Die lokale Lagerdatenbank konnte nicht geöffnet werden: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(modelContainer)
    }
}

final class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        return true
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        [.banner, .sound]
    }
}
