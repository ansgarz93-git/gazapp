import Foundation

enum BarcodeNormalizer {
    static func matchKey(for rawValue: String) -> String {
        var value = rawValue
            .replacingOccurrences(of: "\u{200B}", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        // Entfernt nur einen standardisierten AIM-Symbologie-Präfix (z. B. ]C1).
        // Der eigentliche Barcode-Inhalt – einschließlich GS1-Trennzeichen – bleibt erhalten.
        if value.count >= 3, value.first == "]" {
            let prefix = value.prefix(3)
            if prefix.dropFirst().allSatisfy({ $0.isLetter || $0.isNumber }) {
                value.removeFirst(3)
            }
        }

        return value
    }
}
