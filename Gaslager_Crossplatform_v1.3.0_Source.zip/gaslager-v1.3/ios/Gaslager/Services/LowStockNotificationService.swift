import Foundation
import UserNotifications

enum NotificationAuthorizationState: String {
    case notDetermined = "Noch nicht festgelegt"
    case allowed = "Erlaubt"
    case denied = "In iOS deaktiviert"
}

enum LowStockNotificationService {
    static func authorizationState() async -> NotificationAuthorizationState {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        switch settings.authorizationStatus {
        case .authorized, .provisional, .ephemeral:
            .allowed
        case .denied:
            .denied
        case .notDetermined:
            .notDetermined
        @unknown default:
            .notDetermined
        }
    }

    static func requestAuthorization() async -> Bool {
        do {
            return try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
        } catch {
            return false
        }
    }

    static func scheduleLowStockReminder(for part: SparePart) async -> Bool {
        guard await authorizationState() == .allowed else { return false }

        let content = UNMutableNotificationContent()
        content.title = "Mindestbestand erreicht"
        content.body = "\(part.partName) (Art.-Nr. \(part.originalArticleNumber)): \(part.stockQuantity) \(part.unit) vorhanden, Mindestbestand \(part.minimumStock)."
        content.sound = .default
        content.userInfo = ["partID": part.id.uuidString]

        let request = UNNotificationRequest(
            identifier: identifier(for: part.id),
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        )

        do {
            try await UNUserNotificationCenter.current().add(request)
            return true
        } catch {
            return false
        }
    }

    static func removeLowStockReminder(for partID: UUID) {
        let identifier = identifier(for: partID)
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [identifier])
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [identifier])
    }

    private static func identifier(for partID: UUID) -> String {
        "low-stock-\(partID.uuidString)"
    }
}
