import Foundation
import SwiftData
import SwiftUI
import UniformTypeIdentifiers

struct CatalogImportReport {
    var createdParts = 0
    var updatedParts = 0
    var createdBarcodes = 0
    var createdDrawers = 0
    var createdEquipmentTypes = 0
    var createdAssignments = 0
    var createdMaterialMappings = 0
    var errors: [String] = []

    var summary: String {
        var lines = [
            "Neue Teile: \(createdParts)",
            "Aktualisierte Teile: \(updatedParts)",
            "Neue Barcodes: \(createdBarcodes)",
            "Neue Gerätetypen: \(createdEquipmentTypes)",
            "Neue Schubladen: \(createdDrawers)",
            "Neue Zuordnungen: \(createdAssignments)",
            "Neue SAP-Materialzuordnungen: \(createdMaterialMappings)"
        ]
        if !errors.isEmpty {
            lines.append("Fehler: \(errors.count)")
            lines.append(contentsOf: errors.prefix(8))
            if errors.count > 8 {
                lines.append("… und \(errors.count - 8) weitere")
            }
        }
        return lines.joined(separator: "\n")
    }
}

enum CatalogCSVError: LocalizedError {
    case emptyFile
    case missingColumns([String])
    case unreadableFile

    var errorDescription: String? {
        switch self {
        case .emptyFile:
            "Die CSV-Datei enthält keine Daten."
        case .missingColumns(let columns):
            "In der Kopfzeile fehlen Pflichtspalten: \(columns.joined(separator: ", "))."
        case .unreadableFile:
            "Die CSV-Datei konnte nicht als UTF-8 oder Windows-1252 gelesen werden."
        }
    }
}

private struct CatalogCSVRow {
    let rowNumber: Int
    let barcode: String
    let barcodeType: String
    let manufacturer: String
    let articleNumber: String
    let partName: String
    let drawerCode: String
    let storageLocation: String
    let equipmentDesignation: String
    let equipmentKind: EquipmentKind
    let deviceSparePartNumber: String
    let unit: String
    let stock: Int
    let minimumStock: Int
    let reminderEnabled: Bool
    let notes: String
    let sapMaterialNumber: String
    let sapPlant: String
    let sapStorageLocation: String
    let sapBaseUnit: String
}

@MainActor
enum CatalogCSVImporter {
    static func importFile(at url: URL, into context: ModelContext) throws -> CatalogImportReport {
        let didAccess = url.startAccessingSecurityScopedResource()
        defer {
            if didAccess { url.stopAccessingSecurityScopedResource() }
        }

        let data = try Data(contentsOf: url)
        guard let text = String(data: data, encoding: .utf8)
            ?? String(data: data, encoding: .windowsCP1252) else {
            throw CatalogCSVError.unreadableFile
        }
        return try importText(text, into: context)
    }

    static func importText(_ text: String, into context: ModelContext) throws -> CatalogImportReport {
        let table = CSVCodec.parse(text)
        guard let header = table.first else { throw CatalogCSVError.emptyFile }

        let normalizedHeader = header.map(normalizeHeader)
        let requiredAliases: [[String]] = [
            ["barcode", "strichcode"],
            ["hersteller"],
            ["original_artikelnummer", "artikelnummer"],
            ["bezeichnung"],
            ["schublade"],
            ["geraetetyp", "regler_pilot"],
            ["kategorie"],
            ["ersatzteilnummer_am_geraet", "ersatzteilnummer"]
        ]
        let missing = requiredAliases.compactMap { aliases in
            aliases.contains(where: normalizedHeader.contains) ? nil : aliases[0]
        }
        guard missing.isEmpty else { throw CatalogCSVError.missingColumns(missing) }

        var rows: [CatalogCSVRow] = []
        var parsingErrors: [String] = []

        for (index, values) in table.dropFirst().enumerated() {
            let rowNumber = index + 2
            if values.allSatisfy({ $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) {
                continue
            }

            func value(_ aliases: [String]) -> String {
                guard let column = normalizedHeader.firstIndex(where: aliases.contains), column < values.count else {
                    return ""
                }
                return values[column].trimmingCharacters(in: .whitespacesAndNewlines)
            }

            let barcode = value(["barcode", "strichcode"])
            let manufacturer = value(["hersteller"])
            let articleNumber = value(["original_artikelnummer", "artikelnummer"])
            let partName = value(["bezeichnung"])
            let drawerCode = value(["schublade"])
            let equipmentDesignation = value(["geraetetyp", "regler_pilot"])
            let categoryValue = value(["kategorie"])
            let deviceNumber = value(["ersatzteilnummer_am_geraet", "ersatzteilnummer"])

            let requiredValues = [barcode, manufacturer, articleNumber, partName, drawerCode, equipmentDesignation, categoryValue, deviceNumber]
            guard !requiredValues.contains(where: \.isEmpty) else {
                parsingErrors.append("Zeile \(rowNumber): Mindestens ein Pflichtfeld ist leer.")
                continue
            }

            let equipmentKind: EquipmentKind
            switch normalizeHeader(categoryValue) {
            case "pilot":
                equipmentKind = .pilot
            case "gasdruckregler", "regler", "druckregler":
                equipmentKind = .regulator
            default:
                parsingErrors.append("Zeile \(rowNumber): Kategorie muss Gasdruckregler oder Pilot sein.")
                continue
            }

            let stockValue = value(["bestand"])
            let minimumValue = value(["mindestbestand"])
            guard let stock = stockValue.isEmpty ? 0 : Int(stockValue), stock >= 0 else {
                parsingErrors.append("Zeile \(rowNumber): Bestand ist keine positive ganze Zahl.")
                continue
            }
            guard let minimumStock = minimumValue.isEmpty ? 0 : Int(minimumValue), minimumStock >= 0 else {
                parsingErrors.append("Zeile \(rowNumber): Mindestbestand ist keine positive ganze Zahl.")
                continue
            }

            rows.append(
                CatalogCSVRow(
                    rowNumber: rowNumber,
                    barcode: barcode,
                    barcodeType: value(["barcode_typ", "barcodetyp"]),
                    manufacturer: manufacturer,
                    articleNumber: articleNumber,
                    partName: partName,
                    drawerCode: drawerCode,
                    storageLocation: value(["lagerort"]),
                    equipmentDesignation: equipmentDesignation,
                    equipmentKind: equipmentKind,
                    deviceSparePartNumber: deviceNumber,
                    unit: value(["einheit"]).isEmpty ? "Stück" : value(["einheit"]),
                    stock: stock,
                    minimumStock: minimumStock,
                    reminderEnabled: parseBoolean(value(["erinnerung", "erinnerung_aktiv"])),
                    notes: value(["notiz", "notizen"]),
                    sapMaterialNumber: value(["sap_materialnummer", "materialnummer"]),
                    sapPlant: value(["sap_werk", "werk"]),
                    sapStorageLocation: value(["sap_lagerort", "sap_lager"]),
                    sapBaseUnit: value(["sap_basiseinheit", "basiseinheit"]).isEmpty
                        ? "ST" : value(["sap_basiseinheit", "basiseinheit"])
                )
            )
        }

        var report = try upsert(rows, into: context)
        report.errors.insert(contentsOf: parsingErrors, at: 0)
        return report
    }

    private static func upsert(_ rows: [CatalogCSVRow], into context: ModelContext) throws -> CatalogImportReport {
        var report = CatalogImportReport()
        var parts = try context.fetch(FetchDescriptor<SparePart>())
        var barcodes = try context.fetch(FetchDescriptor<PartBarcode>())
        var equipmentTypes = try context.fetch(FetchDescriptor<EquipmentType>())
        var drawers = try context.fetch(FetchDescriptor<Drawer>())
        var compatibilities = try context.fetch(FetchDescriptor<PartCompatibility>())
        var materialMappings = try context.fetch(FetchDescriptor<SAPMaterialMapping>())
        let orderComponents = try context.fetch(FetchDescriptor<SAPOrderComponent>())
        var seenPartIDs = Set<UUID>()

        for row in rows {
            let barcodeKey = BarcodeNormalizer.matchKey(for: row.barcode)
            guard !barcodeKey.isEmpty else {
                report.errors.append("Zeile \(row.rowNumber): Barcode ist leer.")
                continue
            }

            let part = parts.first {
                equal($0.manufacturer, row.manufacturer) && equal($0.originalArticleNumber, row.articleNumber)
            }
            if let assignedBarcode = barcodes.first(where: { $0.matchKey == barcodeKey }),
               assignedBarcode.partID != part?.id {
                report.errors.append("Zeile \(row.rowNumber): Barcode ist bereits einem anderen Artikel zugeordnet.")
                continue
            }

            let catalogEntry = ManufacturerEquipmentCatalog.matchingEntry(
                for: row.equipmentDesignation,
                kind: row.equipmentKind
            )
            let requestedEquipment = equipmentTypes.first {
                $0.kind == row.equipmentKind &&
                ManufacturerEquipmentCatalog.areEquivalent(
                    $0.designation,
                    row.equipmentDesignation,
                    kind: row.equipmentKind
                ) &&
                (catalogEntry != nil || equal($0.manufacturer, row.manufacturer))
            }

            let equipment: EquipmentType
            let drawer: Drawer
            if let existingDrawer = drawers.first(where: { equal($0.code, row.drawerCode) }) {
                guard let drawerEquipment = equipmentTypes.first(where: { $0.id == existingDrawer.equipmentTypeID }),
                      (catalogEntry != nil || equal(drawerEquipment.manufacturer, row.manufacturer)),
                      ManufacturerEquipmentCatalog.areEquivalent(
                          drawerEquipment.designation,
                          row.equipmentDesignation,
                          kind: row.equipmentKind
                      ),
                      drawerEquipment.kind == row.equipmentKind else {
                    report.errors.append("Zeile \(row.rowNumber): Schublade \(row.drawerCode) gehört bereits zu einem anderen Gerätetyp.")
                    continue
                }
                equipment = drawerEquipment
                drawer = existingDrawer
            } else {
                if let requestedEquipment {
                    equipment = requestedEquipment
                } else {
                    equipment = EquipmentType(
                        manufacturer: row.manufacturer,
                        designation: catalogEntry?.designation ?? row.equipmentDesignation,
                        kind: row.equipmentKind,
                        notes: catalogEntry.map { "\($0.status.rawValue) · \($0.series)" } ?? ""
                    )
                    context.insert(equipment)
                    equipmentTypes.append(equipment)
                    report.createdEquipmentTypes += 1
                    for suggestion in ManufacturerDocumentCatalog.suggestions(for: equipment) {
                        context.insert(
                            TechnicalDocument(
                                equipmentTypeID: equipment.id,
                                title: suggestion.title,
                                kind: suggestion.kind,
                                sourceURL: suggestion.url,
                                isOfficialManufacturerSource: true
                            )
                        )
                    }
                }
                drawer = Drawer(
                    code: row.drawerCode,
                    location: row.storageLocation,
                    equipmentTypeID: equipment.id
                )
                context.insert(drawer)
                drawers.append(drawer)
                report.createdDrawers += 1
            }

            let resolvedPart: SparePart
            if let part {
                resolvedPart = part
                resolvedPart.partName = row.partName
                resolvedPart.unit = row.unit
                resolvedPart.drawerID = drawer.id
                resolvedPart.minimumStock = row.minimumStock
                resolvedPart.reminderEnabled = row.reminderEnabled
                resolvedPart.notes = row.notes
                resolvedPart.updatedAt = .now
                if !seenPartIDs.contains(part.id) { report.updatedParts += 1 }
            } else {
                resolvedPart = SparePart(
                    manufacturer: row.manufacturer,
                    originalArticleNumber: row.articleNumber,
                    partName: row.partName,
                    unit: row.unit,
                    drawerID: drawer.id,
                    stockQuantity: row.stock,
                    minimumStock: row.minimumStock,
                    reminderEnabled: row.reminderEnabled,
                    notes: row.notes
                )
                context.insert(resolvedPart)
                parts.append(resolvedPart)
                report.createdParts += 1

                if row.stock > 0 {
                    context.insert(
                        StockMovement(
                            partID: resolvedPart.id,
                            kind: .openingBalance,
                            quantity: row.stock,
                            reference: "CSV-Import",
                            stockAfter: row.stock,
                            barcodeUsed: row.barcode
                        )
                    )
                }
            }
            seenPartIDs.insert(resolvedPart.id)

            if !row.sapMaterialNumber.isEmpty {
                var mappingWasAccepted = true
                if materialMappings.contains(where: {
                    equal($0.materialNumber, row.sapMaterialNumber) && $0.partID != resolvedPart.id
                }) {
                    mappingWasAccepted = false
                    report.errors.append(
                        "Zeile \(row.rowNumber): SAP-Material \(row.sapMaterialNumber) ist bereits einem anderen Artikel zugeordnet."
                    )
                } else if let mapping = materialMappings.first(where: { $0.partID == resolvedPart.id }) {
                    mapping.materialNumber = row.sapMaterialNumber
                    mapping.plant = row.sapPlant
                    mapping.storageLocation = row.sapStorageLocation
                    mapping.baseUnit = row.sapBaseUnit
                    mapping.updatedAt = .now
                } else {
                    let mapping = SAPMaterialMapping(
                        partID: resolvedPart.id,
                        materialNumber: row.sapMaterialNumber,
                        plant: row.sapPlant,
                        storageLocation: row.sapStorageLocation,
                        baseUnit: row.sapBaseUnit
                    )
                    context.insert(mapping)
                    materialMappings.append(mapping)
                    report.createdMaterialMappings += 1
                }
                if mappingWasAccepted {
                    for component in orderComponents where equal(component.materialNumber, row.sapMaterialNumber) {
                        component.partID = resolvedPart.id
                        component.updatedAt = .now
                    }
                }
            }

            if !barcodes.contains(where: { $0.matchKey == barcodeKey }) {
                let isPrimary = !barcodes.contains(where: { $0.partID == resolvedPart.id })
                let newBarcode = PartBarcode(
                    value: row.barcode,
                    matchKey: barcodeKey,
                    symbology: row.barcodeType,
                    partID: resolvedPart.id,
                    isPrimary: isPrimary
                )
                context.insert(newBarcode)
                barcodes.append(newBarcode)
                report.createdBarcodes += 1
            }

            let assignmentExists = compatibilities.contains {
                $0.partID == resolvedPart.id &&
                $0.equipmentTypeID == equipment.id &&
                equal($0.deviceSparePartNumber, row.deviceSparePartNumber)
            }
            if !assignmentExists {
                let assignment = PartCompatibility(
                    partID: resolvedPart.id,
                    equipmentTypeID: equipment.id,
                    deviceSparePartNumber: row.deviceSparePartNumber
                )
                context.insert(assignment)
                compatibilities.append(assignment)
                report.createdAssignments += 1
            }
        }

        try context.save()
        return report
    }

    private static func normalizeHeader(_ value: String) -> String {
        value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
            .replacingOccurrences(of: "ä", with: "ae")
            .replacingOccurrences(of: "ö", with: "oe")
            .replacingOccurrences(of: "ü", with: "ue")
            .replacingOccurrences(of: "ß", with: "ss")
            .replacingOccurrences(of: " ", with: "_")
            .replacingOccurrences(of: "-", with: "_")
    }

    private static func parseBoolean(_ value: String) -> Bool {
        ["1", "ja", "j", "true", "wahr", "aktiv"].contains(normalizeHeader(value))
    }

    private static func equal(_ lhs: String, _ rhs: String) -> Bool {
        lhs.compare(rhs, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame
    }
}

enum CatalogCSVExporter {
    static let header = [
        "barcode", "barcode_typ", "hersteller", "original_artikelnummer", "bezeichnung",
        "schublade", "lagerort", "geraetetyp", "kategorie", "ersatzteilnummer_am_geraet",
        "einheit", "bestand", "mindestbestand", "erinnerung", "notiz",
        "sap_materialnummer", "sap_werk", "sap_lagerort", "sap_basiseinheit"
    ]

    static func makeCSV(
        parts: [SparePart],
        barcodes: [PartBarcode],
        drawers: [Drawer],
        equipmentTypes: [EquipmentType],
        compatibilities: [PartCompatibility],
        materialMappings: [SAPMaterialMapping] = []
    ) -> String {
        var rows: [[String]] = [header]

        for part in parts.sorted(by: { $0.originalArticleNumber.localizedStandardCompare($1.originalArticleNumber) == .orderedAscending }) {
            let partBarcodes = barcodes.filter { $0.partID == part.id }
            let partAssignments = compatibilities.filter { $0.partID == part.id }
            let selectedBarcodes: [PartBarcode?] = partBarcodes.isEmpty ? [nil] : partBarcodes.map { Optional($0) }
            let selectedAssignments: [PartCompatibility?] = partAssignments.isEmpty ? [nil] : partAssignments.map { Optional($0) }

            for barcode in selectedBarcodes {
                for assignment in selectedAssignments {
                    let equipment = assignment.flatMap { item in
                        equipmentTypes.first(where: { $0.id == item.equipmentTypeID })
                    }
                    let drawer = part.drawerID.flatMap { drawerID in
                        drawers.first(where: { $0.id == drawerID })
                    }
                    let mapping = materialMappings.first(where: { $0.partID == part.id })

                    rows.append([
                        barcode?.value ?? "",
                        barcode?.symbology ?? "",
                        part.manufacturer,
                        part.originalArticleNumber,
                        part.partName,
                        drawer?.code ?? "",
                        drawer?.location ?? "",
                        equipment?.designation ?? "",
                        equipment?.kind.rawValue ?? "",
                        assignment?.deviceSparePartNumber ?? "",
                        part.unit,
                        String(part.stockQuantity),
                        String(part.minimumStock),
                        part.reminderEnabled ? "ja" : "nein",
                        part.notes,
                        mapping?.materialNumber ?? "",
                        mapping?.plant ?? "",
                        mapping?.storageLocation ?? "",
                        mapping?.baseUnit ?? ""
                    ])
                }
            }
        }

        return "\u{FEFF}" + rows.map { row in
            row.map(CSVCodec.escape).joined(separator: ";")
        }.joined(separator: "\r\n")
    }
}

enum BarcodeListCSVExporter {
    static let header = [
        "barcode", "barcode_typ", "hersteller", "original_artikelnummer", "bezeichnung",
        "geraetetyp", "kategorie", "ersatzteilnummer_am_geraet", "schublade", "lagerort",
        "bestand", "mindestbestand", "einheit",
        "sap_materialnummer", "sap_werk", "sap_lagerort", "sap_basiseinheit"
    ]

    static func makeCSV(
        parts: [SparePart],
        barcodes: [PartBarcode],
        drawers: [Drawer],
        equipmentTypes: [EquipmentType],
        compatibilities: [PartCompatibility],
        materialMappings: [SAPMaterialMapping] = []
    ) -> String {
        var rows: [[String]] = [header]

        for barcode in barcodes.sorted(by: { $0.value.localizedStandardCompare($1.value) == .orderedAscending }) {
            guard let part = parts.first(where: { $0.id == barcode.partID }) else { continue }
            let drawer = part.drawerID.flatMap { drawerID in
                drawers.first(where: { $0.id == drawerID })
            }
            let assignments = compatibilities.filter { $0.partID == part.id }
            let mapping = materialMappings.first(where: { $0.partID == part.id })
            let exportedAssignments: [PartCompatibility?] = assignments.isEmpty ? [nil] : assignments.map { Optional($0) }

            for assignment in exportedAssignments {
                let equipment = assignment.flatMap { item in
                    equipmentTypes.first(where: { $0.id == item.equipmentTypeID })
                }
                rows.append([
                    barcode.value,
                    barcode.symbology,
                    part.manufacturer,
                    part.originalArticleNumber,
                    part.partName,
                    equipment?.designation ?? "",
                    equipment?.kind.rawValue ?? "",
                    assignment?.deviceSparePartNumber ?? "",
                    drawer?.code ?? "",
                    drawer?.location ?? "",
                    String(part.stockQuantity),
                    String(part.minimumStock),
                    part.unit,
                    mapping?.materialNumber ?? "",
                    mapping?.plant ?? "",
                    mapping?.storageLocation ?? "",
                    mapping?.baseUnit ?? ""
                ])
            }
        }

        return "\u{FEFF}" + rows.map { row in
            row.map(CSVCodec.escape).joined(separator: ";")
        }.joined(separator: "\r\n")
    }
}

enum CSVCodec {
    static func parse(_ text: String) -> [[String]] {
        let firstLine = text.split(whereSeparator: \.isNewline).first.map(String.init) ?? ""
        let delimiter: Character = firstLine.filter({ $0 == ";" }).count >= firstLine.filter({ $0 == "," }).count ? ";" : ","

        var rows: [[String]] = []
        var row: [String] = []
        var field = ""
        var insideQuotes = false
        var index = text.startIndex

        while index < text.endIndex {
            let character = text[index]
            let nextIndex = text.index(after: index)

            if character == "\"" {
                if insideQuotes, nextIndex < text.endIndex, text[nextIndex] == "\"" {
                    field.append("\"")
                    index = text.index(after: nextIndex)
                    continue
                }
                insideQuotes.toggle()
            } else if character == delimiter, !insideQuotes {
                row.append(field)
                field = ""
            } else if character == "\n", !insideQuotes {
                row.append(field.trimmingCharacters(in: CharacterSet(charactersIn: "\r")))
                rows.append(row)
                row = []
                field = ""
            } else {
                field.append(character)
            }
            index = nextIndex
        }

        if !field.isEmpty || !row.isEmpty {
            row.append(field.trimmingCharacters(in: CharacterSet(charactersIn: "\r")))
            rows.append(row)
        }

        if !rows.isEmpty, !rows[0].isEmpty {
            rows[0][0] = rows[0][0].replacingOccurrences(of: "\u{FEFF}", with: "")
        }
        return rows
    }

    static func escape(_ value: String) -> String {
        guard value.contains(";") || value.contains("\"") || value.contains("\n") || value.contains("\r") else {
            return value
        }
        return "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
}

struct CSVTextDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText, .plainText] }

    var text: String

    init(text: String = "") {
        self.text = text
    }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents,
              let content = String(data: data, encoding: .utf8) else {
            throw CatalogCSVError.unreadableFile
        }
        text = content
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: Data(text.utf8))
    }
}
