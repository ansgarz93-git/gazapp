import Foundation

struct SuggestedManufacturerDocument: Identifiable {
    let title: String
    let kind: TechnicalDocumentKind
    let url: String
    var id: String { url }
}

enum ManufacturerCatalogStatus: String {
    case current = "Aktuelles Herstellerprogramm"
    case installedBase = "Bestands-/Altanlage (Herstellerdokumentation)"
}

struct ManufacturerEquipmentEntry: Identifiable {
    let designation: String
    let kind: EquipmentKind
    let series: String
    let status: ManufacturerCatalogStatus
    let sourceURL: String
    let aliases: [String]

    var id: String { "\(kind.rawValue)|\(designation)" }
}

/// Öffentlich belegter Honeywell-/RMG-Typenkatalog. Artikel- und Ersatzteilnummern
/// werden bewusst nicht geraten, sondern erst aus der typ- und ausführungsspezifischen
/// Herstellerstückliste übernommen.
enum ManufacturerEquipmentCatalog {
    static let officialDocumentArchive = "https://www.hongastec.de/service/download-dokumente"

    static let entries: [ManufacturerEquipmentEntry] = [
        // Klein-Druckregelgeräte
        entry("HON 200", .regulator, "Klein-Druckregelgerät", currentSmall("hon-200")),
        entry("HON 201", .regulator, "Klein-Druckregelgerät", currentSmall("hon-201")),
        entry("HON 210", .regulator, "Klein-Druckregelgerät", officialDocumentArchive, .installedBase),
        entry("HON 213 (D 36 Hb)", .regulator, "Klein-Druckregelgerät", currentSmall("hon-213-d-36-hb"), aliases: ["HON 213", "D 36 Hb"]),
        entry("HON 214 (D 144a)", .regulator, "Klein-Druckregelgerät", currentSmall("hon-214-d-144a"), aliases: ["HON 214", "D 144a"]),
        entry("HON 219 (D 119a)", .regulator, "Klein-Druckregelgerät", currentSmall("hon-219-d-119a"), aliases: ["HON 219", "D 119a"]),

        // Mitteldruckregler bis PN 16 / ANSI 150
        entry("HON 226", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-226")),
        entry("HON 226 SD", .regulator, "Bis PN 16 / ANSI 150", germanMedium),
        entry("HON 226 ZSO", .regulator, "Bis PN 16 / ANSI 150", germanMedium),
        entry("HON 270", .regulator, "Bestandsanlage", officialDocumentArchive, .installedBase),
        entry("HON 270 MK2", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-270-mk2"), aliases: ["HON 270 MK 2"]),
        entry("HON 277", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-277")),
        entry("HON 280", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-280-280h")),
        entry("HON 280H", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-280-280h")),
        entry("HON 280H-309", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-280h-309")),
        entry("HON 282H", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-282h")),
        entry("HON 300", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-300")),
        entry("HON 322", .regulator, "Bestandsanlage", hon650CompatibilityPDF, .installedBase),
        entry("HON 324", .regulator, "Bestandsanlage", officialDocumentArchive, .installedBase),
        entry("HON 330", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-330")),
        entry("HON 332", .regulator, "Bestandsanlage", hon674Manual, .installedBase),
        entry("HON 370", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-370")),
        entry("HON 372", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-372")),
        entry("HON 380", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-380")),
        entry("HON 680", .regulator, "Bestandsanlage", officialDocumentArchive, .installedBase),
        entry("HON 680 MK1", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-680-mk-1-and-mk-2-eva"), aliases: ["HON 680 MK 1"]),
        entry("HON 680 MK2-EVA", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-680-mk-1-and-mk-2-eva"), aliases: ["HON 680 MK 2 EVA", "HON 680 MK2 EVA"]),
        entry("HON 680H MK1", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-680h-mk-1-and-mk-2-eva"), aliases: ["HON 680H MK 1"]),
        entry("HON 680H MK2-EVA", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-680h-mk-1-and-mk-2-eva"), aliases: ["HON 680H MK 2 EVA", "HON 680H MK2 EVA"]),
        entry("HON Elster J125", .regulator, "Bis PN 16 / ANSI 150", currentMedium("hon-elster-j125"), aliases: ["J125"]),

        // Hochdruckregler und Bestandsanlagen
        entry("HON 402", .regulator, "Bis PN 40 / ANSI 300", currentHighPN40("hon-402")),
        entry("HON 408", .regulator, "Bestandsanlage", hon674Manual, .installedBase),
        entry("HON 409", .regulator, "Bestandsanlage", hon650CompatibilityPDF, .installedBase),
        entry("HON 502", .regulator, "Bis ANSI 600", currentHighANSI600("hon-502")),
        entry("HON 5020", .regulator, "Bis PN 40 / ANSI 300", currentHighPN40("hon-5020")),
        entry("HON 503", .regulator, "Bis ANSI 600", currentHighANSI600("hon-503")),
        entry("HON 505", .regulator, "Bestandsanlage", officialDocumentArchive, .installedBase),
        entry("HON 512", .regulator, "Bis ANSI 600", currentHighANSI600("hon-512")),
        entry("HON 530-E", .regulator, "Bis ANSI 600", currentHighANSI600("hon-530-e")),
        entry("HON 530-E-WG", .regulator, "Bis ANSI 600", currentHighANSI600("hon-530-e-wg")),
        entry("HON R100", .regulator, "Bis ANSI 600", currentHighANSI600("honr-100"), aliases: ["HONR 100", "R100"]),
        entry("HON Elster AFV", .regulator, "Bis ANSI 600", currentHighANSI600("hon-elster-afv"), aliases: ["AFV"]),

        // Hilfsenergie-Regler / Piloten
        entry("HON 600", .pilot, "Baureihe 600", officialDocumentArchive, .installedBase),
        entry("HON 610", .pilot, "Baureihe 600", currentPilot("hon-610")),
        entry("HON 610 E", .pilot, "Baureihe 600", currentPilot("hon-610"), aliases: ["HON 610E"]),
        entry("HON 610 D", .pilot, "Baureihe 600", currentPilot("hon-610"), aliases: ["HON 610D"]),
        entry("HON 625", .pilot, "Baureihe 600", currentPilot("hon-625")),
        entry("HON 630", .pilot, "Baureihe 600", currentPilot("hon-630")),
        entry("HON 630a", .pilot, "Baureihe 600", hon630Brochure, .installedBase, aliases: ["HON 630 A"]),
        entry("HON 630-1", .pilot, "Baureihe 600", currentPilot("hon-630-1")),
        entry("HON 630-FE", .pilot, "Baureihe 600", currentPilot("hon-630-fe")),
        entry("HON 638", .pilot, "Baureihe 600", officialDocumentArchive, .installedBase),
        entry("HON 638-EP", .pilot, "Baureihe 600", currentPilot("hon-638-ep")),
        entry("HON 640", .pilot, "Baureihe 600", officialDocumentArchive, .installedBase),
        entry("HON 650", .pilot, "Baureihe 600", currentPilot("hon-650")),
        entry("HON 650-FE", .pilot, "Baureihe 600", currentPilot("hon-650-fe-655-fe")),
        entry("HON 651", .pilot, "Baureihe 600", germanPilots),
        entry("HON 652", .pilot, "Baureihe 600", currentPilot("hon-652")),
        entry("HON 655", .pilot, "Baureihe 600", officialDocumentArchive, .installedBase),
        entry("HON 655-DP", .pilot, "Baureihe 600", currentPilot("hon-655-dp")),
        entry("HON 655-EP", .pilot, "Baureihe 600", currentPilot("hon-655-ep")),
        entry("HON 655-FE", .pilot, "Baureihe 600", currentPilot("hon-650-fe-655-fe")),
        entry("HON 656", .pilot, "Baureihe 600", germanPilots),
        entry("HON 658", .pilot, "Baureihe 600", officialDocumentArchive, .installedBase),
        entry("HON 658-DP", .pilot, "Baureihe 600", currentPilot("hon-658-dp")),
        entry("HON 658-EP", .pilot, "Baureihe 600", currentPilot("hon-658-ep"))
    ]

    static func matchingEntry(for designation: String, kind: EquipmentKind? = nil) -> ManufacturerEquipmentEntry? {
        let key = normalizedKey(designation)
        guard !key.isEmpty else { return nil }
        return entries.first { entry in
            (kind == nil || entry.kind == kind) &&
            ([entry.designation] + entry.aliases).contains { normalizedKey($0) == key }
        }
    }

    static func areEquivalent(_ lhs: String, _ rhs: String, kind: EquipmentKind? = nil) -> Bool {
        if let left = matchingEntry(for: lhs, kind: kind),
           let right = matchingEntry(for: rhs, kind: kind) {
            return left.id == right.id
        }
        return normalizedKey(lhs) == normalizedKey(rhs)
    }

    static func canonicalDesignation(for value: String, kind: EquipmentKind? = nil) -> String {
        matchingEntry(for: value, kind: kind)?.designation ?? value.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func normalizedKey(_ value: String) -> String {
        let folded = value
            .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "de_DE"))
            .uppercased()
            .replacingOccurrences(of: "RMG", with: "HON")
        return folded.unicodeScalars
            .filter { CharacterSet.alphanumerics.contains($0) }
            .map { String($0) }
            .joined()
    }

    private static func entry(
        _ designation: String,
        _ kind: EquipmentKind,
        _ series: String,
        _ sourceURL: String,
        _ status: ManufacturerCatalogStatus = .current,
        aliases: [String] = []
    ) -> ManufacturerEquipmentEntry {
        ManufacturerEquipmentEntry(
            designation: designation,
            kind: kind,
            series: series,
            status: status,
            sourceURL: sourceURL,
            aliases: aliases
        )
    }

    private static let productRoot = "https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories"
    private static func currentSmall(_ slug: String) -> String { "\(productRoot)/small-pressure-regulators-pressure-reducer/\(slug)" }
    private static func currentMedium(_ slug: String) -> String { "\(productRoot)/medium-pressure-regulators-pn16-ansi-150/\(slug)" }
    private static func currentHighPN40(_ slug: String) -> String { "\(productRoot)/high-pressure-regulators-up-to-pn40-ansi-300/\(slug)" }
    private static func currentHighANSI600(_ slug: String) -> String { "\(productRoot)/high-pressure-regulators-up-to-ansi-600/\(slug)" }
    private static func currentPilot(_ slug: String) -> String { "\(productRoot)/pilot-for-gas-pressure-regulators/\(slug)" }

    private static let germanMedium = "https://www.hongastec.de/produkte/gas-druckregelgeraete/gas-druckregelgeraete-bis-pn16-ansi-150"
    private static let germanPilots = "https://www.hongastec.de/produkte/gas-druckregelgeraete/regler-fuer-gas-druckregelgeraete-mit-hilfsenergie"
    private static let hon650CompatibilityPDF = "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/regulators---safety-accessories/series-600-pilot-regulators-for-pilot-operated-gas-pressure-regulators/hon-650/hon-650-english.pdf"
    private static let hon630Brochure = "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/regulators---safety-accessories/series-600-pilot-regulators-for-pilot-operated-gas-pressure-regulators/hon-630/hon-630-english.pdf?download=false"
    private static let hon674Manual = "https://www.hongastec.de/fileadmin/user_upload/Manual_HON_674_20_GB_2023_04.pdf"
}

enum ManufacturerDocumentCatalog {
    static let sparePartsPage = "https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories/regulators-and-safety-accessories-spare-parts/spare-parts-regulators-and-safety-accessories"
    static let regulatorsPage = "https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories"
    static let pilotsPage = "https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories/pilot-for-gas-pressure-regulators"

    static func suggestions(for equipment: EquipmentType) -> [SuggestedManufacturerDocument] {
        var documents: [SuggestedManufacturerDocument] = []
        let entry = ManufacturerEquipmentCatalog.matchingEntry(for: equipment.designation, kind: equipment.kind)

        if let entry {
            documents.append(
                SuggestedManufacturerDocument(
                    title: "\(entry.designation) – offizielle Herstellerquelle",
                    kind: entry.sourceURL.lowercased().contains(".pdf") ? .brochure : .manufacturerPage,
                    url: entry.sourceURL
                )
            )
        } else {
            documents.append(
                SuggestedManufacturerDocument(
                    title: "Honeywell – \(equipment.kind == .pilot ? "Pilot" : "Gasdruckregler")-Produktprogramm",
                    kind: .manufacturerPage,
                    url: equipment.kind == .pilot ? pilotsPage : regulatorsPage
                )
            )
        }

        documents.append(
            SuggestedManufacturerDocument(
                title: "Honeywell Gas Technologies – Dokumentarchiv",
                kind: .manufacturerPage,
                url: ManufacturerEquipmentCatalog.officialDocumentArchive
            )
        )
        documents.append(
            SuggestedManufacturerDocument(
                title: "Honeywell – Ersatzteile und Service",
                kind: .manufacturerPage,
                url: sparePartsPage
            )
        )

        let brochure: SuggestedManufacturerDocument?
        switch ManufacturerEquipmentCatalog.normalizedKey(entry?.designation ?? equipment.designation) {
        case "HON402":
            brochure = SuggestedManufacturerDocument(
                title: "HON 402 – Produktbroschüre",
                kind: .brochure,
                url: "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/regulators---safety-accessories/high-pressure-regulators-up-to-pn40-(ansi-300)/hon-402/hon-402-brochure.pdf?download=false"
            )
        case "HON503":
            brochure = SuggestedManufacturerDocument(
                title: "HON 503 – Produktbroschüre",
                kind: .brochure,
                url: "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/regulators---safety-accessories/high-pressure-regulators-up-to-ansi-600/hon-503/hon-503-brochure.pdf?download=false"
            )
        case "HON630", "HON630A", "HON640":
            brochure = SuggestedManufacturerDocument(
                title: "HON 630a / HON 640 – Produktbroschüre",
                kind: .brochure,
                url: "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/regulators---safety-accessories/series-600-pilot-regulators-for-pilot-operated-gas-pressure-regulators/hon-630/hon-630-english.pdf?download=false"
            )
        case "HON650":
            brochure = SuggestedManufacturerDocument(
                title: "HON 650 – Produktbroschüre",
                kind: .brochure,
                url: "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/regulators---safety-accessories/series-600-pilot-regulators-for-pilot-operated-gas-pressure-regulators/hon-650/hon-650-english.pdf?download=false"
            )
        default:
            brochure = nil
        }
        if let brochure { documents.append(brochure) }

        var seenURLs = Set<String>()
        return documents.filter { seenURLs.insert($0.url).inserted }
    }
}

enum TechnicalDocumentStorage {
    static func importPDF(from sourceURL: URL) throws -> String {
        let didAccess = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if didAccess { sourceURL.stopAccessingSecurityScopedResource() }
        }

        let directory = try documentsDirectory()
        let cleanName = sanitize(sourceURL.deletingPathExtension().lastPathComponent)
        let fileName = "\(UUID().uuidString)_\(cleanName).pdf"
        let destination = directory.appendingPathComponent(fileName, isDirectory: false)
        try FileManager.default.copyItem(at: sourceURL, to: destination)
        return fileName
    }

    static func localURL(for fileName: String) -> URL? {
        guard !fileName.isEmpty, let directory = try? documentsDirectory() else { return nil }
        let url = directory.appendingPathComponent(fileName, isDirectory: false)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    private static func documentsDirectory() throws -> URL {
        let base = try FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let directory = base.appendingPathComponent("Herstellerunterlagen", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory
    }

    private static func sanitize(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_"))
        let scalars = value.unicodeScalars.map { allowed.contains($0) ? Character(String($0)) : "_" }
        let result = String(scalars)
        return result.isEmpty ? "Dokument" : result
    }
}
