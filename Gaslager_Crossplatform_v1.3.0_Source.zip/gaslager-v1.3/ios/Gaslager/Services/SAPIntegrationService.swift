import Foundation
import Security
import SwiftData

enum SAPSettingsKey {
    static let baseURL = "sap.baseURL"
    static let ordersPath = "sap.ordersPath"
    static let movementsPath = "sap.movementsPath"
    static let stockPath = "sap.stockPath"
    static let sapClient = "sap.client"
    static let defaultPlant = "sap.defaultPlant"
    static let defaultStorageLocation = "sap.defaultStorageLocation"
    static let goodsIssueMovementType = "sap.goodsIssueMovementType"
    static let goodsReceiptMovementType = "sap.goodsReceiptMovementType"
    static let orderRequiredForOutbound = "sap.orderRequiredForOutbound"
    static let inventorySyncEnabled = "sap.inventorySyncEnabled"
    static let autoSyncEnabled = "sap.autoSyncEnabled"
    static let sapStockIsMaster = "sap.stockIsMaster"
    static let activeWorkOrderID = "sap.activeWorkOrderID"
}

struct SAPConnectionConfiguration: Sendable {
    var baseURL: String
    var ordersPath: String
    var movementsPath: String
    var stockPath: String
    var sapClient: String
    var defaultPlant: String
    var defaultStorageLocation: String
    var goodsIssueMovementType: String
    var goodsReceiptMovementType: String
    var sapStockIsMaster: Bool

    static func current(defaults: UserDefaults = .standard) -> SAPConnectionConfiguration {
        SAPConnectionConfiguration(
            baseURL: defaults.string(forKey: SAPSettingsKey.baseURL) ?? "",
            ordersPath: defaults.string(forKey: SAPSettingsKey.ordersPath) ?? "/api/gaslager/v1/work-orders",
            movementsPath: defaults.string(forKey: SAPSettingsKey.movementsPath) ?? "/api/gaslager/v1/material-movements",
            stockPath: defaults.string(forKey: SAPSettingsKey.stockPath) ?? "/api/gaslager/v1/stock",
            sapClient: defaults.string(forKey: SAPSettingsKey.sapClient) ?? "",
            defaultPlant: defaults.string(forKey: SAPSettingsKey.defaultPlant) ?? "",
            defaultStorageLocation: defaults.string(forKey: SAPSettingsKey.defaultStorageLocation) ?? "",
            goodsIssueMovementType: defaults.string(forKey: SAPSettingsKey.goodsIssueMovementType) ?? "261",
            goodsReceiptMovementType: defaults.string(forKey: SAPSettingsKey.goodsReceiptMovementType) ?? "101",
            sapStockIsMaster: defaults.object(forKey: SAPSettingsKey.sapStockIsMaster) == nil
                ? true : defaults.bool(forKey: SAPSettingsKey.sapStockIsMaster)
        )
    }

    var isConfigured: Bool {
        guard let url = URL(string: baseURL), url.scheme?.lowercased() == "https", url.host != nil else {
            return false
        }
        return !ordersPath.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
            !movementsPath.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}

enum SAPBridgeError: LocalizedError {
    case notConfigured
    case invalidHTTPSURL
    case invalidResponse
    case server(status: Int, message: String)
    case rejected(String)
    case unreadableImport
    case missingOrderNumber

    var errorDescription: String? {
        switch self {
        case .notConfigured:
            "Die IH2Go-Bridge ist noch nicht vollständig konfiguriert."
        case .invalidHTTPSURL:
            "Die Serveradresse muss eine gültige HTTPS-Adresse sein."
        case .invalidResponse:
            "Die IH2Go-Bridge hat eine unerwartete Antwort geliefert."
        case .server(let status, let message):
            "IH2Go/SAP antwortet mit HTTP \(status): \(message)"
        case .rejected(let message):
            message.isEmpty ? "SAP hat die Materialbuchung abgelehnt." : message
        case .unreadableImport:
            "Die Auftragsdatei entspricht nicht dem IH2Go-Bridge-Format."
        case .missingOrderNumber:
            "Der Auftrag enthält keine Auftragsnummer."
        }
    }
}

enum SAPCredentialStore {
    private static let service = "de.ansgarz.Gaslager.IH2Go"
    private static let account = "bearer-token"

    static func saveBearerToken(_ token: String) throws {
        let cleanToken = token.trimmingCharacters(in: .whitespacesAndNewlines)
        let baseQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(baseQuery as CFDictionary)
        guard !cleanToken.isEmpty else { return }

        var insertQuery = baseQuery
        insertQuery[kSecValueData as String] = Data(cleanToken.utf8)
        insertQuery[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let status = SecItemAdd(insertQuery as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
        }
    }

    static func bearerToken() -> String {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
}

private struct SAPListEnvelope<Element: Decodable>: Decodable {
    let items: [Element]
}

private struct SAPMovementPayload: Encodable {
    let bookingID: String
    let idempotencyKey: String
    let operation: String
    let movementType: String
    let orderNumber: String
    let customerNumber: String
    let equipmentNumber: String
    let materialNumber: String
    let quantity: Int
    let unit: String
    let plant: String
    let storageLocation: String
    let postingDate: Date
    let barcode: String
    let reference: String
    let note: String

    enum CodingKeys: String, CodingKey {
        case bookingID = "booking_id"
        case idempotencyKey = "idempotency_key"
        case operation
        case movementType = "movement_type"
        case orderNumber = "order_number"
        case customerNumber = "customer_number"
        case equipmentNumber = "equipment_number"
        case materialNumber = "material_number"
        case quantity
        case unit
        case plant
        case storageLocation = "storage_location"
        case postingDate = "posting_date"
        case barcode
        case reference
        case note
    }
}

enum IH2GoBridgeClient {
    static func fetchWorkOrders(configuration: SAPConnectionConfiguration) async throws -> [SAPRemoteWorkOrder] {
        let request = try makeRequest(path: configuration.ordersPath, method: "GET", configuration: configuration)
        let data = try await execute(request)
        return try decodeList(SAPRemoteWorkOrder.self, from: data)
    }

    static func fetchStock(configuration: SAPConnectionConfiguration) async throws -> [SAPRemoteStock] {
        guard !configuration.stockPath.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return [] }
        let request = try makeRequest(path: configuration.stockPath, method: "GET", configuration: configuration)
        let data = try await execute(request)
        return try decodeList(SAPRemoteStock.self, from: data)
    }

    static func postMovement(
        queueItem: SAPSyncQueueItem,
        movement: StockMovement,
        part: SparePart,
        sapUnit: String,
        configuration: SAPConnectionConfiguration
    ) async throws -> SAPMovementReceipt {
        let movementType = queueItem.operation == .goodsIssue
            ? configuration.goodsIssueMovementType
            : configuration.goodsReceiptMovementType
        let payload = SAPMovementPayload(
            bookingID: movement.id.uuidString,
            idempotencyKey: queueItem.idempotencyKey,
            operation: queueItem.operation.rawValue,
            movementType: movementType,
            orderNumber: movement.sapOrderNumber,
            customerNumber: movement.sapCustomerNumber,
            equipmentNumber: movement.sapEquipmentNumber,
            materialNumber: movement.sapMaterialNumber,
            quantity: movement.quantity,
            unit: sapUnit.isEmpty ? part.unit : sapUnit,
            plant: movement.sapPlant,
            storageLocation: movement.sapStorageLocation,
            postingDate: movement.timestamp,
            barcode: movement.barcodeUsed,
            reference: movement.reference,
            note: movement.notes
        )

        var request = try makeRequest(
            path: configuration.movementsPath,
            method: "POST",
            configuration: configuration
        )
        request.httpBody = try encoder.encode(payload)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(queueItem.idempotencyKey, forHTTPHeaderField: "Idempotency-Key")

        let data = try await execute(request)
        let receipt = try decoder.decode(SAPMovementReceipt.self, from: data)
        guard receipt.accepted else { throw SAPBridgeError.rejected(receipt.message ?? "") }
        return receipt
    }

    private static func makeRequest(
        path: String,
        method: String,
        configuration: SAPConnectionConfiguration
    ) throws -> URLRequest {
        guard configuration.isConfigured else { throw SAPBridgeError.notConfigured }
        guard var components = URLComponents(string: configuration.baseURL),
              components.scheme?.lowercased() == "https",
              components.host != nil else {
            throw SAPBridgeError.invalidHTTPSURL
        }

        let basePath = components.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let endpointPath = path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        components.path = "/" + [basePath, endpointPath].filter { !$0.isEmpty }.joined(separator: "/")
        if !configuration.sapClient.isEmpty {
            var queryItems = components.queryItems ?? []
            queryItems.append(URLQueryItem(name: "sap-client", value: configuration.sapClient))
            components.queryItems = queryItems
        }
        guard let url = components.url else { throw SAPBridgeError.invalidHTTPSURL }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 30
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Gaslager-iOS/2", forHTTPHeaderField: "User-Agent")
        let token = SAPCredentialStore.bearerToken()
        if !token.isEmpty {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        return request
    }

    private static func execute(_ request: URLRequest) async throws -> Data {
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else { throw SAPBridgeError.invalidResponse }
        guard (200...299).contains(httpResponse.statusCode) else {
            let message = String(data: data, encoding: .utf8)
                .map { String($0.prefix(500)) } ?? "Keine Fehlermeldung"
            throw SAPBridgeError.server(status: httpResponse.statusCode, message: message)
        }
        return data
    }

    private static func decodeList<Element: Decodable>(_ type: Element.Type, from data: Data) throws -> [Element] {
        if let direct = try? decoder.decode([Element].self, from: data) { return direct }
        if let envelope = try? decoder.decode(SAPListEnvelope<Element>.self, from: data) { return envelope.items }
        throw SAPBridgeError.invalidResponse
    }

    private static var decoder: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let value = try container.decode(String.self)
            let fractional = ISO8601DateFormatter()
            fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = fractional.date(from: value) { return date }
            let standard = ISO8601DateFormatter()
            if let date = standard.date(from: value) { return date }
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Ungültiges ISO-8601-Datum")
        }
        return decoder
    }

    private static var encoder: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}

struct SAPSyncReport {
    var importedOrders = 0
    var synchronizedMovements = 0
    var failedMovements = 0
    var synchronizedStocks = 0
    var warnings: [String] = []

    var summary: String {
        var lines = [
            "Aufträge aktualisiert: \(importedOrders)",
            "Buchungen übertragen: \(synchronizedMovements)",
            "Buchungen mit Fehler: \(failedMovements)",
            "Bestände abgeglichen: \(synchronizedStocks)"
        ]
        lines.append(contentsOf: warnings.map { "Hinweis: \($0)" })
        return lines.joined(separator: "\n")
    }
}

@MainActor
enum SAPIntegrationService {
    static func importWorkOrders(from url: URL, into context: ModelContext) throws -> Int {
        let didAccess = url.startAccessingSecurityScopedResource()
        defer { if didAccess { url.stopAccessingSecurityScopedResource() } }
        let data = try Data(contentsOf: url)
        return try importWorkOrders(data: data, into: context)
    }

    static func importWorkOrders(data: Data, into context: ModelContext) throws -> Int {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let value = try container.decode(String.self)
            let fractional = ISO8601DateFormatter()
            fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = fractional.date(from: value) { return date }
            let standard = ISO8601DateFormatter()
            if let date = standard.date(from: value) { return date }
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Ungültiges Datum")
        }

        let orders: [SAPRemoteWorkOrder]
        if let direct = try? decoder.decode([SAPRemoteWorkOrder].self, from: data) {
            orders = direct
        } else if let envelope = try? decoder.decode(SAPListEnvelope<SAPRemoteWorkOrder>.self, from: data) {
            orders = envelope.items
        } else {
            throw SAPBridgeError.unreadableImport
        }
        for order in orders { try upsert(order, into: context) }
        try context.save()
        return orders.count
    }

    static func synchronize(in context: ModelContext) async throws -> SAPSyncReport {
        let configuration = SAPConnectionConfiguration.current()
        guard configuration.isConfigured else { throw SAPBridgeError.notConfigured }
        var report = SAPSyncReport()

        do {
            let remoteOrders = try await IH2GoBridgeClient.fetchWorkOrders(configuration: configuration)
            for order in remoteOrders { try upsert(order, into: context) }
            report.importedOrders = remoteOrders.count
            try context.save()
        } catch {
            report.warnings.append("Auftragsabruf: \(error.localizedDescription)")
        }

        let queue = try context.fetch(FetchDescriptor<SAPSyncQueueItem>())
            .filter { $0.status != .synchronized }
            .sorted { $0.createdAt < $1.createdAt }
        let movements = try context.fetch(FetchDescriptor<StockMovement>())
        let parts = try context.fetch(FetchDescriptor<SparePart>())
        let mappings = try context.fetch(FetchDescriptor<SAPMaterialMapping>())

        for item in queue {
            guard let movement = movements.first(where: { $0.id == item.movementID }),
                  let part = parts.first(where: { $0.id == movement.partID }) else {
                item.status = .failed
                item.lastError = "Lokale Buchung oder Ersatzteil nicht gefunden."
                report.failedMovements += 1
                continue
            }

            let partMapping = mappings.first(where: { $0.partID == part.id })
            if movement.sapMaterialNumber.isEmpty, let mapping = partMapping {
                movement.sapMaterialNumber = mapping.materialNumber
                movement.sapPlant = movement.sapPlant.isEmpty ? mapping.plant : movement.sapPlant
                movement.sapStorageLocation = movement.sapStorageLocation.isEmpty ? mapping.storageLocation : movement.sapStorageLocation
            }
            if movement.sapPlant.isEmpty {
                let mappedPlant = partMapping?.plant ?? ""
                movement.sapPlant = mappedPlant.isEmpty ? configuration.defaultPlant : mappedPlant
            }
            if movement.sapStorageLocation.isEmpty {
                let mappedStorageLocation = partMapping?.storageLocation ?? ""
                movement.sapStorageLocation = mappedStorageLocation.isEmpty
                    ? configuration.defaultStorageLocation : mappedStorageLocation
            }
            guard !movement.sapMaterialNumber.isEmpty else {
                item.status = .mappingRequired
                movement.sapSyncStatus = .mappingRequired
                item.lastError = "Dem Ersatzteil fehlt die SAP-Materialnummer."
                report.failedMovements += 1
                continue
            }

            item.status = .syncing
            movement.sapSyncStatus = .syncing
            item.attempts += 1
            item.lastAttemptAt = .now
            try context.save()

            do {
                let receipt = try await IH2GoBridgeClient.postMovement(
                    queueItem: item,
                    movement: movement,
                    part: part,
                    sapUnit: partMapping?.baseUnit ?? part.unit,
                    configuration: configuration
                )
                item.status = .synchronized
                item.lastError = ""
                item.sapDocumentNumber = receipt.materialDocument ?? ""
                movement.sapSyncStatus = .synchronized
                movement.sapMaterialDocument = receipt.materialDocument ?? ""
                movement.sapSyncMessage = receipt.message ?? ""
                report.synchronizedMovements += 1
            } catch {
                item.status = .failed
                item.lastError = error.localizedDescription
                movement.sapSyncStatus = .failed
                movement.sapSyncMessage = error.localizedDescription
                report.failedMovements += 1
            }
            try context.save()
        }

        do {
            let remoteStocks = try await IH2GoBridgeClient.fetchStock(configuration: configuration)
            report.synchronizedStocks = try await apply(remoteStocks, configuration: configuration, in: context)
        } catch {
            report.warnings.append("Bestandsabruf: \(error.localizedDescription)")
        }
        return report
    }

    static func addManualOrder(
        orderNumber: String,
        customerNumber: String,
        customerName: String,
        equipmentNumber: String,
        functionalLocation: String,
        equipmentTypeID: UUID?,
        shortText: String,
        plant: String,
        storageLocation: String,
        in context: ModelContext
    ) throws -> SAPWorkOrder {
        let cleanOrderNumber = orderNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanOrderNumber.isEmpty else { throw SAPBridgeError.missingOrderNumber }
        let orders = try context.fetch(FetchDescriptor<SAPWorkOrder>())
        let order: SAPWorkOrder
        if let existing = orders.first(where: { $0.orderNumber == cleanOrderNumber }) {
            order = existing
        } else {
            order = SAPWorkOrder(
                orderNumber: cleanOrderNumber,
                customerName: customerName.trimmingCharacters(in: .whitespacesAndNewlines)
            )
            context.insert(order)
        }
        order.customerNumber = customerNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        order.customerName = customerName.trimmingCharacters(in: .whitespacesAndNewlines)
        order.equipmentNumber = equipmentNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        order.functionalLocation = functionalLocation.trimmingCharacters(in: .whitespacesAndNewlines)
        order.equipmentTypeID = equipmentTypeID
        order.shortText = shortText.trimmingCharacters(in: .whitespacesAndNewlines)
        order.plant = plant.trimmingCharacters(in: .whitespacesAndNewlines)
        order.storageLocation = storageLocation.trimmingCharacters(in: .whitespacesAndNewlines)
        order.sourceSystem = "Manuell / IH2Go"
        order.updatedAt = .now
        try context.save()
        return order
    }

    private static func upsert(_ remote: SAPRemoteWorkOrder, into context: ModelContext) throws {
        let cleanOrderNumber = remote.orderNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanOrderNumber.isEmpty else { throw SAPBridgeError.missingOrderNumber }

        var equipmentTypes = try context.fetch(FetchDescriptor<EquipmentType>())
        let catalogEntry = ManufacturerEquipmentCatalog.matchingEntry(for: remote.equipmentType)
        let equipmentKind: EquipmentKind = catalogEntry?.kind ?? (
            remote.equipmentKind.lowercased().contains("pilot") ? .pilot : .regulator
        )
        var equipmentType: EquipmentType?
        if !remote.equipmentType.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            equipmentType = equipmentTypes.first {
                $0.kind == equipmentKind &&
                ManufacturerEquipmentCatalog.areEquivalent($0.designation, remote.equipmentType, kind: equipmentKind) &&
                (catalogEntry != nil || remote.equipmentManufacturer.isEmpty || equal($0.manufacturer, remote.equipmentManufacturer))
            }
            if equipmentType == nil {
                let created = EquipmentType(
                    manufacturer: remote.equipmentManufacturer.isEmpty ? "Honeywell / RMG" : remote.equipmentManufacturer,
                    designation: catalogEntry?.designation ?? remote.equipmentType,
                    kind: equipmentKind,
                    notes: catalogEntry.map { "Aus IH2Go/SAP übernommen · \($0.status.rawValue)" }
                        ?? "Aus IH2Go/SAP-Auftrag übernommen"
                )
                context.insert(created)
                equipmentTypes.append(created)
                equipmentType = created
                for suggestion in ManufacturerDocumentCatalog.suggestions(for: created) {
                    context.insert(
                        TechnicalDocument(
                            equipmentTypeID: created.id,
                            title: suggestion.title,
                            kind: suggestion.kind,
                            sourceURL: suggestion.url,
                            isOfficialManufacturerSource: true
                        )
                    )
                }
            }
        }

        let orders = try context.fetch(FetchDescriptor<SAPWorkOrder>())
        let order: SAPWorkOrder
        if let existing = orders.first(where: { $0.orderNumber == cleanOrderNumber }) {
            order = existing
        } else {
            order = SAPWorkOrder(orderNumber: cleanOrderNumber, customerName: remote.customerName)
            context.insert(order)
        }
        order.customerNumber = remote.customerNumber
        order.customerName = remote.customerName
        order.equipmentNumber = remote.equipmentNumber
        order.functionalLocation = remote.functionalLocation
        order.equipmentTypeID = equipmentType?.id
        order.shortText = remote.shortText
        order.status = SAPWorkOrderStatus.fromRemoteValue(remote.status)
        order.plannedStart = remote.plannedStart
        order.plant = remote.plant
        order.storageLocation = remote.storageLocation
        order.sourceSystem = "IH2Go / SAP"
        order.lastSyncedAt = .now
        order.updatedAt = .now

        let mappings = try context.fetch(FetchDescriptor<SAPMaterialMapping>())
        var components = try context.fetch(FetchDescriptor<SAPOrderComponent>())
        let remoteItemNumbers = Set(remote.components.map(\.itemNumber))
        for staleComponent in components where
            staleComponent.workOrderID == order.id &&
            !remoteItemNumbers.contains(staleComponent.itemNumber) {
            context.delete(staleComponent)
        }
        components.removeAll {
            $0.workOrderID == order.id && !remoteItemNumbers.contains($0.itemNumber)
        }
        for remoteComponent in remote.components {
            let component: SAPOrderComponent
            if let existing = components.first(where: {
                $0.workOrderID == order.id && $0.itemNumber == remoteComponent.itemNumber
            }) {
                component = existing
            } else {
                component = SAPOrderComponent(
                    workOrderID: order.id,
                    itemNumber: remoteComponent.itemNumber,
                    materialNumber: remoteComponent.materialNumber
                )
                context.insert(component)
                components.append(component)
            }
            component.materialNumber = remoteComponent.materialNumber
            component.descriptionText = remoteComponent.description
            component.requiredQuantity = remoteComponent.requiredQuantity
            component.withdrawnQuantity = remoteComponent.withdrawnQuantity
            component.partID = mappings.first(where: { $0.materialNumber == remoteComponent.materialNumber })?.partID
            component.updatedAt = .now
        }
    }

    private static func apply(
        _ remoteStocks: [SAPRemoteStock],
        configuration: SAPConnectionConfiguration,
        in context: ModelContext
    ) async throws -> Int {
        guard !remoteStocks.isEmpty else { return 0 }
        let mappings = try context.fetch(FetchDescriptor<SAPMaterialMapping>())
        let parts = try context.fetch(FetchDescriptor<SparePart>())
        let movements = try context.fetch(FetchDescriptor<StockMovement>())
        let pendingMovementIDs = Set(
            try context.fetch(FetchDescriptor<SAPSyncQueueItem>())
                .filter { $0.status != .synchronized }
                .map(\.movementID)
        )
        var changed = 0

        for remote in remoteStocks {
            guard let mapping = mappings.first(where: {
                $0.materialNumber == remote.materialNumber &&
                ($0.plant.isEmpty || $0.plant == remote.plant) &&
                ($0.storageLocation.isEmpty || $0.storageLocation == remote.storageLocation)
            }), let part = parts.first(where: { $0.id == mapping.partID }) else { continue }

            mapping.lastSAPStockQuantity = remote.availableQuantity
            mapping.lastStockSyncAt = .now
            mapping.updatedAt = .now
            changed += 1

            let unsynchronizedDelta = movements
                .filter { $0.partID == part.id && pendingMovementIDs.contains($0.id) }
                .reduce(0) { partial, movement in
                    partial + movement.quantity * movement.kind.signedMultiplier
                }
            let effectiveStock = max(0, remote.availableQuantity + unsynchronizedDelta)
            guard configuration.sapStockIsMaster, part.stockQuantity != effectiveStock else { continue }
            let oldStock = part.stockQuantity
            part.stockQuantity = effectiveStock
            part.updatedAt = .now
            context.insert(
                StockMovement(
                    partID: part.id,
                    kind: .reconciliation,
                    quantity: abs(effectiveStock - oldStock),
                    reference: "IH2Go/SAP",
                    notes: "Bestand vor Abgleich: \(oldStock); offener lokaler Saldo: \(unsynchronizedDelta)",
                    stockAfter: effectiveStock,
                    sapMaterialNumber: remote.materialNumber,
                    sapPlant: remote.plant,
                    sapStorageLocation: remote.storageLocation,
                    sapSyncStatus: .synchronized
                )
            )

            let isLow = part.stockQuantity <= part.minimumStock
            if part.reminderEnabled && isLow && !part.lowStockAlerted {
                part.lowStockAlerted = true
                let sent = await LowStockNotificationService.scheduleLowStockReminder(for: part)
                if !sent { part.lowStockAlerted = false }
            } else if !isLow && part.lowStockAlerted {
                part.lowStockAlerted = false
                LowStockNotificationService.removeLowStockReminder(for: part.id)
            }
        }
        try context.save()
        return changed
    }

    private static func equal(_ lhs: String, _ rhs: String) -> Bool {
        lhs.compare(rhs, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame
    }
}

enum SAPMovementCSVExporter {
    static func makeCSV(
        movements: [StockMovement],
        parts: [SparePart],
        materialMappings: [SAPMaterialMapping] = []
    ) -> String {
        let header = [
            "booking_id", "zeitpunkt", "vorgang", "sap_status", "sap_auftrag", "kunde",
            "equipment", "materialnummer", "original_artikelnummer", "barcode", "menge",
            "einheit", "werk", "lagerort", "materialbeleg", "referenz", "notiz"
        ]
        var rows = [header]
        for movement in movements.sorted(by: { $0.timestamp < $1.timestamp }) {
            guard let part = parts.first(where: { $0.id == movement.partID }) else { continue }
            let mapping = materialMappings.first(where: { $0.partID == part.id })
            let sapUnit = mapping?.baseUnit.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            rows.append([
                movement.id.uuidString,
                ISO8601DateFormatter().string(from: movement.timestamp),
                movement.kind.rawValue,
                movement.sapSyncStatus.rawValue,
                movement.sapOrderNumber,
                movement.sapCustomerNumber,
                movement.sapEquipmentNumber,
                movement.sapMaterialNumber,
                part.originalArticleNumber,
                movement.barcodeUsed,
                String(movement.quantity),
                sapUnit.isEmpty ? part.unit : sapUnit,
                movement.sapPlant,
                movement.sapStorageLocation,
                movement.sapMaterialDocument,
                movement.reference,
                movement.notes
            ])
        }
        return "\u{FEFF}" + rows.map { $0.map(CSVCodec.escape).joined(separator: ";") }.joined(separator: "\r\n")
    }
}
