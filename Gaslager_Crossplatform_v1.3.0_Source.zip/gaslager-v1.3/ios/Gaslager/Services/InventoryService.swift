import Foundation
import SwiftData

enum InventoryError: LocalizedError {
    case emptyBarcode
    case invalidQuantity
    case insufficientStock(available: Int)
    case duplicateBarcode
    case barcodeAssignedToAnotherPart
    case duplicateDrawerCode
    case duplicateSAPMaterialNumber
    case missingRequiredFields

    var errorDescription: String? {
        switch self {
        case .emptyBarcode:
            "Der Barcode ist leer."
        case .invalidQuantity:
            "Die Menge muss größer als null sein."
        case .insufficientStock(let available):
            "Der Ausgang ist größer als der verfügbare Bestand (\(available))."
        case .duplicateBarcode:
            "Dieser Barcode ist bereits hinterlegt."
        case .barcodeAssignedToAnotherPart:
            "Dieser Barcode gehört bereits zu einem anderen Ersatzteil."
        case .duplicateDrawerCode:
            "Diese Schubladenbezeichnung ist bereits vorhanden."
        case .duplicateSAPMaterialNumber:
            "Diese SAP-Materialnummer ist bereits einem anderen Ersatzteil zugeordnet."
        case .missingRequiredFields:
            "Bitte alle Pflichtfelder ausfüllen."
        }
    }
}

struct BookingResult {
    let movement: StockMovement
    let syncQueueItem: SAPSyncQueueItem?
    let shouldSendLowStockReminder: Bool
    let shouldRemoveLowStockReminder: Bool
}

struct SAPBookingContext {
    var workOrderID: UUID?
    var orderNumber: String
    var customerNumber: String
    var equipmentNumber: String
    var materialNumber: String
    var plant: String
    var storageLocation: String
    var syncRequested: Bool

    static let localOnly = SAPBookingContext(
        workOrderID: nil,
        orderNumber: "",
        customerNumber: "",
        equipmentNumber: "",
        materialNumber: "",
        plant: "",
        storageLocation: "",
        syncRequested: false
    )
}

struct PartRegistrationInput {
    var barcode: String
    var symbology: String
    var manufacturer: String
    var originalArticleNumber: String
    var partName: String
    var unit: String
    var drawerID: UUID?
    var equipmentTypeID: UUID?
    var deviceSparePartNumber: String
    var initialQuantity: Int
    var minimumStock: Int
    var reminderEnabled: Bool
    var notes: String
    var sapMaterialNumber: String
    var sapPlant: String
    var sapStorageLocation: String
    var sapBaseUnit: String
    var sapSyncRequested: Bool
}

struct PartRegistrationResult {
    let part: SparePart
    let wasExistingPart: Bool
    let shouldSendLowStockReminder: Bool
}

@MainActor
enum InventoryService {
    static func resolvePart(for rawBarcode: String, in context: ModelContext) throws -> SparePart? {
        let matchKey = BarcodeNormalizer.matchKey(for: rawBarcode)
        guard !matchKey.isEmpty else { throw InventoryError.emptyBarcode }

        var barcodeDescriptor = FetchDescriptor<PartBarcode>(
            predicate: #Predicate<PartBarcode> { barcode in
                barcode.matchKey == matchKey
            }
        )
        barcodeDescriptor.fetchLimit = 1

        guard let barcode = try context.fetch(barcodeDescriptor).first else { return nil }
        let partID = barcode.partID
        var partDescriptor = FetchDescriptor<SparePart>(
            predicate: #Predicate<SparePart> { part in
                part.id == partID
            }
        )
        partDescriptor.fetchLimit = 1
        return try context.fetch(partDescriptor).first
    }

    static func performMovement(
        for part: SparePart,
        kind: MovementKind,
        quantity: Int,
        reference: String,
        notes: String,
        barcodeUsed: String,
        sapContext: SAPBookingContext = .localOnly,
        in context: ModelContext
    ) throws -> BookingResult {
        guard quantity > 0 else { throw InventoryError.invalidQuantity }

        let oldStock = part.stockQuantity
        let newStock = oldStock + (quantity * kind.signedMultiplier)
        guard newStock >= 0 else {
            throw InventoryError.insufficientStock(available: oldStock)
        }

        let isLowAfterBooking = newStock <= part.minimumStock
        let shouldNotify = part.reminderEnabled && isLowAfterBooking && !part.lowStockAlerted
        let shouldRemove = !isLowAfterBooking && part.lowStockAlerted

        part.stockQuantity = newStock
        part.lowStockAlerted = part.reminderEnabled && isLowAfterBooking
        part.updatedAt = .now

        let syncStatus: SAPSyncStatus
        if sapContext.syncRequested {
            syncStatus = sapContext.materialNumber.isEmpty ? .mappingRequired : .pending
        } else {
            syncStatus = .notRequired
        }

        let cleanedReference = reference.trimmingCharacters(in: .whitespacesAndNewlines)
        let movement = StockMovement(
            partID: part.id,
            kind: kind,
            quantity: quantity,
            reference: cleanedReference.isEmpty ? sapContext.orderNumber : cleanedReference,
            notes: notes.trimmingCharacters(in: .whitespacesAndNewlines),
            stockAfter: newStock,
            barcodeUsed: barcodeUsed,
            sapWorkOrderID: sapContext.workOrderID,
            sapOrderNumber: sapContext.orderNumber,
            sapCustomerNumber: sapContext.customerNumber,
            sapEquipmentNumber: sapContext.equipmentNumber,
            sapMaterialNumber: sapContext.materialNumber,
            sapPlant: sapContext.plant,
            sapStorageLocation: sapContext.storageLocation,
            sapSyncStatus: syncStatus
        )
        context.insert(movement)

        var queueItem: SAPSyncQueueItem?
        if sapContext.syncRequested && (kind == .inbound || kind == .outbound) {
            let item = SAPSyncQueueItem(
                movementID: movement.id,
                operation: kind == .outbound ? .goodsIssue : .goodsReceipt,
                status: syncStatus
            )
            context.insert(item)
            queueItem = item
        }

        var updatedComponent: SAPOrderComponent?
        var previousWithdrawnQuantity: Int?
        if kind == .outbound, let workOrderID = sapContext.workOrderID {
            let components = try context.fetch(FetchDescriptor<SAPOrderComponent>())
            if let component = components.first(where: {
                $0.workOrderID == workOrderID &&
                ($0.partID == part.id || (!$0.materialNumber.isEmpty && $0.materialNumber == sapContext.materialNumber))
            }) {
                updatedComponent = component
                previousWithdrawnQuantity = component.withdrawnQuantity
                component.withdrawnQuantity += quantity
                component.updatedAt = .now
            }
        }

        do {
            try context.save()
        } catch {
            part.stockQuantity = oldStock
            if let updatedComponent, let previousWithdrawnQuantity {
                updatedComponent.withdrawnQuantity = previousWithdrawnQuantity
            }
            context.delete(movement)
            if let queueItem { context.delete(queueItem) }
            throw error
        }

        return BookingResult(
            movement: movement,
            syncQueueItem: queueItem,
            shouldSendLowStockReminder: shouldNotify,
            shouldRemoveLowStockReminder: shouldRemove
        )
    }

    static func registerPart(
        _ input: PartRegistrationInput,
        in context: ModelContext
    ) throws -> PartRegistrationResult {
        let barcodeValue = input.barcode.trimmingCharacters(in: .whitespacesAndNewlines)
        let matchKey = BarcodeNormalizer.matchKey(for: barcodeValue)
        let manufacturer = input.manufacturer.trimmingCharacters(in: .whitespacesAndNewlines)
        let articleNumber = input.originalArticleNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        let partName = input.partName.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !matchKey.isEmpty else { throw InventoryError.emptyBarcode }
        guard !manufacturer.isEmpty, !articleNumber.isEmpty, !partName.isEmpty else {
            throw InventoryError.missingRequiredFields
        }
        guard input.initialQuantity >= 0, input.minimumStock >= 0 else {
            throw InventoryError.invalidQuantity
        }

        if try resolvePart(for: barcodeValue, in: context) != nil {
            throw InventoryError.duplicateBarcode
        }

        let allParts = try context.fetch(FetchDescriptor<SparePart>())
        let existingPart = allParts.first {
            $0.manufacturer.compare(manufacturer, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame &&
            $0.originalArticleNumber.compare(articleNumber, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame
        }
        let sapMaterialNumber = input.sapMaterialNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        let existingMappings = try context.fetch(FetchDescriptor<SAPMaterialMapping>())
        if !sapMaterialNumber.isEmpty,
           existingMappings.contains(where: {
               $0.partID != existingPart?.id &&
               $0.materialNumber.compare(sapMaterialNumber, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame
           }) {
            throw InventoryError.duplicateSAPMaterialNumber
        }

        let part: SparePart
        let wasExistingPart = existingPart != nil
        if let existingPart {
            part = existingPart
            if part.drawerID == nil { part.drawerID = input.drawerID }
            part.updatedAt = .now
        } else {
            part = SparePart(
                manufacturer: manufacturer,
                originalArticleNumber: articleNumber,
                partName: partName,
                unit: input.unit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Stück" : input.unit,
                drawerID: input.drawerID,
                stockQuantity: 0,
                minimumStock: input.minimumStock,
                reminderEnabled: input.reminderEnabled,
                notes: input.notes.trimmingCharacters(in: .whitespacesAndNewlines)
            )
            context.insert(part)
        }

        let existingBarcodes = try context.fetch(FetchDescriptor<PartBarcode>())
        let isFirstBarcode = !existingBarcodes.contains(where: { $0.partID == part.id })
        context.insert(
            PartBarcode(
                value: barcodeValue,
                matchKey: matchKey,
                symbology: input.symbology,
                partID: part.id,
                isPrimary: isFirstBarcode
            )
        )

        if let equipmentTypeID = input.equipmentTypeID {
            let sparePartNumber = input.deviceSparePartNumber.trimmingCharacters(in: .whitespacesAndNewlines)
            let compatibilities = try context.fetch(FetchDescriptor<PartCompatibility>())
            let alreadyAssigned = compatibilities.contains {
                $0.partID == part.id &&
                $0.equipmentTypeID == equipmentTypeID &&
                $0.deviceSparePartNumber.compare(sparePartNumber, options: [.caseInsensitive]) == .orderedSame
            }
            if !alreadyAssigned {
                context.insert(
                    PartCompatibility(
                        partID: part.id,
                        equipmentTypeID: equipmentTypeID,
                        deviceSparePartNumber: sparePartNumber
                    )
                )
            }
        }

        if !sapMaterialNumber.isEmpty {
            if let mapping = existingMappings.first(where: { $0.partID == part.id }) {
                mapping.materialNumber = sapMaterialNumber
                mapping.plant = input.sapPlant.trimmingCharacters(in: .whitespacesAndNewlines)
                mapping.storageLocation = input.sapStorageLocation.trimmingCharacters(in: .whitespacesAndNewlines)
                mapping.baseUnit = input.sapBaseUnit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "ST" : input.sapBaseUnit
                mapping.updatedAt = .now
            } else {
                context.insert(
                    SAPMaterialMapping(
                        partID: part.id,
                        materialNumber: sapMaterialNumber,
                        plant: input.sapPlant.trimmingCharacters(in: .whitespacesAndNewlines),
                        storageLocation: input.sapStorageLocation.trimmingCharacters(in: .whitespacesAndNewlines),
                        baseUnit: input.sapBaseUnit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "ST" : input.sapBaseUnit
                    )
                )
            }
        }

        if input.initialQuantity > 0 {
            part.stockQuantity += input.initialQuantity
            let syncStatus: SAPSyncStatus = input.sapSyncRequested
                ? (sapMaterialNumber.isEmpty ? .mappingRequired : .pending)
                : .notRequired
            let movement = StockMovement(
                partID: part.id,
                kind: .inbound,
                quantity: input.initialQuantity,
                reference: "Erstanlage",
                stockAfter: part.stockQuantity,
                barcodeUsed: barcodeValue,
                sapMaterialNumber: sapMaterialNumber,
                sapPlant: input.sapPlant.trimmingCharacters(in: .whitespacesAndNewlines),
                sapStorageLocation: input.sapStorageLocation.trimmingCharacters(in: .whitespacesAndNewlines),
                sapSyncStatus: syncStatus
            )
            context.insert(movement)
            if input.sapSyncRequested {
                context.insert(
                    SAPSyncQueueItem(
                        movementID: movement.id,
                        operation: .goodsReceipt,
                        status: syncStatus
                    )
                )
            }
        }

        let shouldNotify = part.reminderEnabled && part.stockQuantity <= part.minimumStock
        part.lowStockAlerted = shouldNotify
        try context.save()

        return PartRegistrationResult(
            part: part,
            wasExistingPart: wasExistingPart,
            shouldSendLowStockReminder: shouldNotify
        )
    }
}
