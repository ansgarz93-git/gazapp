import Foundation
import SwiftData

enum EquipmentKind: String, Codable, CaseIterable, Identifiable {
    case regulator = "Gasdruckregler"
    case pilot = "Pilot"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .regulator: "gauge.with.dots.needle.50percent"
        case .pilot: "slider.horizontal.3"
        }
    }
}

enum MovementKind: String, Codable, CaseIterable, Identifiable {
    case inbound = "Eingang"
    case outbound = "Ausgang"
    case openingBalance = "Bestandsübernahme"
    case reconciliation = "SAP-Bestandsabgleich"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .inbound, .openingBalance: "arrow.down.circle.fill"
        case .outbound: "arrow.up.circle.fill"
        case .reconciliation: "arrow.triangle.2.circlepath.circle.fill"
        }
    }

    var signedMultiplier: Int {
        switch self {
        case .inbound, .openingBalance: 1
        case .outbound: -1
        case .reconciliation: 0
        }
    }

    static let bookableCases: [MovementKind] = [.inbound, .outbound]
}

enum TechnicalDocumentKind: String, Codable, CaseIterable, Identifiable {
    case manufacturerPage = "Herstellerseite"
    case brochure = "Broschüre"
    case operatingInstructions = "Betriebsanleitung"
    case maintenanceAndSpareParts = "Wartung / Ersatzteilliste"
    case drawing = "Zeichnung"
    case certificate = "Zertifikat"
    case other = "Sonstiges"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .manufacturerPage: "link.circle.fill"
        case .brochure: "book.closed.fill"
        case .operatingInstructions: "text.book.closed.fill"
        case .maintenanceAndSpareParts: "wrench.and.screwdriver.fill"
        case .drawing: "ruler.fill"
        case .certificate: "checkmark.seal.fill"
        case .other: "doc.fill"
        }
    }
}

@Model
final class EquipmentType {
    @Attribute(.unique) var id: UUID
    var manufacturer: String
    var designation: String
    var kindRawValue: String
    var notes: String
    var createdAt: Date

    init(
        id: UUID = UUID(),
        manufacturer: String,
        designation: String,
        kind: EquipmentKind,
        notes: String = "",
        createdAt: Date = .now
    ) {
        self.id = id
        self.manufacturer = manufacturer
        self.designation = designation
        self.kindRawValue = kind.rawValue
        self.notes = notes
        self.createdAt = createdAt
    }

    var kind: EquipmentKind {
        get { EquipmentKind(rawValue: kindRawValue) ?? .regulator }
        set { kindRawValue = newValue.rawValue }
    }

    var displayName: String {
        "\(manufacturer) \(designation)"
    }
}

@Model
final class Drawer {
    @Attribute(.unique) var id: UUID
    @Attribute(.unique) var code: String
    var location: String
    var equipmentTypeID: UUID
    var notes: String
    var createdAt: Date

    init(
        id: UUID = UUID(),
        code: String,
        location: String = "",
        equipmentTypeID: UUID,
        notes: String = "",
        createdAt: Date = .now
    ) {
        self.id = id
        self.code = code
        self.location = location
        self.equipmentTypeID = equipmentTypeID
        self.notes = notes
        self.createdAt = createdAt
    }

    var displayName: String {
        location.isEmpty ? code : "\(code) · \(location)"
    }
}

@Model
final class SparePart {
    @Attribute(.unique) var id: UUID
    var manufacturer: String
    var originalArticleNumber: String
    var partName: String
    var unit: String
    var drawerID: UUID?
    var stockQuantity: Int
    var minimumStock: Int
    var reminderEnabled: Bool
    var lowStockAlerted: Bool
    var notes: String
    var isArchived: Bool
    var createdAt: Date
    var updatedAt: Date

    init(
        id: UUID = UUID(),
        manufacturer: String,
        originalArticleNumber: String,
        partName: String,
        unit: String = "Stück",
        drawerID: UUID? = nil,
        stockQuantity: Int = 0,
        minimumStock: Int = 0,
        reminderEnabled: Bool = false,
        lowStockAlerted: Bool = false,
        notes: String = "",
        isArchived: Bool = false,
        createdAt: Date = .now,
        updatedAt: Date = .now
    ) {
        self.id = id
        self.manufacturer = manufacturer
        self.originalArticleNumber = originalArticleNumber
        self.partName = partName
        self.unit = unit
        self.drawerID = drawerID
        self.stockQuantity = stockQuantity
        self.minimumStock = minimumStock
        self.reminderEnabled = reminderEnabled
        self.lowStockAlerted = lowStockAlerted
        self.notes = notes
        self.isArchived = isArchived
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }

    var isLowStock: Bool {
        stockQuantity <= minimumStock
    }
}

@Model
final class PartBarcode {
    @Attribute(.unique) var id: UUID
    var value: String
    @Attribute(.unique) var matchKey: String
    var symbology: String
    var partID: UUID
    var isPrimary: Bool
    var createdAt: Date

    init(
        id: UUID = UUID(),
        value: String,
        matchKey: String,
        symbology: String = "",
        partID: UUID,
        isPrimary: Bool = true,
        createdAt: Date = .now
    ) {
        self.id = id
        self.value = value
        self.matchKey = matchKey
        self.symbology = symbology
        self.partID = partID
        self.isPrimary = isPrimary
        self.createdAt = createdAt
    }
}

@Model
final class PartCompatibility {
    @Attribute(.unique) var id: UUID
    var partID: UUID
    var equipmentTypeID: UUID
    var deviceSparePartNumber: String
    var notes: String

    init(
        id: UUID = UUID(),
        partID: UUID,
        equipmentTypeID: UUID,
        deviceSparePartNumber: String,
        notes: String = ""
    ) {
        self.id = id
        self.partID = partID
        self.equipmentTypeID = equipmentTypeID
        self.deviceSparePartNumber = deviceSparePartNumber
        self.notes = notes
    }
}

@Model
final class StockMovement {
    @Attribute(.unique) var id: UUID
    var partID: UUID
    var kindRawValue: String
    var quantity: Int
    var timestamp: Date
    var reference: String
    var notes: String
    var stockAfter: Int
    var barcodeUsed: String
    var sapWorkOrderID: UUID?
    var sapOrderNumber: String = ""
    var sapCustomerNumber: String = ""
    var sapEquipmentNumber: String = ""
    var sapMaterialNumber: String = ""
    var sapPlant: String = ""
    var sapStorageLocation: String = ""
    var sapSyncStatusRawValue: String = "Nicht erforderlich"
    var sapMaterialDocument: String = ""
    var sapSyncMessage: String = ""

    init(
        id: UUID = UUID(),
        partID: UUID,
        kind: MovementKind,
        quantity: Int,
        timestamp: Date = .now,
        reference: String = "",
        notes: String = "",
        stockAfter: Int,
        barcodeUsed: String = "",
        sapWorkOrderID: UUID? = nil,
        sapOrderNumber: String = "",
        sapCustomerNumber: String = "",
        sapEquipmentNumber: String = "",
        sapMaterialNumber: String = "",
        sapPlant: String = "",
        sapStorageLocation: String = "",
        sapSyncStatus: SAPSyncStatus = .notRequired,
        sapMaterialDocument: String = "",
        sapSyncMessage: String = ""
    ) {
        self.id = id
        self.partID = partID
        self.kindRawValue = kind.rawValue
        self.quantity = quantity
        self.timestamp = timestamp
        self.reference = reference
        self.notes = notes
        self.stockAfter = stockAfter
        self.barcodeUsed = barcodeUsed
        self.sapWorkOrderID = sapWorkOrderID
        self.sapOrderNumber = sapOrderNumber
        self.sapCustomerNumber = sapCustomerNumber
        self.sapEquipmentNumber = sapEquipmentNumber
        self.sapMaterialNumber = sapMaterialNumber
        self.sapPlant = sapPlant
        self.sapStorageLocation = sapStorageLocation
        self.sapSyncStatusRawValue = sapSyncStatus.rawValue
        self.sapMaterialDocument = sapMaterialDocument
        self.sapSyncMessage = sapSyncMessage
    }

    var kind: MovementKind {
        get { MovementKind(rawValue: kindRawValue) ?? .inbound }
        set { kindRawValue = newValue.rawValue }
    }

    var sapSyncStatus: SAPSyncStatus {
        get { SAPSyncStatus(rawValue: sapSyncStatusRawValue) ?? .notRequired }
        set { sapSyncStatusRawValue = newValue.rawValue }
    }
}

@Model
final class TechnicalDocument {
    @Attribute(.unique) var id: UUID
    var equipmentTypeID: UUID
    var title: String
    var kindRawValue: String
    var sourceURL: String
    var localFileName: String
    var isOfficialManufacturerSource: Bool
    var addedAt: Date

    init(
        id: UUID = UUID(),
        equipmentTypeID: UUID,
        title: String,
        kind: TechnicalDocumentKind,
        sourceURL: String = "",
        localFileName: String = "",
        isOfficialManufacturerSource: Bool = false,
        addedAt: Date = .now
    ) {
        self.id = id
        self.equipmentTypeID = equipmentTypeID
        self.title = title
        self.kindRawValue = kind.rawValue
        self.sourceURL = sourceURL
        self.localFileName = localFileName
        self.isOfficialManufacturerSource = isOfficialManufacturerSource
        self.addedAt = addedAt
    }

    var kind: TechnicalDocumentKind {
        get { TechnicalDocumentKind(rawValue: kindRawValue) ?? .other }
        set { kindRawValue = newValue.rawValue }
    }

    var isLocal: Bool { !localFileName.isEmpty }
}
