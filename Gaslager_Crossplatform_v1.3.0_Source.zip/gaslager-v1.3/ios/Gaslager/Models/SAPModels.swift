import Foundation
import SwiftData

enum SAPWorkOrderStatus: String, Codable, CaseIterable, Identifiable {
    case open = "Offen"
    case released = "Freigegeben"
    case inProgress = "In Bearbeitung"
    case technicallyCompleted = "Technisch abgeschlossen"
    case completed = "Abgeschlossen"
    case unknown = "Unbekannt"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .open: "circle"
        case .released: "checkmark.seal"
        case .inProgress: "wrench.and.screwdriver.fill"
        case .technicallyCompleted, .completed: "checkmark.circle.fill"
        case .unknown: "questionmark.circle"
        }
    }

    static func fromRemoteValue(_ value: String) -> SAPWorkOrderStatus {
        let normalized = value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
            .replacingOccurrences(of: "_", with: "")
            .replacingOccurrences(of: "-", with: "")
            .replacingOccurrences(of: " ", with: "")

        switch normalized {
        case "open", "offen", "created", "crtd": .open
        case "released", "freigegeben", "rel": .released
        case "inprogress", "inbearbeitung", "pcnf": .inProgress
        case "technicallycompleted", "technischabgeschlossen", "teco": .technicallyCompleted
        case "completed", "abgeschlossen", "closed", "clsd": .completed
        default: .unknown
        }
    }
}

enum SAPSyncStatus: String, Codable, CaseIterable, Identifiable {
    case notRequired = "Nicht erforderlich"
    case pending = "Ausstehend"
    case syncing = "Wird übertragen"
    case synchronized = "Synchronisiert"
    case mappingRequired = "Materialzuordnung fehlt"
    case failed = "Fehlgeschlagen"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .notRequired: "minus.circle"
        case .pending: "clock.badge"
        case .syncing: "arrow.triangle.2.circlepath"
        case .synchronized: "checkmark.icloud.fill"
        case .mappingRequired: "link.badge.plus"
        case .failed: "exclamationmark.icloud.fill"
        }
    }
}

enum SAPQueueOperation: String, Codable {
    case goodsIssue = "WARENAUSGANG"
    case goodsReceipt = "WARENEINGANG"
}

@Model
final class SAPWorkOrder {
    @Attribute(.unique) var id: UUID
    @Attribute(.unique) var orderNumber: String
    var customerNumber: String
    var customerName: String
    var equipmentNumber: String
    var functionalLocation: String
    var equipmentTypeID: UUID?
    var shortText: String
    var statusRawValue: String
    var plannedStart: Date?
    var plant: String
    var storageLocation: String
    var sourceSystem: String
    var lastSyncedAt: Date?
    var updatedAt: Date

    init(
        id: UUID = UUID(),
        orderNumber: String,
        customerNumber: String = "",
        customerName: String,
        equipmentNumber: String = "",
        functionalLocation: String = "",
        equipmentTypeID: UUID? = nil,
        shortText: String = "",
        status: SAPWorkOrderStatus = .open,
        plannedStart: Date? = nil,
        plant: String = "",
        storageLocation: String = "",
        sourceSystem: String = "IH2Go / SAP",
        lastSyncedAt: Date? = nil,
        updatedAt: Date = .now
    ) {
        self.id = id
        self.orderNumber = orderNumber
        self.customerNumber = customerNumber
        self.customerName = customerName
        self.equipmentNumber = equipmentNumber
        self.functionalLocation = functionalLocation
        self.equipmentTypeID = equipmentTypeID
        self.shortText = shortText
        self.statusRawValue = status.rawValue
        self.plannedStart = plannedStart
        self.plant = plant
        self.storageLocation = storageLocation
        self.sourceSystem = sourceSystem
        self.lastSyncedAt = lastSyncedAt
        self.updatedAt = updatedAt
    }

    var status: SAPWorkOrderStatus {
        get { SAPWorkOrderStatus(rawValue: statusRawValue) ?? .unknown }
        set { statusRawValue = newValue.rawValue }
    }

    var customerDisplayName: String {
        if customerName.isEmpty { return customerNumber.isEmpty ? "Kunde nicht hinterlegt" : customerNumber }
        return customerNumber.isEmpty ? customerName : "\(customerName) · \(customerNumber)"
    }

    var isClosed: Bool {
        status == .completed || status == .technicallyCompleted
    }
}

@Model
final class SAPOrderComponent {
    @Attribute(.unique) var id: UUID
    var workOrderID: UUID
    var itemNumber: String
    var materialNumber: String
    var descriptionText: String
    var requiredQuantity: Int
    var withdrawnQuantity: Int
    var partID: UUID?
    var updatedAt: Date

    init(
        id: UUID = UUID(),
        workOrderID: UUID,
        itemNumber: String,
        materialNumber: String,
        descriptionText: String = "",
        requiredQuantity: Int = 0,
        withdrawnQuantity: Int = 0,
        partID: UUID? = nil,
        updatedAt: Date = .now
    ) {
        self.id = id
        self.workOrderID = workOrderID
        self.itemNumber = itemNumber
        self.materialNumber = materialNumber
        self.descriptionText = descriptionText
        self.requiredQuantity = requiredQuantity
        self.withdrawnQuantity = withdrawnQuantity
        self.partID = partID
        self.updatedAt = updatedAt
    }

    var remainingQuantity: Int {
        max(0, requiredQuantity - withdrawnQuantity)
    }
}

@Model
final class SAPMaterialMapping {
    @Attribute(.unique) var id: UUID
    var partID: UUID
    var materialNumber: String
    var plant: String
    var storageLocation: String
    var baseUnit: String
    var lastSAPStockQuantity: Int?
    var lastStockSyncAt: Date?
    var updatedAt: Date

    init(
        id: UUID = UUID(),
        partID: UUID,
        materialNumber: String,
        plant: String = "",
        storageLocation: String = "",
        baseUnit: String = "ST",
        lastSAPStockQuantity: Int? = nil,
        lastStockSyncAt: Date? = nil,
        updatedAt: Date = .now
    ) {
        self.id = id
        self.partID = partID
        self.materialNumber = materialNumber
        self.plant = plant
        self.storageLocation = storageLocation
        self.baseUnit = baseUnit
        self.lastSAPStockQuantity = lastSAPStockQuantity
        self.lastStockSyncAt = lastStockSyncAt
        self.updatedAt = updatedAt
    }
}

@Model
final class SAPSyncQueueItem {
    @Attribute(.unique) var id: UUID
    @Attribute(.unique) var movementID: UUID
    var operationRawValue: String
    var statusRawValue: String
    var idempotencyKey: String
    var attempts: Int
    var createdAt: Date
    var lastAttemptAt: Date?
    var lastError: String
    var sapDocumentNumber: String

    init(
        id: UUID = UUID(),
        movementID: UUID,
        operation: SAPQueueOperation,
        status: SAPSyncStatus,
        idempotencyKey: String = UUID().uuidString,
        attempts: Int = 0,
        createdAt: Date = .now,
        lastAttemptAt: Date? = nil,
        lastError: String = "",
        sapDocumentNumber: String = ""
    ) {
        self.id = id
        self.movementID = movementID
        self.operationRawValue = operation.rawValue
        self.statusRawValue = status.rawValue
        self.idempotencyKey = idempotencyKey
        self.attempts = attempts
        self.createdAt = createdAt
        self.lastAttemptAt = lastAttemptAt
        self.lastError = lastError
        self.sapDocumentNumber = sapDocumentNumber
    }

    var operation: SAPQueueOperation {
        get { SAPQueueOperation(rawValue: operationRawValue) ?? .goodsIssue }
        set { operationRawValue = newValue.rawValue }
    }

    var status: SAPSyncStatus {
        get { SAPSyncStatus(rawValue: statusRawValue) ?? .pending }
        set { statusRawValue = newValue.rawValue }
    }
}

struct SAPRemoteWorkOrder: Codable, Identifiable {
    var id: String { orderNumber }
    let orderNumber: String
    let customerNumber: String
    let customerName: String
    let equipmentNumber: String
    let functionalLocation: String
    let equipmentManufacturer: String
    let equipmentType: String
    let equipmentKind: String
    let shortText: String
    let status: String
    let plannedStart: Date?
    let plant: String
    let storageLocation: String
    let components: [SAPRemoteOrderComponent]

    enum CodingKeys: String, CodingKey {
        case orderNumber = "order_number"
        case customerNumber = "customer_number"
        case customerName = "customer_name"
        case equipmentNumber = "equipment_number"
        case functionalLocation = "functional_location"
        case equipmentManufacturer = "equipment_manufacturer"
        case equipmentType = "equipment_type"
        case equipmentKind = "equipment_kind"
        case shortText = "short_text"
        case status
        case plannedStart = "planned_start"
        case plant
        case storageLocation = "storage_location"
        case components
    }
}

struct SAPRemoteOrderComponent: Codable {
    let itemNumber: String
    let materialNumber: String
    let description: String
    let requiredQuantity: Int
    let withdrawnQuantity: Int

    enum CodingKeys: String, CodingKey {
        case itemNumber = "item_number"
        case materialNumber = "material_number"
        case description
        case requiredQuantity = "required_quantity"
        case withdrawnQuantity = "withdrawn_quantity"
    }
}

struct SAPRemoteStock: Codable {
    let materialNumber: String
    let plant: String
    let storageLocation: String
    let availableQuantity: Int

    enum CodingKeys: String, CodingKey {
        case materialNumber = "material_number"
        case plant
        case storageLocation = "storage_location"
        case availableQuantity = "available_quantity"
    }
}

struct SAPMovementReceipt: Codable {
    let accepted: Bool
    let materialDocument: String?
    let message: String?

    enum CodingKeys: String, CodingKey {
        case accepted
        case materialDocument = "material_document"
        case message
    }
}
