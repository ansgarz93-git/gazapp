import SwiftUI
import SwiftData
import UniformTypeIdentifiers

struct InventoryListView: View {
    @Query(sort: \SparePart.partName) private var parts: [SparePart]
    @Query(sort: \PartBarcode.value) private var barcodes: [PartBarcode]
    @Query(sort: \Drawer.code) private var drawers: [Drawer]
    @State private var searchText = ""
    @State private var addPartPresented = false

    private var filteredParts: [SparePart] {
        let active = parts.filter { !$0.isArchived }
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return active }

        let matchingPartIDs = Set(
            barcodes.filter { $0.value.localizedCaseInsensitiveContains(query) }.map(\.partID)
        )
        return active.filter {
            $0.partName.localizedCaseInsensitiveContains(query) ||
            $0.manufacturer.localizedCaseInsensitiveContains(query) ||
            $0.originalArticleNumber.localizedCaseInsensitiveContains(query) ||
            matchingPartIDs.contains($0.id)
        }
    }

    var body: some View {
        Group {
            if parts.filter({ !$0.isArchived }).isEmpty {
                ContentUnavailableView {
                    Label("Noch keine Ersatzteile", systemImage: "shippingbox")
                } description: {
                    Text("Scanne den ersten Original-Barcode oder importiere den Teilekatalog als CSV.")
                } actions: {
                    Button("Ersatzteil anlegen") { addPartPresented = true }
                        .buttonStyle(.borderedProminent)
                }
            } else {
                List(filteredParts) { part in
                    NavigationLink {
                        PartDetailView(part: part)
                    } label: {
                        PartRow(part: part, drawerCode: drawerCode(for: part))
                    }
                }
                .overlay {
                    if filteredParts.isEmpty {
                        ContentUnavailableView.search(text: searchText)
                    }
                }
            }
        }
        .navigationTitle("Ersatzteile")
        .searchable(text: $searchText, prompt: "Bezeichnung, Art.-Nr. oder Barcode")
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                NavigationLink {
                    BarcodeMasterListView()
                } label: {
                    Image(systemName: "barcode")
                }
                .accessibilityLabel("Barcode-Liste")
            }
            ToolbarItem(placement: .primaryAction) {
                Button {
                    addPartPresented = true
                } label: {
                    Image(systemName: "plus")
                }
                .accessibilityLabel("Ersatzteil anlegen")
            }
        }
        .sheet(isPresented: $addPartPresented) {
            PartRegistrationView(initialBarcode: "")
        }
    }

    private func drawerCode(for part: SparePart) -> String? {
        guard let drawerID = part.drawerID else { return nil }
        return drawers.first(where: { $0.id == drawerID })?.code
    }
}

struct BarcodeMasterListView: View {
    @Query(sort: \PartBarcode.value) private var barcodes: [PartBarcode]
    @Query private var parts: [SparePart]
    @Query private var drawers: [Drawer]
    @Query private var equipmentTypes: [EquipmentType]
    @Query private var compatibilities: [PartCompatibility]
    @Query private var materialMappings: [SAPMaterialMapping]

    @State private var searchText = ""
    @State private var exportDocument = CSVTextDocument()
    @State private var exporterPresented = false
    @State private var errorMessage: String?

    private var filteredBarcodes: [PartBarcode] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return barcodes }
        return barcodes.filter { barcode in
            guard let part = part(for: barcode) else {
                return barcode.value.localizedCaseInsensitiveContains(query)
            }
            return barcode.value.localizedCaseInsensitiveContains(query) ||
                barcode.symbology.localizedCaseInsensitiveContains(query) ||
                part.originalArticleNumber.localizedCaseInsensitiveContains(query) ||
                part.partName.localizedCaseInsensitiveContains(query) ||
                part.manufacturer.localizedCaseInsensitiveContains(query) ||
                (materialMappings.first(where: { $0.partID == part.id })?
                    .materialNumber.localizedCaseInsensitiveContains(query) ?? false)
        }
    }

    var body: some View {
        Group {
            if barcodes.isEmpty {
                ContentUnavailableView(
                    "Noch keine Barcodes",
                    systemImage: "barcode",
                    description: Text("Barcodes werden beim Scannen oder CSV-Import in diese Liste aufgenommen.")
                )
            } else {
                List(filteredBarcodes) { barcode in
                    if let part = part(for: barcode) {
                        NavigationLink {
                            PartDetailView(part: part)
                        } label: {
                            VStack(alignment: .leading, spacing: 7) {
                                HStack(alignment: .firstTextBaseline) {
                                    Text(barcode.value)
                                        .font(.body.monospaced().weight(.semibold))
                                        .lineLimit(2)
                                    Spacer()
                                    if barcode.isPrimary {
                                        Text("Hauptcode")
                                            .font(.caption2.weight(.semibold))
                                            .padding(.horizontal, 7)
                                            .padding(.vertical, 3)
                                            .background(Color.blue.opacity(0.12), in: Capsule())
                                    }
                                }
                                Text("\(part.manufacturer) · \(part.originalArticleNumber) · \(part.partName)")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(2)
                                HStack(spacing: 8) {
                                    if !barcode.symbology.isEmpty {
                                        Label(barcode.symbology, systemImage: "barcode.viewfinder")
                                    }
                                    if let drawer = drawer(for: part) {
                                        Label(drawer.code, systemImage: "cabinet.fill")
                                    }
                                    if let material = materialMappings.first(where: { $0.partID == part.id }) {
                                        Label(material.materialNumber, systemImage: "link")
                                    }
                                }
                                .font(.caption)
                                .foregroundStyle(.secondary)

                                let assignments = assignmentLabels(for: part)
                                if !assignments.isEmpty {
                                    Text(assignments.joined(separator: " · "))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(3)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
                .overlay {
                    if filteredBarcodes.isEmpty {
                        ContentUnavailableView.search(text: searchText)
                    }
                }
            }
        }
        .navigationTitle("Barcode-Liste")
        .searchable(text: $searchText, prompt: "Code, Artikel oder Bezeichnung")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button(action: export) {
                    Image(systemName: "square.and.arrow.up")
                }
                .accessibilityLabel("Barcode-Liste als CSV exportieren")
                .disabled(barcodes.isEmpty)
            }
        }
        .fileExporter(
            isPresented: $exporterPresented,
            document: exportDocument,
            contentType: .commaSeparatedText,
            defaultFilename: "Gaslager_Barcodes"
        ) { result in
            if case .failure(let error) = result {
                errorMessage = error.localizedDescription
            }
        }
        .alert("Export fehlgeschlagen", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "Unbekannter Fehler")
        }
    }

    private func part(for barcode: PartBarcode) -> SparePart? {
        parts.first(where: { $0.id == barcode.partID })
    }

    private func drawer(for part: SparePart) -> Drawer? {
        guard let drawerID = part.drawerID else { return nil }
        return drawers.first(where: { $0.id == drawerID })
    }

    private func assignmentLabels(for part: SparePart) -> [String] {
        compatibilities
            .filter { $0.partID == part.id }
            .compactMap { assignment in
                guard let equipment = equipmentTypes.first(where: { $0.id == assignment.equipmentTypeID }) else {
                    return nil
                }
                return "\(equipment.designation): \(assignment.deviceSparePartNumber)"
            }
    }

    private func export() {
        exportDocument = CSVTextDocument(
            text: BarcodeListCSVExporter.makeCSV(
                parts: parts,
                barcodes: barcodes,
                drawers: drawers,
                equipmentTypes: equipmentTypes,
                compatibilities: compatibilities,
                materialMappings: materialMappings
            )
        )
        exporterPresented = true
    }
}

struct PartDetailView: View {
    let part: SparePart
    @Query private var barcodes: [PartBarcode]
    @Query private var compatibilities: [PartCompatibility]
    @Query private var movements: [StockMovement]
    @Query(sort: \EquipmentType.designation) private var equipmentTypes: [EquipmentType]
    @Query(sort: \Drawer.code) private var drawers: [Drawer]
    @Query private var materialMappings: [SAPMaterialMapping]

    @State private var bookingKind: IdentifiableMovementKind?
    @State private var editPresented = false
    @State private var addCompatibilityPresented = false
    @State private var sapMappingPresented = false

    init(part: SparePart) {
        self.part = part
        let partID = part.id
        _barcodes = Query(
            filter: #Predicate<PartBarcode> { $0.partID == partID },
            sort: \PartBarcode.value
        )
        _compatibilities = Query(
            filter: #Predicate<PartCompatibility> { $0.partID == partID },
            sort: \PartCompatibility.deviceSparePartNumber
        )
        _movements = Query(
            filter: #Predicate<StockMovement> { $0.partID == partID },
            sort: \StockMovement.timestamp,
            order: .reverse
        )
    }

    var body: some View {
        List {
            Section {
                VStack(spacing: 8) {
                    Text("\(part.stockQuantity)")
                        .font(.system(size: 52, weight: .bold, design: .rounded))
                        .foregroundStyle(part.isLowStock ? Color.orange : Color.primary)
                    Text(part.unit)
                        .foregroundStyle(.secondary)
                    if part.isLowStock {
                        Label("Mindestbestand \(part.minimumStock) erreicht", systemImage: "exclamationmark.triangle.fill")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(.orange)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)

                HStack {
                    Button {
                        bookingKind = IdentifiableMovementKind(kind: .inbound)
                    } label: {
                        Label("Eingang", systemImage: "arrow.down.circle.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)

                    Button {
                        bookingKind = IdentifiableMovementKind(kind: .outbound)
                    } label: {
                        Label("Ausgang", systemImage: "arrow.up.circle.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.orange)
                    .disabled(part.stockQuantity == 0)
                }
            }

            Section("Originalkennzeichnung") {
                LabeledContent("Hersteller", value: part.manufacturer)
                LabeledContent("Original Art.-Nr.", value: part.originalArticleNumber)
                LabeledContent("Bezeichnung", value: part.partName)
                ForEach(barcodes) { barcode in
                    VStack(alignment: .leading, spacing: 3) {
                        HStack {
                            Text(barcode.isPrimary ? "Hauptbarcode" : "Weiterer Barcode")
                            Spacer()
                            if !barcode.symbology.isEmpty {
                                Text(barcode.symbology)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .font(.caption)
                        Text(barcode.value)
                            .font(.body.monospaced())
                            .textSelection(.enabled)
                    }
                }
            }

            Section("Lagerort") {
                if let drawer = assignedDrawer {
                    LabeledContent("Schublade", value: drawer.code)
                    if !drawer.location.isEmpty {
                        LabeledContent("Ort", value: drawer.location)
                    }
                } else {
                    Label("Keine Schublade zugeordnet", systemImage: "tray")
                        .foregroundStyle(.secondary)
                }
            }

            Section("Regler- / Pilotzuordnung") {
                if compatibilities.isEmpty {
                    Text("Noch keine gerätespezifische Ersatzteilnummer hinterlegt.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(compatibilities) { assignment in
                        if let equipment = equipmentTypes.first(where: { $0.id == assignment.equipmentTypeID }) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(equipment.displayName)
                                    .font(.headline)
                                Text("Ersatzteil-Nr.: \(assignment.deviceSparePartNumber)")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                Button {
                    addCompatibilityPresented = true
                } label: {
                    Label("Gerätezuordnung hinzufügen", systemImage: "plus.circle.fill")
                }
            }

            Section("IH2Go / SAP") {
                if let mapping = materialMapping {
                    LabeledContent("Materialnummer", value: mapping.materialNumber)
                    if !mapping.plant.isEmpty { LabeledContent("Werk", value: mapping.plant) }
                    if !mapping.storageLocation.isEmpty { LabeledContent("Lagerort", value: mapping.storageLocation) }
                    if let sapStock = mapping.lastSAPStockQuantity {
                        LabeledContent("Letzter SAP-Bestand", value: "\(sapStock) \(part.unit)")
                    }
                } else {
                    Label("Noch keine SAP-Materialnummer", systemImage: "link.badge.plus")
                        .foregroundStyle(.secondary)
                }
                Button {
                    sapMappingPresented = true
                } label: {
                    Label("SAP-Material zuordnen", systemImage: "link")
                }
            }

            Section("Mindestbestand") {
                LabeledContent("Grenzwert", value: "\(part.minimumStock) \(part.unit)")
                LabeledContent("Erinnerung", value: part.reminderEnabled ? "Aktiv" : "Aus")
            }

            Section("Buchungsverlauf") {
                if movements.isEmpty {
                    Text("Noch keine Buchungen")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(movements.prefix(30)) { movement in
                        HStack {
                            Image(systemName: movement.kind.systemImage)
                                .foregroundStyle(movement.kind == .outbound ? Color.orange : Color.green)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(movement.kind.rawValue)
                                    .font(.subheadline.weight(.semibold))
                                Text(movement.timestamp.formatted(date: .numeric, time: .shortened))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                if !movement.reference.isEmpty {
                                    Text(movement.reference)
                                        .font(.caption)
                                }
                                if !movement.sapOrderNumber.isEmpty {
                                    Text("SAP-Auftrag \(movement.sapOrderNumber)")
                                        .font(.caption)
                                }
                                if movement.sapSyncStatus != .notRequired {
                                    Label(movement.sapSyncStatus.rawValue, systemImage: movement.sapSyncStatus.systemImage)
                                        .font(.caption2)
                                        .foregroundStyle(
                                            movement.sapSyncStatus == .failed || movement.sapSyncStatus == .mappingRequired
                                                ? Color.red : Color.secondary
                                        )
                                }
                            }
                            Spacer()
                            VStack(alignment: .trailing) {
                                Text(movementQuantityText(movement))
                                    .font(.headline.monospacedDigit())
                                Text("danach \(movement.stockAfter)")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }

            if !part.notes.isEmpty {
                Section("Notiz") {
                    Text(part.notes)
                }
            }
        }
        .navigationTitle(part.partName)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button("Bearbeiten") { editPresented = true }
            }
        }
        .sheet(item: $bookingKind) { item in
            BookingFormView(part: part, initialKind: item.kind, barcodeUsed: barcodes.first(where: \.isPrimary)?.value ?? "")
        }
        .sheet(isPresented: $editPresented) {
            PartEditView(part: part)
        }
        .sheet(isPresented: $addCompatibilityPresented) {
            AddCompatibilityView(part: part)
        }
        .sheet(isPresented: $sapMappingPresented) {
            SAPMaterialMappingEditorView(part: part)
        }
    }

    private var assignedDrawer: Drawer? {
        guard let drawerID = part.drawerID else { return nil }
        return drawers.first(where: { $0.id == drawerID })
    }

    private var materialMapping: SAPMaterialMapping? {
        materialMappings.first(where: { $0.partID == part.id })
    }

    private func movementQuantityText(_ movement: StockMovement) -> String {
        switch movement.kind {
        case .outbound: "−\(movement.quantity)"
        case .inbound, .openingBalance: "+\(movement.quantity)"
        case .reconciliation: "= \(movement.stockAfter)"
        }
    }
}

private struct AddCompatibilityView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    let part: SparePart
    @Query(sort: \EquipmentType.designation) private var equipmentTypes: [EquipmentType]
    @Query private var existingCompatibilities: [PartCompatibility]

    @State private var selectedEquipmentID: UUID?
    @State private var sparePartNumber = ""
    @State private var notes = ""
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("Zuordnung") {
                    Picker("Regler / Pilot", selection: $selectedEquipmentID) {
                        Text("Bitte wählen").tag(Optional<UUID>.none)
                        ForEach(equipmentTypes) { equipment in
                            Text("\(equipment.displayName) · \(equipment.kind.rawValue)")
                                .tag(Optional(equipment.id))
                        }
                    }
                    TextField("Ersatzteilnummer an diesem Gerät", text: $sparePartNumber)
                    TextField("Notiz", text: $notes, axis: .vertical)
                        .lineLimit(2...4)
                }

                if equipmentTypes.isEmpty {
                    Section {
                        Text("Lege zuerst im Tab Schubladen einen Regler- oder Pilottyp an.")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Gerätezuordnung")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern", action: save)
                        .disabled(
                            selectedEquipmentID == nil ||
                            sparePartNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        )
                }
            }
            .alert("Speichern fehlgeschlagen", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
        }
    }

    private func save() {
        guard let selectedEquipmentID else { return }
        let cleanNumber = sparePartNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        let duplicate = existingCompatibilities.contains {
            $0.partID == part.id &&
            $0.equipmentTypeID == selectedEquipmentID &&
            $0.deviceSparePartNumber.compare(cleanNumber, options: [.caseInsensitive]) == .orderedSame
        }
        guard !duplicate else {
            errorMessage = "Diese Zuordnung ist bereits vorhanden."
            return
        }

        modelContext.insert(
            PartCompatibility(
                partID: part.id,
                equipmentTypeID: selectedEquipmentID,
                deviceSparePartNumber: cleanNumber,
                notes: notes.trimmingCharacters(in: .whitespacesAndNewlines)
            )
        )
        do {
            try modelContext.save()
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

private struct IdentifiableMovementKind: Identifiable {
    let kind: MovementKind
    var id: String { kind.rawValue }
}

private struct PartEditView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Bindable var part: SparePart
    @Query(sort: \Drawer.code) private var drawers: [Drawer]

    @State private var manufacturer: String
    @State private var articleNumber: String
    @State private var partName: String
    @State private var unit: String
    @State private var selectedDrawerID: UUID?
    @State private var minimumStock: Int
    @State private var reminderEnabled: Bool
    @State private var notes: String
    @State private var errorMessage: String?
    @State private var notificationDenied = false

    init(part: SparePart) {
        self.part = part
        _manufacturer = State(initialValue: part.manufacturer)
        _articleNumber = State(initialValue: part.originalArticleNumber)
        _partName = State(initialValue: part.partName)
        _unit = State(initialValue: part.unit)
        _selectedDrawerID = State(initialValue: part.drawerID)
        _minimumStock = State(initialValue: part.minimumStock)
        _reminderEnabled = State(initialValue: part.reminderEnabled)
        _notes = State(initialValue: part.notes)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Ersatzteil") {
                    TextField("Hersteller", text: $manufacturer)
                    TextField("Original-Artikelnummer", text: $articleNumber)
                    TextField("Bezeichnung", text: $partName)
                    TextField("Einheit", text: $unit)
                }

                Section("Lager") {
                    Picker("Schublade", selection: $selectedDrawerID) {
                        Text("Nicht zugeordnet").tag(Optional<UUID>.none)
                        ForEach(drawers) { drawer in
                            Text(drawer.displayName).tag(Optional(drawer.id))
                        }
                    }
                    Stepper("Mindestbestand: \(minimumStock)", value: $minimumStock, in: 0...99_999)
                    Toggle("Erinnerung bei Mindestbestand", isOn: $reminderEnabled)
                }

                Section("Notiz") {
                    TextField("Optional", text: $notes, axis: .vertical)
                        .lineLimit(2...5)
                }
            }
            .navigationTitle("Ersatzteil bearbeiten")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern", action: save)
                        .disabled(
                            manufacturer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                            articleNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                            partName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        )
                }
            }
            .onChange(of: reminderEnabled) { _, isEnabled in
                guard isEnabled else { return }
                Task { @MainActor in
                    let state = await LowStockNotificationService.authorizationState()
                    if state == .notDetermined {
                        let granted = await LowStockNotificationService.requestAuthorization()
                        if !granted {
                            reminderEnabled = false
                            notificationDenied = true
                        }
                    } else if state == .denied {
                        reminderEnabled = false
                        notificationDenied = true
                    }
                }
            }
            .alert("Speichern fehlgeschlagen", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
            .alert("Benachrichtigungen sind deaktiviert", isPresented: $notificationDenied) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Erlaube Benachrichtigungen in den iOS-Einstellungen.")
            }
        }
    }

    private func save() {
        let shouldNotify = reminderEnabled && part.stockQuantity <= minimumStock && !part.lowStockAlerted
        let shouldRemove = (!reminderEnabled || part.stockQuantity > minimumStock) && part.lowStockAlerted

        part.manufacturer = manufacturer.trimmingCharacters(in: .whitespacesAndNewlines)
        part.originalArticleNumber = articleNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        part.partName = partName.trimmingCharacters(in: .whitespacesAndNewlines)
        part.unit = unit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Stück" : unit
        part.drawerID = selectedDrawerID
        part.minimumStock = minimumStock
        part.reminderEnabled = reminderEnabled
        part.notes = notes.trimmingCharacters(in: .whitespacesAndNewlines)
        part.lowStockAlerted = reminderEnabled && part.stockQuantity <= minimumStock
        part.updatedAt = .now

        do {
            try modelContext.save()
            if shouldRemove {
                LowStockNotificationService.removeLowStockReminder(for: part.id)
            }
            if shouldNotify {
                Task { @MainActor in
                    let sent = await LowStockNotificationService.scheduleLowStockReminder(for: part)
                    if !sent {
                        part.lowStockAlerted = false
                        try? modelContext.save()
                    }
                }
            }
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
