import SwiftUI

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage(SAPSettingsKey.autoSyncEnabled) private var autoSyncEnabled = true
    @State private var isAutoSynchronizing = false

    var body: some View {
        TabView {
            NavigationStack {
                DashboardView()
            }
            .tabItem {
                Label("Übersicht", systemImage: "square.grid.2x2.fill")
            }

            NavigationStack {
                BookingHubView()
            }
            .tabItem {
                Label("Buchen", systemImage: "barcode.viewfinder")
            }

            NavigationStack {
                InventoryListView()
            }
            .tabItem {
                Label("Ersatzteile", systemImage: "shippingbox.fill")
            }

            NavigationStack {
                StorageView()
            }
            .tabItem {
                Label("Schubladen", systemImage: "cabinet.fill")
            }

            NavigationStack {
                SettingsView()
            }
            .tabItem {
                Label("Mehr", systemImage: "ellipsis.circle.fill")
            }
        }
        .tint(.blue)
        .task { await synchronizeIfConfigured() }
        .onChange(of: scenePhase) { _, phase in
            guard phase == .active else { return }
            Task { await synchronizeIfConfigured() }
        }
    }

    @MainActor
    private func synchronizeIfConfigured() async {
        guard autoSyncEnabled,
              !isAutoSynchronizing,
              SAPConnectionConfiguration.current().isConfigured else { return }
        isAutoSynchronizing = true
        defer { isAutoSynchronizing = false }
        _ = try? await SAPIntegrationService.synchronize(in: modelContext)
    }
}
