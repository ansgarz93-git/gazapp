import SwiftUI
import VisionKit
import Vision

struct BarcodeScannerView: View {
    @Environment(\.dismiss) private var dismiss
    let onScan: (_ value: String, _ symbology: String) -> Void

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                if DataScannerViewController.isSupported && DataScannerViewController.isAvailable {
                    DataScannerRepresentable(onScan: onScan)
                        .ignoresSafeArea()

                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(.white.opacity(0.9), lineWidth: 3)
                        .frame(width: 300, height: 180)
                        .accessibilityHidden(true)

                    VStack {
                        Spacer()
                        Text("Original-Barcode vollständig in den Rahmen halten")
                            .font(.callout.weight(.semibold))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 18)
                            .padding(.vertical, 12)
                            .foregroundStyle(.white)
                            .background(.black.opacity(0.65), in: Capsule())
                            .padding(.bottom, 32)
                    }
                } else {
                    ContentUnavailableView(
                        "Scanner nicht verfügbar",
                        systemImage: "camera.fill",
                        description: Text("Bitte den Barcode auf der Buchungsseite manuell eingeben.")
                    )
                    .foregroundStyle(.white)
                }
            }
            .navigationTitle("Barcode scannen")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbarBackground(.black.opacity(0.6), for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                        .foregroundStyle(.white)
                }
            }
        }
    }
}

private struct DataScannerRepresentable: UIViewControllerRepresentable {
    let onScan: (_ value: String, _ symbology: String) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onScan: onScan)
    }

    func makeUIViewController(context: Context) -> DataScannerViewController {
        let scanner = DataScannerViewController(
            recognizedDataTypes: [.barcode(symbologies: [])],
            qualityLevel: .balanced,
            recognizesMultipleItems: false,
            isHighFrameRateTrackingEnabled: true,
            isPinchToZoomEnabled: true,
            isGuidanceEnabled: true,
            isHighlightingEnabled: true
        )
        scanner.delegate = context.coordinator
        DispatchQueue.main.async {
            try? scanner.startScanning()
        }
        return scanner
    }

    func updateUIViewController(_ uiViewController: DataScannerViewController, context: Context) {}

    static func dismantleUIViewController(_ uiViewController: DataScannerViewController, coordinator: Coordinator) {
        uiViewController.stopScanning()
    }

    final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        private let onScan: (_ value: String, _ symbology: String) -> Void
        private var completed = false

        init(onScan: @escaping (_ value: String, _ symbology: String) -> Void) {
            self.onScan = onScan
        }

        func dataScanner(
            _ dataScanner: DataScannerViewController,
            didAdd addedItems: [RecognizedItem],
            allItems: [RecognizedItem]
        ) {
            process(addedItems)
        }

        func dataScanner(_ dataScanner: DataScannerViewController, didTapOn item: RecognizedItem) {
            process([item])
        }

        private func process(_ items: [RecognizedItem]) {
            guard !completed else { return }
            for item in items {
                guard case .barcode(let barcode) = item,
                      let value = barcode.payloadStringValue,
                      !value.isEmpty else { continue }
                completed = true
                onScan(value, barcode.observation.symbology.rawValue)
                return
            }
        }
    }
}
