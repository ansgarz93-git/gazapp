import SwiftUI
import SwiftData
import UniformTypeIdentifiers

struct SAPConnectionSettingsView: View {
    @AppStorage(SAPSettingsKey.baseURL) private var baseURL = ""
    @AppStorage(SAPSettingsKey.ordersPath) private var ordersPath = "/api/gaslager/v1/work-orders"
    @AppStorage(SAPSettingsKey.movementsPath) private var movementsPath = "/api/gaslager/v1/material-movements"
    @AppStorage(SAPSettingsKey.stockPath) private var stockPath = "/api/gaslager/v1/stock"
    @AppStorage(SAPSettingsKey.sapClient) private var sapClient = ""
    @AppStorage(SAPSettingsKey.defaultPlant) private var defaultPlant = ""
    @AppStorage(SAPSettingsKey.defaultStorageLocation) private var defaultStorageLocation = ""
    @AppStorage(SAPSettingsKey.goodsIssueMovementType) private var goodsIssueMovementType = "261"
    @AppStorage(SAPSettingsKey.goodsReceiptMovementType) private var goodsReceiptMovementType = "101"
    @AppStorage(SAPSettingsKey.orderRequiredForOutbound) private var orderRequiredForOutbound = true
    @AppStorage(SAPSettingsKey.inventorySyncEnabled) private var inventorySyncEnabled = true
    @AppStorage(SAPSettingsKey.autoSyncEnabled) private var autoSyncEnabled = true
    @AppStorage(SAPSettingsKey.sapStockIsMaster) private var sapStockIsMaster = true

    @State private var bearerToken = ""
    @State private var isTesting = false
    @State private var statusMessage: String?
    @State private var errorMessage: String?

    var body: some View {
        Form {
            Section("IH2Go-Bridge") {
                TextField("https://ih2go-bridge.firma.de", text: $baseURL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                SecureField("Bearer-Token", text: $bearerToken)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                TextField("SAP-Mandant, z. B. 100", text: $sapClient)
                    .keyboardType(.numberPad)

                Button(action: saveAndTest) {
                    if isTesting {
                        HStack { ProgressView(); Text("Verbindung wird geprüft …") }
                    } else {
                        Label("Speichern und Verbindung testen", systemImage: "network.badge.shield.half.filled")
                    }
                }
                .disabled(isTesting || baseURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                Text("Das Token wird ausschließlich im iOS-Schlüsselbund gespeichert. Die App akzeptiert für die Live-Anbindung nur HTTPS.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Bridge-Endpunkte") {
                TextField("Aufträge", text: $ordersPath)
                    .textInputCapitalizationDisabled()
                TextField("Materialbuchungen", text: $movementsPath)
                    .textInputCapitalizationDisabled()
                TextField("Bestände (leer = kein Abruf)", text: $stockPath)
                    .textInputCapitalizationDisabled()
                Text("Die Pfade gehören zum mitgelieferten Bridge-Vertrag und werden von der kundenspezifischen IH2Go-/SAP-Middleware umgesetzt.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("SAP-Lager") {
                TextField("Standardwerk", text: $defaultPlant)
                TextField("Standardlagerort", text: $defaultStorageLocation)
                TextField("Bewegungsart Ausgang", text: $goodsIssueMovementType)
                    .keyboardType(.numberPad)
                TextField("Bewegungsart Eingang", text: $goodsReceiptMovementType)
                    .keyboardType(.numberPad)
                Toggle("SAP-Bestand ist führend", isOn: $sapStockIsMaster)
                Text("Werk, Lagerort und Bewegungsarten müssen vor dem produktiven Einsatz mit der SAP-Betreuung abgestimmt werden.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Buchungsregeln") {
                Toggle("SAP-Auftrag bei Ausgang verlangen", isOn: $orderRequiredForOutbound)
                Toggle("Lagerbuchungen synchronisieren", isOn: $inventorySyncEnabled)
                Toggle("Beim App-Start automatisch synchronisieren", isOn: $autoSyncEnabled)
                Text("Offline-Buchungen bleiben lokal erhalten und werden mit eindeutiger Buchungs-ID erneut übertragen. SAP-Fehler erscheinen in der Synchronisationswarteschlange.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Schnittstellenvertrag") {
                LabeledContent("Aufträge", value: "GET JSON")
                LabeledContent("Bestand", value: "GET JSON")
                LabeledContent("Materialbuchung", value: "POST JSON")
                Text("Ein vollständiges Feldschema und Beispieldateien liegen im Projektordner Schnittstelle. Ohne kundenspezifische IH2Go-Freigabe arbeitet die App über Dateiimport/-export.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("IH2Go / SAP")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { bearerToken = SAPCredentialStore.bearerToken() }
        .alert("Verbindung", isPresented: Binding(
            get: { statusMessage != nil },
            set: { if !$0 { statusMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(statusMessage ?? "")
        }
        .alert("Verbindung fehlgeschlagen", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "Unbekannter Fehler")
        }
    }

    private func saveAndTest() {
        isTesting = true
        Task { @MainActor in
            defer { isTesting = false }
            do {
                try SAPCredentialStore.saveBearerToken(bearerToken)
                let configuration = SAPConnectionConfiguration.current()
                let orders = try await IH2GoBridgeClient.fetchWorkOrders(configuration: configuration)
                statusMessage = "Verbindung erfolgreich. \(orders.count) Auftrag/Aufträge sind abrufbar."
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}

private extension View {
    func textInputCapitalizationDisabled() -> some View {
        textInputAutocapitalization(.never)
            .autocorrectionDisabled()
    }
}

struct SAPMaterialMappingEditorView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    let part: SparePart
    @Query private var mappings: [SAPMaterialMapping]
    @Query private var orderComponents: [SAPOrderComponent]

    @AppStorage(SAPSettingsKey.defaultPlant) private var defaultPlant = ""
    @AppStorage(SAPSettingsKey.defaultStorageLocation) private var defaultStorageLocation = ""
    @State private var materialNumber = ""
    @State private var plant = ""
    @State private var storageLocation = ""
    @State private var baseUnit = "ST"
    @State private var errorMessage: String?

    private var existingMapping: SAPMaterialMapping? {
        mappings.first(where: { $0.partID == part.id })
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Ersatzteil") {
                    LabeledContent("Original Art.-Nr.", value: part.originalArticleNumber)
                    LabeledContent("Bezeichnung", value: part.partName)
                }
                Section("SAP-Materialstamm") {
                    TextField("SAP-Materialnummer", text: $materialNumber)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                    TextField("Werk", text: $plant)
                    TextField("Lagerort", text: $storageLocation)
                    TextField("SAP-Basiseinheit", text: $baseUnit)
                        .textInputAutocapitalization(.characters)
                    if let mapping = existingMapping, let sapStock = mapping.lastSAPStockQuantity {
                        LabeledContent("Letzter SAP-Bestand", value: String(sapStock))
                        if let lastSync = mapping.lastStockSyncAt {
                            LabeledContent("Stand", value: lastSync.formatted(date: .abbreviated, time: .shortened))
                        }
                    }
                }
                Section {
                    Text("Die SAP-Materialnummer verbindet den Originalartikel und seinen Barcode eindeutig mit Materialbelegen in IH2Go/SAP.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("SAP-Zuordnung")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern", action: save)
                        .disabled(materialNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .onAppear(perform: load)
            .alert("Speichern fehlgeschlagen", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
        }
    }

    private func load() {
        if let mapping = existingMapping {
            materialNumber = mapping.materialNumber
            plant = mapping.plant
            storageLocation = mapping.storageLocation
            baseUnit = mapping.baseUnit
        } else {
            plant = defaultPlant
            storageLocation = defaultStorageLocation
        }
    }

    private func save() {
        let cleanMaterial = materialNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        if mappings.contains(where: {
            $0.partID != part.id &&
            $0.materialNumber.compare(cleanMaterial, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame
        }) {
            errorMessage = "Diese SAP-Materialnummer ist bereits einem anderen Ersatzteil zugeordnet."
            return
        }
        let mapping: SAPMaterialMapping
        if let existingMapping {
            mapping = existingMapping
        } else {
            mapping = SAPMaterialMapping(partID: part.id, materialNumber: cleanMaterial)
            modelContext.insert(mapping)
        }
        mapping.materialNumber = cleanMaterial
        mapping.plant = plant.trimmingCharacters(in: .whitespacesAndNewlines)
        mapping.storageLocation = storageLocation.trimmingCharacters(in: .whitespacesAndNewlines)
        mapping.baseUnit = baseUnit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "ST" : baseUnit
        mapping.updatedAt = .now
        for component in orderComponents where component.materialNumber == cleanMaterial {
            component.partID = part.id
            component.updatedAt = .now
        }

        do {
            try modelContext.save()
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

struct SAPMovementExportView: View {
    @Query(sort: \StockMovement.timestamp) private var movements: [StockMovement]
    @Query private var parts: [SparePart]
    @Query private var materialMappings: [SAPMaterialMapping]
    @State private var exporterPresented = false
    @State private var exportDocument = CSVTextDocument()
    @State private var errorMessage: String?

    var body: some View {
        List {
            Section {
                Button {
                    exportDocument = CSVTextDocument(
                        text: SAPMovementCSVExporter.makeCSV(
                            movements: movements,
                            parts: parts,
                            materialMappings: materialMappings
                        )
                    )
                    exporterPresented = true
                } label: {
                    Label("SAP-Buchungsdatei exportieren", systemImage: "square.and.arrow.up")
                }
                .disabled(movements.isEmpty)
            }
            Section {
                Text("Der Export enthält Auftrags-, Kunden-, Equipment-, Material-, Werk- und Lagerortbezug sowie den Synchronisationsstatus jeder Buchung.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("SAP-Dateiexport")
        .fileExporter(
            isPresented: $exporterPresented,
            document: exportDocument,
            contentType: .commaSeparatedText,
            defaultFilename: "Gaslager_SAP_Buchungen"
        ) { result in
            if case .failure(let error) = result { errorMessage = error.localizedDescription }
        }
        .alert("Export fehlgeschlagen", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "Unbekannter Fehler")
        }
    }
}
