import SwiftUI
import SwiftData
import UniformTypeIdentifiers
import UIKit

struct SettingsView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var parts: [SparePart]
    @Query private var barcodes: [PartBarcode]
    @Query private var drawers: [Drawer]
    @Query private var equipmentTypes: [EquipmentType]
    @Query private var compatibilities: [PartCompatibility]
    @Query private var documents: [TechnicalDocument]
    @Query private var sapOrders: [SAPWorkOrder]
    @Query private var sapMappings: [SAPMaterialMapping]
    @Query private var sapQueue: [SAPSyncQueueItem]

    @State private var importerPresented = false
    @State private var exporterPresented = false
    @State private var exportDocument = CSVTextDocument()
    @State private var exportFilename = "Gaslager_Katalog"
    @State private var importReport: CatalogImportReport?
    @State private var errorMessage: String?
    @State private var notificationState: NotificationAuthorizationState = .notDetermined

    var body: some View {
        List {
            Section("IH2Go / SAP") {
                NavigationLink {
                    SAPOrdersView()
                } label: {
                    Label("Kunden- und Wartungsaufträge", systemImage: "wrench.and.screwdriver.fill")
                }
                NavigationLink {
                    SAPConnectionSettingsView()
                } label: {
                    Label("Schnittstelle konfigurieren", systemImage: "network")
                }
                NavigationLink {
                    SAPSyncQueueView()
                } label: {
                    LabeledContent {
                        Text(String(sapQueue.filter { $0.status != .synchronized }.count))
                    } label: {
                        Label("Synchronisationswarteschlange", systemImage: "arrow.triangle.2.circlepath")
                    }
                }
                NavigationLink {
                    SAPMovementExportView()
                } label: {
                    Label("SAP-Buchungen als CSV", systemImage: "square.and.arrow.up")
                }
                LabeledContent("Aufträge", value: String(sapOrders.count))
                LabeledContent("Materialzuordnungen", value: String(sapMappings.count))
            }

            Section("Teilekatalog") {
                Button {
                    importerPresented = true
                } label: {
                    Label("CSV-Katalog importieren", systemImage: "square.and.arrow.down")
                }

                Button(action: exportCatalog) {
                    Label("Bestand als CSV exportieren", systemImage: "square.and.arrow.up")
                }

                Button(action: exportBarcodeList) {
                    Label("Barcode-Liste als CSV exportieren", systemImage: "barcode")
                }

                Button(action: exportTemplate) {
                    Label("Leere CSV-Vorlage exportieren", systemImage: "tablecells")
                }

                Text("Vorhandene Artikel werden beim Import anhand von Hersteller und Original-Artikelnummer aktualisiert. Der laufende Bestand wird dabei nicht überschrieben.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Herstellerunterlagen") {
                NavigationLink {
                    ManufacturerResourcesView()
                } label: {
                    Label("Offizielle Honeywell-Quellen", systemImage: "building.columns.fill")
                }
                LabeledContent("Offline-PDFs und Links", value: String(documents.count))
                Text("Unterlagen werden direkt beim jeweiligen Regler- oder Pilottyp verwaltet.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Mindestbestandswarnungen") {
                LabeledContent("iOS-Berechtigung", value: notificationState.rawValue)
                if notificationState != .allowed {
                    Button("Benachrichtigungen aktivieren", action: requestNotifications)
                }
                Text("Die Erinnerung wird pro Ersatzteil eingeschaltet und nach jeder erneuten Unterschreitung einmal ausgelöst.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Datenbestand") {
                LabeledContent("Ersatzteile", value: String(parts.count))
                LabeledContent("Original-Barcodes", value: String(barcodes.count))
                LabeledContent("Regler und Piloten", value: String(equipmentTypes.count))
                LabeledContent("Schubladen", value: String(drawers.count))
            }

            Section("App") {
                LabeledContent("Name", value: "Gaslager")
                LabeledContent("Version", value: appVersion)
                Text("Lagerdatenbank und importierte PDFs liegen lokal auf diesem Gerät. Aufträge, Materialbuchungen und freigegebene Bestände können über die konfigurierte IH2Go-Bridge mit SAP synchronisiert werden.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Mehr")
        .task {
            notificationState = await LowStockNotificationService.authorizationState()
        }
        .fileImporter(
            isPresented: $importerPresented,
            allowedContentTypes: [.commaSeparatedText, .plainText],
            allowsMultipleSelection: false
        ) { result in
            importCatalog(result)
        }
        .fileExporter(
            isPresented: $exporterPresented,
            document: exportDocument,
            contentType: .commaSeparatedText,
            defaultFilename: exportFilename
        ) { result in
            if case .failure(let error) = result {
                errorMessage = error.localizedDescription
            }
        }
        .alert("CSV-Import abgeschlossen", isPresented: Binding(
            get: { importReport != nil },
            set: { if !$0 { importReport = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(importReport?.summary ?? "")
        }
        .alert("Vorgang fehlgeschlagen", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "Unbekannter Fehler")
        }
    }

    private var appVersion: String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
        return "\(version) (\(build))"
    }

    private func importCatalog(_ result: Result<[URL], Error>) {
        do {
            guard let url = try result.get().first else { return }
            importReport = try CatalogCSVImporter.importFile(at: url, into: modelContext)
            Task { @MainActor in
                let importedParts = (try? modelContext.fetch(FetchDescriptor<SparePart>())) ?? []
                for part in importedParts where part.reminderEnabled && part.stockQuantity <= part.minimumStock && !part.lowStockAlerted {
                    let sent = await LowStockNotificationService.scheduleLowStockReminder(for: part)
                    if sent { part.lowStockAlerted = true }
                }
                try? modelContext.save()
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func exportCatalog() {
        exportDocument = CSVTextDocument(
            text: CatalogCSVExporter.makeCSV(
                parts: parts,
                barcodes: barcodes,
                drawers: drawers,
                equipmentTypes: equipmentTypes,
                compatibilities: compatibilities,
                materialMappings: sapMappings
            )
        )
        exportFilename = "Gaslager_Katalog"
        exporterPresented = true
    }

    private func exportBarcodeList() {
        exportDocument = CSVTextDocument(
            text: BarcodeListCSVExporter.makeCSV(
                parts: parts,
                barcodes: barcodes,
                drawers: drawers,
                equipmentTypes: equipmentTypes,
                compatibilities: compatibilities,
                materialMappings: sapMappings
            )
        )
        exportFilename = "Gaslager_Barcodes"
        exporterPresented = true
    }

    private func exportTemplate() {
        let text = "\u{FEFF}" + CatalogCSVExporter.header.joined(separator: ";") + "\r\n"
        exportDocument = CSVTextDocument(text: text)
        exportFilename = "RMG_Honeywell_Katalogvorlage"
        exporterPresented = true
    }

    private func requestNotifications() {
        Task { @MainActor in
            let granted = await LowStockNotificationService.requestAuthorization()
            notificationState = await LowStockNotificationService.authorizationState()
            if granted {
                for part in parts where part.reminderEnabled && part.stockQuantity <= part.minimumStock && !part.lowStockAlerted {
                    let sent = await LowStockNotificationService.scheduleLowStockReminder(for: part)
                    if sent { part.lowStockAlerted = true }
                }
                try? modelContext.save()
            } else if notificationState == .denied {
                if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                    await UIApplication.shared.open(settingsURL)
                }
            }
        }
    }
}
