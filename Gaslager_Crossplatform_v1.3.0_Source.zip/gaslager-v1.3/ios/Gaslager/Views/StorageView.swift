import SwiftUI
import SwiftData

struct StorageView: View {
    @Query(sort: \EquipmentType.designation) private var equipmentTypes: [EquipmentType]
    @Query(sort: \Drawer.code) private var drawers: [Drawer]
    @State private var activeSheet: StorageSheet?

    var body: some View {
        Group {
            if equipmentTypes.isEmpty {
                ContentUnavailableView {
                    Label("Keine Regler oder Piloten", systemImage: "cabinet")
                } description: {
                    Text("Übernimm Gerätetypen aus dem Honeywell-/RMG-Katalog und lege danach die Schubladen an.")
                } actions: {
                    VStack {
                        Button("Herstellerkatalog öffnen") { activeSheet = .catalog }
                            .buttonStyle(.borderedProminent)
                        Button("Gerätetyp manuell anlegen") { activeSheet = .equipment }
                    }
                }
            } else {
                List {
                    ForEach(EquipmentKind.allCases) { kind in
                        let matchingEquipment = equipmentTypes.filter { $0.kind == kind }
                        if !matchingEquipment.isEmpty {
                            Section(kind.rawValue) {
                                ForEach(matchingEquipment) { equipment in
                                    NavigationLink {
                                        EquipmentDetailView(equipment: equipment)
                                    } label: {
                                        HStack(spacing: 12) {
                                            Image(systemName: kind.systemImage)
                                                .foregroundStyle(kind == .pilot ? Color.indigo : Color.blue)
                                                .frame(width: 28)
                                            VStack(alignment: .leading, spacing: 3) {
                                                Text(equipment.displayName)
                                                    .font(.headline)
                                                let count = drawers.filter { $0.equipmentTypeID == equipment.id }.count
                                                Text("\(count) \(count == 1 ? "Schublade" : "Schubladen")")
                                                    .font(.caption)
                                                    .foregroundStyle(.secondary)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Schubladen")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Menu {
                    Button {
                        activeSheet = .catalog
                    } label: {
                        Label("Herstellerkatalog", systemImage: "books.vertical.fill")
                    }
                    Button {
                        activeSheet = .equipment
                    } label: {
                        Label("Regler / Pilot anlegen", systemImage: "gauge.with.dots.needle.50percent")
                    }
                    Button {
                        activeSheet = .drawer
                    } label: {
                        Label("Schublade anlegen", systemImage: "cabinet.fill")
                    }
                    .disabled(equipmentTypes.isEmpty)
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(item: $activeSheet) { sheet in
            switch sheet {
            case .catalog:
                ManufacturerCatalogView()
            case .equipment:
                EquipmentTypeFormView()
            case .drawer:
                DrawerFormView()
            }
        }
    }
}

private enum StorageSheet: String, Identifiable {
    case catalog
    case equipment
    case drawer
    var id: String { rawValue }
}

struct EquipmentDetailView: View {
    let equipment: EquipmentType
    @Query private var equipmentDrawers: [Drawer]
    @Query private var documents: [TechnicalDocument]
    @Query(sort: \SparePart.partName) private var allParts: [SparePart]
    @State private var addDrawerPresented = false

    init(equipment: EquipmentType) {
        self.equipment = equipment
        let equipmentID = equipment.id
        _equipmentDrawers = Query(
            filter: #Predicate<Drawer> { $0.equipmentTypeID == equipmentID },
            sort: \Drawer.code
        )
        _documents = Query(
            filter: #Predicate<TechnicalDocument> { $0.equipmentTypeID == equipmentID },
            sort: \TechnicalDocument.title
        )
    }

    private var assignedParts: [SparePart] {
        let drawerIDs = Set(equipmentDrawers.map(\.id))
        return allParts.filter { part in
            guard let drawerID = part.drawerID else { return false }
            return drawerIDs.contains(drawerID)
        }
    }

    var body: some View {
        List {
            Section("Gerät") {
                LabeledContent("Hersteller", value: equipment.manufacturer)
                LabeledContent("Typ", value: equipment.designation)
                LabeledContent("Kategorie", value: equipment.kind.rawValue)
            }

            Section("Unterlagen") {
                NavigationLink {
                    TechnicalDocumentsView(equipment: equipment)
                } label: {
                    Label("Herstellerunterlagen", systemImage: "books.vertical.fill")
                }
                Text("\(documents.count) \(documents.count == 1 ? "Unterlage" : "Unterlagen") zugeordnet")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Schubladen") {
                if equipmentDrawers.isEmpty {
                    Text("Noch keine Schublade angelegt")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(equipmentDrawers) { drawer in
                        NavigationLink {
                            DrawerDetailView(drawer: drawer, equipment: equipment)
                        } label: {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(drawer.code)
                                    .font(.headline)
                                if !drawer.location.isEmpty {
                                    Text(drawer.location)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }

                Button {
                    addDrawerPresented = true
                } label: {
                    Label("Schublade hinzufügen", systemImage: "plus.circle.fill")
                }
            }

            Section("Bestand dieses Typs") {
                LabeledContent("Ersatzteilpositionen", value: String(assignedParts.count))
                LabeledContent("Teile gesamt", value: String(assignedParts.reduce(0) { $0 + $1.stockQuantity }))
            }

            if !equipment.notes.isEmpty {
                Section("Notiz") {
                    Text(equipment.notes)
                }
            }
        }
        .navigationTitle(equipment.designation)
        .sheet(isPresented: $addDrawerPresented) {
            DrawerFormView(preselectedEquipmentID: equipment.id)
        }
    }
}

struct DrawerDetailView: View {
    let drawer: Drawer
    let equipment: EquipmentType
    @Query private var parts: [SparePart]

    init(drawer: Drawer, equipment: EquipmentType) {
        self.drawer = drawer
        self.equipment = equipment
        let drawerID = drawer.id
        _parts = Query(
            filter: #Predicate<SparePart> { $0.drawerID == drawerID },
            sort: \SparePart.partName
        )
    }

    var body: some View {
        List {
            Section("Schublade") {
                LabeledContent("Kennung", value: drawer.code)
                LabeledContent("Gerätetyp", value: equipment.displayName)
                if !drawer.location.isEmpty {
                    LabeledContent("Lagerort", value: drawer.location)
                }
            }

            Section("Ersatzteile") {
                if parts.isEmpty {
                    Text("Diese Schublade ist noch leer.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(parts) { part in
                        NavigationLink {
                            PartDetailView(part: part)
                        } label: {
                            PartRow(part: part, drawerCode: nil)
                        }
                    }
                }
            }
        }
        .navigationTitle("Schublade \(drawer.code)")
    }
}

private struct ManufacturerCatalogView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query private var existingEquipment: [EquipmentType]

    @State private var selectedKind: EquipmentKind = .regulator
    @State private var searchText = ""
    @State private var includeInstalledBase = true
    @State private var message: String?
    @State private var errorMessage: String?

    private var filteredEntries: [ManufacturerEquipmentEntry] {
        ManufacturerEquipmentCatalog.entries.filter { entry in
            guard entry.kind == selectedKind else { return false }
            guard includeInstalledBase || entry.status == .current else { return false }
            guard !searchText.isEmpty else { return true }
            let haystack = ([entry.designation, entry.series, entry.status.rawValue] + entry.aliases)
                .joined(separator: " ")
            return haystack.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("Kategorie", selection: $selectedKind) {
                        ForEach(EquipmentKind.allCases) { kind in
                            Text(kind.rawValue).tag(kind)
                        }
                    }
                    .pickerStyle(.segmented)

                    Toggle("Bestands- und Altanlagen anzeigen", isOn: $includeInstalledBase)
                } footer: {
                    Text("Altanlagen sind nur aufgenommen, wenn sie in offiziellen Honeywell-/RMG-Unterlagen belegt sind.")
                }

                Section("\(filteredEntries.count) Typen") {
                    ForEach(filteredEntries) { entry in
                        HStack(alignment: .top, spacing: 12) {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(entry.designation)
                                    .font(.headline)
                                Text(entry.series)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Label(
                                    entry.status == .current ? "Aktuelles Programm" : "Bestands-/Altanlage",
                                    systemImage: entry.status == .current ? "checkmark.seal.fill" : "clock.arrow.circlepath"
                                )
                                .font(.caption2)
                                .foregroundStyle(entry.status == .current ? Color.green : Color.orange)
                                if let url = URL(string: entry.sourceURL) {
                                    Link("Herstellerquelle", destination: url)
                                        .font(.caption)
                                }
                            }
                            Spacer()
                            Button {
                                add([entry])
                            } label: {
                                Image(systemName: isAdded(entry) ? "checkmark.circle.fill" : "plus.circle.fill")
                                    .font(.title2)
                            }
                            .buttonStyle(.borderless)
                            .disabled(isAdded(entry))
                            .accessibilityLabel(isAdded(entry) ? "Bereits übernommen" : "Gerätetyp übernehmen")
                        }
                        .padding(.vertical, 3)
                    }
                }
            }
            .searchable(text: $searchText, prompt: "Typ oder Baureihe suchen")
            .navigationTitle("Herstellerkatalog")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Menu {
                        Button("Gefilterte Typen übernehmen") { add(filteredEntries) }
                            .disabled(filteredEntries.allSatisfy { isAdded($0) })
                        Button("Gesamten Katalog übernehmen") {
                            add(ManufacturerEquipmentCatalog.entries)
                        }
                        .disabled(ManufacturerEquipmentCatalog.entries.allSatisfy { isAdded($0) })
                    } label: {
                        Label("Übernehmen", systemImage: "square.and.arrow.down")
                    }
                }
            }
            .alert("Katalog", isPresented: Binding(
                get: { message != nil },
                set: { if !$0 { message = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(message ?? "")
            }
            .alert("Übernahme fehlgeschlagen", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
        }
    }

    private func isAdded(_ entry: ManufacturerEquipmentEntry) -> Bool {
        existingEquipment.contains {
            $0.kind == entry.kind &&
            ManufacturerEquipmentCatalog.areEquivalent($0.designation, entry.designation, kind: entry.kind)
        }
    }

    private func add(_ entries: [ManufacturerEquipmentEntry]) {
        let missingEntries = entries.filter { !isAdded($0) }
        guard !missingEntries.isEmpty else {
            message = "Alle sichtbaren Typen sind bereits vorhanden."
            return
        }

        for entry in missingEntries {
            let equipment = EquipmentType(
                manufacturer: "Honeywell / RMG",
                designation: entry.designation,
                kind: entry.kind,
                notes: "\(entry.status.rawValue) · \(entry.series)"
            )
            modelContext.insert(equipment)
            for suggestion in ManufacturerDocumentCatalog.suggestions(for: equipment) {
                modelContext.insert(
                    TechnicalDocument(
                        equipmentTypeID: equipment.id,
                        title: suggestion.title,
                        kind: suggestion.kind,
                        sourceURL: suggestion.url,
                        isOfficialManufacturerSource: true
                    )
                )
            }
        }

        do {
            try modelContext.save()
            message = "\(missingEntries.count) Gerätetyp\(missingEntries.count == 1 ? "" : "en") übernommen."
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

private struct EquipmentTypeFormView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query private var existingEquipment: [EquipmentType]

    @State private var manufacturer = "Honeywell / RMG"
    @State private var designation = ""
    @State private var kind: EquipmentKind = .regulator
    @State private var notes = ""
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("Gerätetyp") {
                    TextField("Hersteller", text: $manufacturer)
                    TextField("Typ, z. B. HON 402", text: $designation)
                        .textInputAutocapitalization(.characters)
                    Picker("Kategorie", selection: $kind) {
                        ForEach(EquipmentKind.allCases) { kind in
                            Text(kind.rawValue).tag(kind)
                        }
                    }
                    TextField("Notiz", text: $notes, axis: .vertical)
                        .lineLimit(2...4)
                }
            }
            .navigationTitle("Regler / Pilot anlegen")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern", action: save)
                        .disabled(
                            manufacturer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                            designation.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        )
                }
            }
            .alert("Speichern fehlgeschlagen", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
        }
    }

    private func save() {
        let cleanManufacturer = manufacturer.trimmingCharacters(in: .whitespacesAndNewlines)
        let enteredDesignation = designation.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanDesignation = ManufacturerEquipmentCatalog.canonicalDesignation(for: enteredDesignation, kind: kind)
        let duplicate = existingEquipment.contains {
            ManufacturerEquipmentCatalog.areEquivalent($0.designation, cleanDesignation, kind: kind) &&
            $0.kind == kind
        }
        guard !duplicate else {
            errorMessage = "Dieser Gerätetyp ist bereits vorhanden."
            return
        }

        let equipment = EquipmentType(
            manufacturer: cleanManufacturer,
            designation: cleanDesignation,
            kind: kind,
            notes: notes.trimmingCharacters(in: .whitespacesAndNewlines)
        )
        modelContext.insert(equipment)
        for suggestion in ManufacturerDocumentCatalog.suggestions(for: equipment) {
            modelContext.insert(
                TechnicalDocument(
                    equipmentTypeID: equipment.id,
                    title: suggestion.title,
                    kind: suggestion.kind,
                    sourceURL: suggestion.url,
                    isOfficialManufacturerSource: true
                )
            )
        }
        do {
            try modelContext.save()
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

private struct DrawerFormView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \EquipmentType.designation) private var equipmentTypes: [EquipmentType]
    @Query private var existingDrawers: [Drawer]

    @State private var code = ""
    @State private var location = ""
    @State private var selectedEquipmentID: UUID?
    @State private var notes = ""
    @State private var errorMessage: String?

    init(preselectedEquipmentID: UUID? = nil) {
        _selectedEquipmentID = State(initialValue: preselectedEquipmentID)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Schublade") {
                    TextField("Kennung, z. B. A-03", text: $code)
                        .textInputAutocapitalization(.characters)
                    TextField("Lagerort, z. B. Schrank 2", text: $location)
                    Picker("Regler / Pilot", selection: $selectedEquipmentID) {
                        Text("Bitte wählen").tag(Optional<UUID>.none)
                        ForEach(equipmentTypes) { equipment in
                            Text("\(equipment.displayName) · \(equipment.kind.rawValue)")
                                .tag(Optional(equipment.id))
                        }
                    }
                    TextField("Notiz", text: $notes, axis: .vertical)
                        .lineLimit(2...4)
                }
            }
            .navigationTitle("Schublade anlegen")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern", action: save)
                        .disabled(code.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || selectedEquipmentID == nil)
                }
            }
            .alert("Speichern fehlgeschlagen", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
        }
    }

    private func save() {
        guard let selectedEquipmentID else { return }
        let cleanCode = code.trimmingCharacters(in: .whitespacesAndNewlines)
        let duplicate = existingDrawers.contains {
            $0.code.compare(cleanCode, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame
        }
        guard !duplicate else {
            errorMessage = InventoryError.duplicateDrawerCode.localizedDescription
            return
        }

        modelContext.insert(
            Drawer(
                code: cleanCode,
                location: location.trimmingCharacters(in: .whitespacesAndNewlines),
                equipmentTypeID: selectedEquipmentID,
                notes: notes.trimmingCharacters(in: .whitespacesAndNewlines)
            )
        )
        do {
            try modelContext.save()
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
