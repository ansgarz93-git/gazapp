import SwiftUI
import SwiftData

struct DashboardView: View {
    @Query(sort: \SparePart.partName) private var parts: [SparePart]
    @Query(sort: \StockMovement.timestamp, order: .reverse) private var movements: [StockMovement]
    @Query(sort: \Drawer.code) private var drawers: [Drawer]
    @Query(sort: \SAPWorkOrder.updatedAt, order: .reverse) private var workOrders: [SAPWorkOrder]
    @Query private var syncQueue: [SAPSyncQueueItem]
    @AppStorage(SAPSettingsKey.activeWorkOrderID) private var activeWorkOrderID = ""

    private var activeParts: [SparePart] { parts.filter { !$0.isArchived } }
    private var lowStockParts: [SparePart] { activeParts.filter(\.isLowStock) }
    private var totalUnits: Int { activeParts.reduce(0) { $0 + $1.stockQuantity } }
    private var openOrders: [SAPWorkOrder] { workOrders.filter { !$0.isClosed } }
    private var activeOrder: SAPWorkOrder? {
        guard let id = UUID(uuidString: activeWorkOrderID) else { return nil }
        return openOrders.first(where: { $0.id == id })
    }
    private var pendingSyncCount: Int {
        syncQueue.filter { $0.status != .synchronized && $0.status != .notRequired }.count
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 22) {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    MetricCard(
                        title: "Ersatzteilpositionen",
                        value: String(activeParts.count),
                        systemImage: "shippingbox.fill"
                    )
                    MetricCard(
                        title: "Teile im Bestand",
                        value: String(totalUnits),
                        systemImage: "sum",
                        color: .teal
                    )
                    MetricCard(
                        title: "Unter Mindestbestand",
                        value: String(lowStockParts.count),
                        systemImage: "exclamationmark.triangle.fill",
                        color: lowStockParts.isEmpty ? .green : .orange
                    )
                    MetricCard(
                        title: "Schubladen",
                        value: String(drawers.count),
                        systemImage: "cabinet.fill",
                        color: .indigo
                    )
                }

                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Label("IH2Go / SAP", systemImage: "network")
                            .font(.title3.bold())
                        Spacer()
                        NavigationLink("Aufträge") { SAPOrdersView() }
                            .font(.subheadline)
                    }

                    if let activeOrder {
                        NavigationLink {
                            SAPOrderDetailView(order: activeOrder)
                        } label: {
                            VStack(alignment: .leading, spacing: 5) {
                                Text("Aktiver Auftrag \(activeOrder.orderNumber)")
                                    .font(.headline)
                                Text(activeOrder.customerDisplayName)
                                    .foregroundStyle(.secondary)
                                if !activeOrder.equipmentNumber.isEmpty {
                                    Label(activeOrder.equipmentNumber, systemImage: "gauge.with.dots.needle.50percent")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .buttonStyle(.plain)
                    } else {
                        NavigationLink {
                            SAPOrdersView()
                        } label: {
                            Label("Kundenauftrag auswählen", systemImage: "checklist")
                        }
                    }

                    HStack {
                        Label("Offene Aufträge: \(openOrders.count)", systemImage: "wrench.and.screwdriver")
                        Spacer()
                        Label("Sync: \(pendingSyncCount)", systemImage: pendingSyncCount == 0 ? "checkmark.icloud" : "clock.badge")
                            .foregroundStyle(pendingSyncCount == 0 ? .green : .orange)
                    }
                    .font(.caption)
                }
                .padding()
                .background(Color.blue.opacity(0.07))
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

                if !lowStockParts.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Nachbestellen", systemImage: "bell.badge.fill")
                            .font(.title3.bold())
                            .foregroundStyle(.orange)

                        ForEach(lowStockParts.prefix(5)) { part in
                            NavigationLink {
                                PartDetailView(part: part)
                            } label: {
                                PartRow(part: part, drawerCode: drawerCode(for: part))
                            }
                            .buttonStyle(.plain)
                            Divider()
                        }
                    }
                    .padding()
                    .background(Color.orange.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text("Letzte Buchungen")
                        .font(.title3.bold())

                    if movements.isEmpty {
                        ContentUnavailableView(
                            "Noch keine Buchungen",
                            systemImage: "arrow.left.arrow.right",
                            description: Text("Eingänge und Ausgänge erscheinen hier.")
                        )
                        .frame(minHeight: 180)
                    } else {
                        ForEach(movements.prefix(8)) { movement in
                            if let part = parts.first(where: { $0.id == movement.partID }) {
                                HStack(spacing: 12) {
                                    Image(systemName: movement.kind.systemImage)
                                        .font(.title3)
                                        .foregroundStyle(movement.kind == .outbound ? Color.orange : Color.green)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(part.partName)
                                            .font(.subheadline.weight(.semibold))
                                        Text(movement.timestamp.formatted(date: .abbreviated, time: .shortened))
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Text("\(movement.kind == .outbound ? "−" : "+")\(movement.quantity)")
                                        .font(.headline.monospacedDigit())
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                }
            }
            .padding()
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Gaslager")
    }

    private func drawerCode(for part: SparePart) -> String? {
        guard let drawerID = part.drawerID else { return nil }
        return drawers.first(where: { $0.id == drawerID })?.code
    }
}
