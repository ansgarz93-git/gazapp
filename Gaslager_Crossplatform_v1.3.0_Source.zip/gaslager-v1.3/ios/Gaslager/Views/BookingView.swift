import SwiftUI
import SwiftData
import UIKit

struct BookingHubView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \SAPWorkOrder.updatedAt, order: .reverse) private var workOrders: [SAPWorkOrder]
    @Query private var compatibilities: [PartCompatibility]
    @Query private var equipmentTypes: [EquipmentType]
    @AppStorage(SAPSettingsKey.activeWorkOrderID) private var activeWorkOrderID = ""
    @AppStorage(SAPSettingsKey.orderRequiredForOutbound) private var orderRequiredForOutbound = true
    @State private var movementKind: MovementKind = .inbound
    @State private var manualBarcode = ""
    @State private var scannerPresented = false
    @State private var activeSheet: BookingSheet?
    @State private var errorMessage: String?

    private var activeWorkOrder: SAPWorkOrder? {
        guard let id = UUID(uuidString: activeWorkOrderID) else { return nil }
        return workOrders.first(where: { $0.id == id && !$0.isClosed })
    }

    private var requiresOrderSelection: Bool {
        movementKind == .outbound && orderRequiredForOutbound && activeWorkOrder == nil
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                Picker("Buchungsart", selection: $movementKind) {
                    ForEach(MovementKind.bookableCases) { kind in
                        Text(kind.rawValue).tag(kind)
                    }
                }
                .pickerStyle(.segmented)

                if movementKind == .outbound {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Label("IH2Go-/SAP-Auftrag", systemImage: "wrench.and.screwdriver.fill")
                                .font(.headline)
                            Spacer()
                            NavigationLink("Verwalten") { SAPOrdersView() }
                                .font(.subheadline)
                        }

                        if workOrders.filter({ !$0.isClosed }).isEmpty {
                            Label("Noch kein offener Auftrag vorhanden", systemImage: "exclamationmark.triangle.fill")
                                .foregroundStyle(.orange)
                            NavigationLink {
                                SAPOrdersView()
                            } label: {
                                Label("Auftrag importieren oder anlegen", systemImage: "plus.circle.fill")
                            }
                        } else {
                            Picker("Aktiver Auftrag", selection: $activeWorkOrderID) {
                                if !orderRequiredForOutbound {
                                    Text("Ohne Auftrag").tag("")
                                }
                                ForEach(workOrders.filter { !$0.isClosed }) { order in
                                    Text("\(order.orderNumber) · \(order.customerName)")
                                        .tag(order.id.uuidString)
                                }
                            }
                            .pickerStyle(.menu)

                            if let order = activeWorkOrder {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(order.customerDisplayName)
                                        .font(.subheadline.weight(.semibold))
                                    Text([order.equipmentNumber, equipmentName(for: order)].filter { !$0.isEmpty }.joined(separator: " · "))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                NavigationLink {
                                    CompatibleSparePartsView(order: order)
                                } label: {
                                    Label("Passende Ersatzteilliste öffnen", systemImage: "list.bullet.rectangle")
                                }
                                .disabled(order.equipmentTypeID == nil)
                            }
                        }
                    }
                    .padding()
                    .background(Color(uiColor: .secondarySystemGroupedBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                VStack(spacing: 18) {
                    Image(systemName: movementKind == .inbound ? "arrow.down.circle.fill" : "arrow.up.circle.fill")
                        .font(.system(size: 58))
                        .foregroundStyle(movementKind == .inbound ? Color.green : Color.orange)

                    Text(movementKind == .inbound ? "Wareneingang buchen" : "Ersatzteil entnehmen")
                        .font(.title2.bold())

                    Text("Scanne den Original-Barcode auf der RMG-/Honeywell-Verpackung.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)

                    Button {
                        scannerPresented = true
                    } label: {
                        Label("Barcode scannen", systemImage: "barcode.viewfinder")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 6)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(requiresOrderSelection)
                }
                .padding(24)
                .background(Color(uiColor: .secondarySystemGroupedBackground))
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))

                VStack(alignment: .leading, spacing: 10) {
                    Text("Barcode manuell eingeben")
                        .font(.headline)
                    HStack {
                        TextField("Barcode", text: $manualBarcode)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .textFieldStyle(.roundedBorder)
                            .submitLabel(.done)
                            .onSubmit(openManualBarcode)

                        Button("Öffnen", action: openManualBarcode)
                            .buttonStyle(.bordered)
                            .disabled(BarcodeNormalizer.matchKey(for: manualBarcode).isEmpty || requiresOrderSelection)
                    }
                }
                .padding()
                .background(Color(uiColor: .secondarySystemGroupedBackground))
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

                Label(
                    requiresOrderSelection
                        ? "Wähle zuerst den Kundenauftrag. Danach werden nur Ersatzteile des hinterlegten Reglers/Piloten zugelassen."
                        : "Ein Ausgang wird blockiert, wenn das Teil nicht zum Auftragsgerät passt oder der Bestand nicht ausreicht.",
                    systemImage: "checkmark.shield.fill"
                )
                .font(.footnote)
                .foregroundStyle(.secondary)
            }
            .padding()
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Buchen")
        .fullScreenCover(isPresented: $scannerPresented) {
            BarcodeScannerView { value, symbology in
                Task { @MainActor in
                    scannerPresented = false
                    try? await Task.sleep(for: .milliseconds(250))
                    handleBarcode(value, symbology: symbology)
                }
            }
        }
        .sheet(item: $activeSheet) { sheet in
            switch sheet {
            case .booking(let part, let kind, let barcode, let workOrder):
                BookingFormView(
                    part: part,
                    initialKind: kind,
                    barcodeUsed: barcode,
                    workOrder: workOrder
                )
            case .registration(let barcode, let symbology, let kind):
                PartRegistrationView(
                    initialBarcode: barcode,
                    initialSymbology: symbology,
                    initialKind: kind
                )
            }
        }
        .alert("Barcode konnte nicht geöffnet werden", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "Unbekannter Fehler")
        }
    }

    private func openManualBarcode() {
        handleBarcode(manualBarcode, symbology: "manuell")
    }

    private func handleBarcode(_ barcode: String, symbology: String) {
        do {
            if let part = try InventoryService.resolvePart(for: barcode, in: modelContext) {
                if movementKind == .outbound,
                   let order = activeWorkOrder,
                   let equipmentTypeID = order.equipmentTypeID,
                   !compatibilities.contains(where: {
                       $0.partID == part.id && $0.equipmentTypeID == equipmentTypeID
                   }) {
                    errorMessage = "Das gescannte Ersatzteil ist nicht für den im Auftrag \(order.orderNumber) hinterlegten Regler/Piloten freigegeben."
                    return
                }
                activeSheet = .booking(
                    part: part,
                    kind: movementKind,
                    barcode: barcode,
                    workOrder: movementKind == .outbound ? activeWorkOrder : nil
                )
            } else {
                activeSheet = .registration(barcode: barcode, symbology: symbology, kind: movementKind)
            }
            manualBarcode = ""
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func equipmentName(for order: SAPWorkOrder) -> String {
        guard let equipmentTypeID = order.equipmentTypeID else { return "Reglertyp fehlt" }
        return equipmentTypes.first(where: { $0.id == equipmentTypeID })?.displayName ?? "Reglertyp fehlt"
    }
}

private enum BookingSheet: Identifiable {
    case booking(part: SparePart, kind: MovementKind, barcode: String, workOrder: SAPWorkOrder?)
    case registration(barcode: String, symbology: String, kind: MovementKind)

    var id: String {
        switch self {
        case .booking(let part, let kind, _, let workOrder):
            "booking-\(part.id)-\(kind.rawValue)-\(workOrder?.id.uuidString ?? "lokal")"
        case .registration(let barcode, _, let kind):
            "registration-\(BarcodeNormalizer.matchKey(for: barcode))-\(kind.rawValue)"
        }
    }
}

struct BookingFormView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext

    let part: SparePart
    let barcodeUsed: String
    let explicitWorkOrder: SAPWorkOrder?
    @Query private var workOrders: [SAPWorkOrder]
    @Query private var mappings: [SAPMaterialMapping]
    @Query private var compatibilities: [PartCompatibility]
    @AppStorage(SAPSettingsKey.activeWorkOrderID) private var activeWorkOrderID = ""
    @AppStorage(SAPSettingsKey.orderRequiredForOutbound) private var orderRequiredForOutbound = true
    @AppStorage(SAPSettingsKey.inventorySyncEnabled) private var inventorySyncEnabled = true
    @AppStorage(SAPSettingsKey.defaultPlant) private var defaultPlant = ""
    @AppStorage(SAPSettingsKey.defaultStorageLocation) private var defaultStorageLocation = ""
    @State private var kind: MovementKind
    @State private var quantity = 1
    @State private var reference = ""
    @State private var notes = ""
    @State private var errorMessage: String?

    init(
        part: SparePart,
        initialKind: MovementKind,
        barcodeUsed: String,
        workOrder: SAPWorkOrder? = nil
    ) {
        self.part = part
        self.barcodeUsed = barcodeUsed
        self.explicitWorkOrder = workOrder
        _kind = State(initialValue: initialKind)
        _reference = State(initialValue: workOrder?.orderNumber ?? "")
    }

    private var projectedStock: Int {
        part.stockQuantity + quantity * kind.signedMultiplier
    }

    private var selectedWorkOrder: SAPWorkOrder? {
        if let explicitWorkOrder { return explicitWorkOrder }
        guard let id = UUID(uuidString: activeWorkOrderID) else { return nil }
        return workOrders.first(where: { $0.id == id && !$0.isClosed })
    }

    private var materialMapping: SAPMaterialMapping? {
        mappings.first(where: { $0.partID == part.id })
    }

    private var isCompatibleWithOrder: Bool {
        guard kind == .outbound, let order = selectedWorkOrder,
              let equipmentTypeID = order.equipmentTypeID else { return true }
        return compatibilities.contains {
            $0.partID == part.id && $0.equipmentTypeID == equipmentTypeID
        }
    }

    private var canBook: Bool {
        guard quantity > 0, projectedStock >= 0, isCompatibleWithOrder else { return false }
        if kind == .outbound && orderRequiredForOutbound && selectedWorkOrder == nil { return false }
        return true
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Ersatzteil") {
                    LabeledContent("Bezeichnung", value: part.partName)
                    LabeledContent("Hersteller", value: part.manufacturer)
                    LabeledContent("Original Art.-Nr.", value: part.originalArticleNumber)
                    LabeledContent("Aktueller Bestand", value: "\(part.stockQuantity) \(part.unit)")
                }

                Section("Buchung") {
                    Picker("Buchungsart", selection: $kind) {
                        ForEach(MovementKind.bookableCases) { kind in
                            Text(kind.rawValue).tag(kind)
                        }
                    }
                    TextField("Menge", value: $quantity, format: .number)
                        .keyboardType(.numberPad)
                    Stepper("Menge: \(quantity)", value: $quantity, in: 1...99_999)
                    LabeledContent("Bestand danach") {
                        Text("\(projectedStock) \(part.unit)")
                            .foregroundStyle(projectedStock < 0 ? Color.red : Color.primary)
                            .fontWeight(.semibold)
                    }
                }

                if kind == .outbound {
                    Section("Kundenauftrag") {
                        if let order = selectedWorkOrder {
                            LabeledContent("SAP-Auftrag", value: order.orderNumber)
                            LabeledContent("Kunde", value: order.customerDisplayName)
                            if !order.equipmentNumber.isEmpty {
                                LabeledContent("Equipment", value: order.equipmentNumber)
                            }
                            if !isCompatibleWithOrder {
                                Label("Dieses Teil passt nicht zum Auftragsgerät.", systemImage: "xmark.shield.fill")
                                    .foregroundStyle(.red)
                            }
                        } else {
                            Label("Kein SAP-Auftrag ausgewählt", systemImage: "exclamationmark.triangle.fill")
                                .foregroundStyle(orderRequiredForOutbound ? .red : .orange)
                        }
                    }
                }

                Section("IH2Go / SAP") {
                    if let mapping = materialMapping {
                        LabeledContent("Materialnummer", value: mapping.materialNumber)
                        LabeledContent("Werk", value: resolvedPlant(mapping: mapping).isEmpty ? "–" : resolvedPlant(mapping: mapping))
                        LabeledContent("Lagerort", value: resolvedStorageLocation(mapping: mapping).isEmpty ? "–" : resolvedStorageLocation(mapping: mapping))
                        if let stock = mapping.lastSAPStockQuantity {
                            LabeledContent("Letzter SAP-Bestand", value: "\(stock) \(part.unit)")
                        }
                    } else {
                        Label("SAP-Materialnummer fehlt – Buchung bleibt in der Warteschlange.", systemImage: "link.badge.plus")
                            .foregroundStyle(.orange)
                    }
                    LabeledContent("Synchronisation", value: inventorySyncEnabled ? "Aktiv" : "Nur lokal")
                }

                Section("Nachweis (optional)") {
                    TextField("Auftrag / Entnahmeschein", text: $reference)
                    TextField("Notiz", text: $notes, axis: .vertical)
                        .lineLimit(2...5)
                }

                if kind == .outbound && projectedStock < 0 {
                    Section {
                        Label("Nicht genügend Bestand vorhanden.", systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle(kind.rawValue)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Buchen", action: save)
                        .fontWeight(.semibold)
                        .disabled(!canBook)
                }
            }
            .alert("Buchung fehlgeschlagen", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
        }
    }

    private func save() {
        do {
            let result = try InventoryService.performMovement(
                for: part,
                kind: kind,
                quantity: quantity,
                reference: reference,
                notes: notes,
                barcodeUsed: barcodeUsed,
                sapContext: makeSAPContext(),
                in: modelContext
            )

            if result.shouldRemoveLowStockReminder {
                LowStockNotificationService.removeLowStockReminder(for: part.id)
            }
            if result.shouldSendLowStockReminder {
                Task { @MainActor in
                    let sent = await LowStockNotificationService.scheduleLowStockReminder(for: part)
                    if !sent {
                        part.lowStockAlerted = false
                        try? modelContext.save()
                    }
                }
            }

            UINotificationFeedbackGenerator().notificationOccurred(.success)
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
            UINotificationFeedbackGenerator().notificationOccurred(.error)
        }
    }

    private func makeSAPContext() -> SAPBookingContext {
        let order = kind == .outbound ? selectedWorkOrder : nil
        let mapping = materialMapping
        return SAPBookingContext(
            workOrderID: order?.id,
            orderNumber: order?.orderNumber ?? "",
            customerNumber: order?.customerNumber ?? "",
            equipmentNumber: order?.equipmentNumber ?? "",
            materialNumber: mapping?.materialNumber ?? "",
            plant: resolvedPlant(mapping: mapping),
            storageLocation: resolvedStorageLocation(mapping: mapping),
            syncRequested: inventorySyncEnabled
        )
    }

    private func resolvedPlant(mapping: SAPMaterialMapping?) -> String {
        if let plant = selectedWorkOrder?.plant, !plant.isEmpty { return plant }
        if let plant = mapping?.plant, !plant.isEmpty { return plant }
        return defaultPlant
    }

    private func resolvedStorageLocation(mapping: SAPMaterialMapping?) -> String {
        if let location = selectedWorkOrder?.storageLocation, !location.isEmpty { return location }
        if let location = mapping?.storageLocation, !location.isEmpty { return location }
        return defaultStorageLocation
    }
}

struct PartRegistrationView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Drawer.code) private var drawers: [Drawer]
    @Query(sort: \EquipmentType.designation) private var equipmentTypes: [EquipmentType]
    @AppStorage(SAPSettingsKey.defaultPlant) private var defaultPlant = ""
    @AppStorage(SAPSettingsKey.defaultStorageLocation) private var defaultStorageLocation = ""
    @AppStorage(SAPSettingsKey.inventorySyncEnabled) private var inventorySyncEnabled = true

    let initialKind: MovementKind
    @State private var barcode: String
    @State private var symbology: String
    @State private var manufacturer = "Honeywell / RMG"
    @State private var articleNumber = ""
    @State private var partName = ""
    @State private var unit = "Stück"
    @State private var selectedDrawerID: UUID?
    @State private var deviceSparePartNumber = ""
    @State private var initialQuantity: Int
    @State private var minimumStock = 0
    @State private var reminderEnabled = false
    @State private var notes = ""
    @State private var sapMaterialNumber = ""
    @State private var sapPlant = ""
    @State private var sapStorageLocation = ""
    @State private var sapBaseUnit = "ST"
    @State private var errorMessage: String?
    @State private var notificationDenied = false

    init(initialBarcode: String, initialSymbology: String = "", initialKind: MovementKind = .inbound) {
        self.initialKind = initialKind
        _barcode = State(initialValue: initialBarcode)
        _symbology = State(initialValue: initialSymbology)
        _initialQuantity = State(initialValue: initialKind == .inbound ? 1 : 0)
    }

    private var selectedDrawer: Drawer? {
        guard let selectedDrawerID else { return nil }
        return drawers.first(where: { $0.id == selectedDrawerID })
    }

    private var selectedEquipment: EquipmentType? {
        guard let equipmentID = selectedDrawer?.equipmentTypeID else { return nil }
        return equipmentTypes.first(where: { $0.id == equipmentID })
    }

    private var canSave: Bool {
        !BarcodeNormalizer.matchKey(for: barcode).isEmpty &&
        !manufacturer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !articleNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !partName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        (selectedDrawerID == nil || !deviceSparePartNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Originalkennzeichnung") {
                    TextField("Barcode", text: $barcode)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    if !symbology.isEmpty {
                        LabeledContent("Barcode-Typ", value: symbology)
                    }
                    TextField("Hersteller", text: $manufacturer)
                    TextField("Original-Artikelnummer", text: $articleNumber)
                    TextField("Bezeichnung", text: $partName)
                    TextField("Einheit", text: $unit)
                }

                Section("Schublade und Gerät") {
                    Picker("Schublade", selection: $selectedDrawerID) {
                        Text("Noch nicht zugeordnet").tag(Optional<UUID>.none)
                        ForEach(drawers) { drawer in
                            Text(drawer.displayName).tag(Optional(drawer.id))
                        }
                    }

                    if let equipment = selectedEquipment {
                        LabeledContent(equipment.kind.rawValue, value: equipment.displayName)
                        TextField("Ersatzteilnummer an diesem Gerät", text: $deviceSparePartNumber)
                    } else if drawers.isEmpty {
                        Label(
                            "Lege im Bereich Schubladen zuerst einen Regler- oder Pilottyp an.",
                            systemImage: "info.circle"
                        )
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    }
                }

                Section("Bestand") {
                    if initialKind == .inbound {
                        Stepper("Eingang: \(initialQuantity) \(unit)", value: $initialQuantity, in: 0...99_999)
                    } else {
                        Text("Ein unbekanntes Teil wird zunächst mit Bestand 0 angelegt. Danach ist ein Ausgang erst möglich, wenn ein Eingang gebucht wurde.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    Stepper("Mindestbestand: \(minimumStock)", value: $minimumStock, in: 0...99_999)
                    Toggle("Erinnerung bei Mindestbestand", isOn: $reminderEnabled)
                }

                Section("IH2Go / SAP (optional)") {
                    TextField("SAP-Materialnummer", text: $sapMaterialNumber)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                    TextField("Werk", text: $sapPlant)
                    TextField("SAP-Lagerort", text: $sapStorageLocation)
                    TextField("SAP-Basiseinheit", text: $sapBaseUnit)
                        .textInputAutocapitalization(.characters)
                }

                Section("Notiz") {
                    TextField("Optional", text: $notes, axis: .vertical)
                        .lineLimit(2...5)
                }
            }
            .navigationTitle("Ersatzteil anlegen")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern", action: save)
                        .fontWeight(.semibold)
                        .disabled(!canSave)
                }
            }
            .onChange(of: reminderEnabled) { _, isEnabled in
                guard isEnabled else { return }
                Task { @MainActor in
                    if await LowStockNotificationService.authorizationState() == .notDetermined {
                        let granted = await LowStockNotificationService.requestAuthorization()
                        if !granted {
                            reminderEnabled = false
                            notificationDenied = true
                        }
                    } else if await LowStockNotificationService.authorizationState() == .denied {
                        reminderEnabled = false
                        notificationDenied = true
                    }
                }
            }
            .onAppear {
                if sapPlant.isEmpty { sapPlant = defaultPlant }
                if sapStorageLocation.isEmpty { sapStorageLocation = defaultStorageLocation }
            }
            .alert("Speichern nicht möglich", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
            .alert("Benachrichtigungen sind deaktiviert", isPresented: $notificationDenied) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Erlaube Benachrichtigungen in den iOS-Einstellungen, um Mindestbestandswarnungen zu erhalten.")
            }
        }
    }

    private func save() {
        do {
            let result = try InventoryService.registerPart(
                PartRegistrationInput(
                    barcode: barcode,
                    symbology: symbology,
                    manufacturer: manufacturer,
                    originalArticleNumber: articleNumber,
                    partName: partName,
                    unit: unit,
                    drawerID: selectedDrawer?.id,
                    equipmentTypeID: selectedEquipment?.id,
                    deviceSparePartNumber: deviceSparePartNumber,
                    initialQuantity: initialQuantity,
                    minimumStock: minimumStock,
                    reminderEnabled: reminderEnabled,
                    notes: notes,
                    sapMaterialNumber: sapMaterialNumber,
                    sapPlant: sapPlant,
                    sapStorageLocation: sapStorageLocation,
                    sapBaseUnit: sapBaseUnit,
                    sapSyncRequested: inventorySyncEnabled
                ),
                in: modelContext
            )

            if result.shouldSendLowStockReminder {
                Task { @MainActor in
                    let sent = await LowStockNotificationService.scheduleLowStockReminder(for: result.part)
                    if !sent {
                        result.part.lowStockAlerted = false
                        try? modelContext.save()
                    }
                }
            }

            UINotificationFeedbackGenerator().notificationOccurred(.success)
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
