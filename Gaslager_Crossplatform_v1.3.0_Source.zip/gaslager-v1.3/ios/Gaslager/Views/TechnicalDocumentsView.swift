import SwiftUI
import SwiftData
import UniformTypeIdentifiers
import SafariServices
import PDFKit

struct TechnicalDocumentsView: View {
    @Environment(\.modelContext) private var modelContext
    let equipment: EquipmentType
    @Query private var documents: [TechnicalDocument]

    @State private var importerPresented = false
    @State private var linkFormPresented = false
    @State private var preview: DocumentPreview?
    @State private var errorMessage: String?

    init(equipment: EquipmentType) {
        self.equipment = equipment
        let equipmentID = equipment.id
        _documents = Query(
            filter: #Predicate<TechnicalDocument> { document in
                document.equipmentTypeID == equipmentID
            },
            sort: \TechnicalDocument.title
        )
    }

    private var missingSuggestions: [SuggestedManufacturerDocument] {
        ManufacturerDocumentCatalog.suggestions(for: equipment).filter { suggestion in
            !documents.contains(where: { $0.sourceURL == suggestion.url })
        }
    }

    var body: some View {
        List {
            Section {
                LabeledContent(equipment.kind.rawValue, value: equipment.displayName)
            }

            if !missingSuggestions.isEmpty {
                Section("Gefundene Herstellerquellen") {
                    ForEach(missingSuggestions) { suggestion in
                        Button {
                            addSuggestion(suggestion)
                        } label: {
                            Label(suggestion.title, systemImage: "plus.circle.fill")
                        }
                    }
                    Text("Die Zuordnung erfolgt ausschließlich bei einer eindeutigen Typbezeichnung.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Section("Zugeordnete Unterlagen") {
                if documents.isEmpty {
                    ContentUnavailableView(
                        "Keine Unterlagen",
                        systemImage: "doc.text.magnifyingglass",
                        description: Text("Importiere PDFs oder verknüpfe offizielle Herstellerseiten.")
                    )
                    .frame(minHeight: 180)
                } else {
                    ForEach(documents) { document in
                        Button {
                            open(document)
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: document.kind.systemImage)
                                    .font(.title3)
                                    .foregroundStyle(document.isLocal ? Color.red : Color.blue)
                                    .frame(width: 28)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(document.title)
                                        .foregroundStyle(.primary)
                                    HStack(spacing: 5) {
                                        Text(document.kind.rawValue)
                                        if document.isOfficialManufacturerSource {
                                            Text("· Offizielle Quelle")
                                        }
                                        if document.isLocal {
                                            Text("· Offline")
                                        }
                                    }
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(.tertiary)
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Herstellerunterlagen")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Menu {
                    Button {
                        importerPresented = true
                    } label: {
                        Label("PDF importieren", systemImage: "square.and.arrow.down")
                    }
                    Button {
                        linkFormPresented = true
                    } label: {
                        Label("Weblink hinzufügen", systemImage: "link.badge.plus")
                    }
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .fileImporter(
            isPresented: $importerPresented,
            allowedContentTypes: [.pdf],
            allowsMultipleSelection: false
        ) { result in
            importPDF(result)
        }
        .sheet(isPresented: $linkFormPresented) {
            NewDocumentLinkView(equipment: equipment)
        }
        .sheet(item: $preview) { item in
            switch item {
            case .web(let url):
                SafariView(url: url)
                    .ignoresSafeArea()
            case .pdf(let url, let title):
                NavigationStack {
                    PDFDocumentView(url: url)
                        .navigationTitle(title)
                        .navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .confirmationAction) {
                                Button("Fertig") { preview = nil }
                            }
                        }
                }
            }
        }
        .alert("Unterlage konnte nicht geöffnet werden", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "Unbekannter Fehler")
        }
    }

    private func addSuggestion(_ suggestion: SuggestedManufacturerDocument) {
        modelContext.insert(
            TechnicalDocument(
                equipmentTypeID: equipment.id,
                title: suggestion.title,
                kind: suggestion.kind,
                sourceURL: suggestion.url,
                isOfficialManufacturerSource: true
            )
        )
        do {
            try modelContext.save()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func importPDF(_ result: Result<[URL], Error>) {
        do {
            guard let sourceURL = try result.get().first else { return }
            let fileName = try TechnicalDocumentStorage.importPDF(from: sourceURL)
            let document = TechnicalDocument(
                equipmentTypeID: equipment.id,
                title: sourceURL.deletingPathExtension().lastPathComponent,
                kind: .operatingInstructions,
                localFileName: fileName
            )
            modelContext.insert(document)
            try modelContext.save()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func open(_ document: TechnicalDocument) {
        if document.isLocal {
            guard let url = TechnicalDocumentStorage.localURL(for: document.localFileName) else {
                errorMessage = "Die lokal gespeicherte PDF-Datei wurde nicht gefunden."
                return
            }
            preview = .pdf(url: url, title: document.title)
        } else if let url = URL(string: document.sourceURL), ["http", "https"].contains(url.scheme?.lowercased() ?? "") {
            preview = .web(url: url)
        } else {
            errorMessage = "Die hinterlegte Internetadresse ist ungültig."
        }
    }
}

private enum DocumentPreview: Identifiable {
    case web(url: URL)
    case pdf(url: URL, title: String)

    var id: String {
        switch self {
        case .web(let url): "web-\(url.absoluteString)"
        case .pdf(let url, _): "pdf-\(url.path)"
        }
    }
}

private struct NewDocumentLinkView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    let equipment: EquipmentType

    @State private var title = ""
    @State private var kind: TechnicalDocumentKind = .brochure
    @State private var urlText = ""
    @State private var officialSource = true
    @State private var errorMessage: String?

    private var parsedURL: URL? {
        guard let url = URL(string: urlText.trimmingCharacters(in: .whitespacesAndNewlines)),
              ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { return nil }
        return url
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Unterlage") {
                    TextField("Titel", text: $title)
                    Picker("Art", selection: $kind) {
                        ForEach(TechnicalDocumentKind.allCases) { kind in
                            Text(kind.rawValue).tag(kind)
                        }
                    }
                    TextField("https://…", text: $urlText, axis: .vertical)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    Toggle("Offizielle Herstellerquelle", isOn: $officialSource)
                }
            }
            .navigationTitle("Weblink hinzufügen")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern", action: save)
                        .disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || parsedURL == nil)
                }
            }
            .alert("Speichern fehlgeschlagen", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
        }
    }

    private func save() {
        guard let parsedURL else { return }
        modelContext.insert(
            TechnicalDocument(
                equipmentTypeID: equipment.id,
                title: title.trimmingCharacters(in: .whitespacesAndNewlines),
                kind: kind,
                sourceURL: parsedURL.absoluteString,
                isOfficialManufacturerSource: officialSource
            )
        )
        do {
            try modelContext.save()
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

struct ManufacturerResourcesView: View {
    @State private var selectedURL: IdentifiableURL?

    var body: some View {
        List {
            Section("Honeywell Gas") {
                resourceButton(
                    "Original-Ersatzteile und Zubehör",
                    detail: "Offizieller Ersatzteilbereich",
                    url: ManufacturerDocumentCatalog.sparePartsPage
                )
                resourceButton(
                    "Regler und Sicherheitseinrichtungen",
                    detail: "Produktübersicht und Broschüren",
                    url: ManufacturerDocumentCatalog.regulatorsPage
                )
                resourceButton(
                    "Piloten für Gasdruckregler",
                    detail: "Produktübersicht und Broschüren",
                    url: ManufacturerDocumentCatalog.pilotsPage
                )
            }

            Section {
                Text("Ein Teil der Ersatzteillisten ist bei Honeywell erst nach Anmeldung oder über den zuständigen Ansprechpartner verfügbar. Solche PDFs können anschließend einem Gerätetyp offline zugeordnet werden.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Herstellerquellen")
        .sheet(item: $selectedURL) { item in
            SafariView(url: item.url)
                .ignoresSafeArea()
        }
    }

    private func resourceButton(_ title: String, detail: String, url: String) -> some View {
        Button {
            if let url = URL(string: url) { selectedURL = IdentifiableURL(url: url) }
        } label: {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text(title)
                        .foregroundStyle(.primary)
                    Text(detail)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "arrow.up.right.square")
            }
        }
    }
}

private struct IdentifiableURL: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

private struct SafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }

    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}

private struct PDFDocumentView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> PDFView {
        let view = PDFView()
        view.autoScales = true
        view.displayMode = .singlePageContinuous
        view.displayDirection = .vertical
        view.document = PDFDocument(url: url)
        return view
    }

    func updateUIView(_ uiView: PDFView, context: Context) {}
}
