import SwiftUI

struct StockBadge: View {
    let part: SparePart

    var body: some View {
        Text("\(part.stockQuantity) \(part.unit)")
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 9)
            .padding(.vertical, 5)
            .foregroundStyle(part.isLowStock ? Color.red : Color.primary)
            .background(part.isLowStock ? Color.red.opacity(0.13) : Color.secondary.opacity(0.12))
            .clipShape(Capsule())
            .accessibilityLabel("Bestand \(part.stockQuantity) \(part.unit)")
    }
}

struct MetricCard: View {
    let title: String
    let value: String
    let systemImage: String
    var color: Color = .blue

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: systemImage)
                .font(.title3)
                .foregroundStyle(color)
            Text(value)
                .font(.title2.bold())
                .contentTransition(.numericText())
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

struct PartRow: View {
    let part: SparePart
    let drawerCode: String?

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: part.isLowStock ? "exclamationmark.triangle.fill" : "shippingbox.fill")
                .frame(width: 28)
                .foregroundStyle(part.isLowStock ? Color.orange : Color.blue)

            VStack(alignment: .leading, spacing: 3) {
                Text(part.partName)
                    .font(.headline)
                    .lineLimit(2)
                Text("\(part.manufacturer) · \(part.originalArticleNumber)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                if let drawerCode {
                    Text("Schublade \(drawerCode)")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer(minLength: 8)
            StockBadge(part: part)
        }
        .padding(.vertical, 3)
    }
}
