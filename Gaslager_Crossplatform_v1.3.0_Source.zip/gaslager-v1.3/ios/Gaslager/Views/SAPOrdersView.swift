import SwiftUI
import SwiftData
import UniformTypeIdentifiers

struct SAPOrdersView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \SAPWorkOrder.updatedAt, order: .reverse) private var orders: [SAPWorkOrder]
    @Query private var queueItems: [SAPSyncQueueItem]

    @AppStorage(SAPSettingsKey.activeWorkOrderID) private var activeWorkOrderID = ""
    @State private var searchText = ""
    @State private var importerPresented = false
    @State private var editorPresented = false
    @State private var isSynchronizing = false
    @State private var resultMessage: String?
    @State private var errorMessage: String?

    private var filteredOrders: [SAPWorkOrder] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return orders }
        return orders.filter {
            $0.orderNumber.localizedCaseInsensitiveContains(query) ||
            $0.customerNumber.localizedCaseInsensitiveContains(query) ||
            $0.customerName.localizedCaseInsensitiveContains(query) ||
            $0.equipmentNumber.localizedCaseInsensitiveContains(query) ||
            $0.shortText.localizedCaseInsensitiveContains(query)
        }
    }

    private var pendingCount: Int {
        queueItems.filter { $0.status != .synchronized && $0.status != .notRequired }.count
    }

    var body: some View {
        Group {
            if orders.isEmpty {
                ContentUnavailableView {
                    Label("Noch keine SAP-Aufträge", systemImage: "wrench.and.screwdriver")
                } description: {
                    Text("Synchronisiere die IH2Go-Bridge, importiere eine Auftragsdatei oder lege einen Testauftrag manuell an.")
                } actions: {
                    Button("Auftragsdatei importieren") { importerPresented = true }
                        .buttonStyle(.borderedProminent)
                    Button("Auftrag manuell anlegen") { editorPresented = true }
                        .buttonStyle(.bordered)
                }
            } else {
                List {
                    if pendingCount > 0 {
                        Section {
                            NavigationLink {
                                SAPSyncQueueView()
                            } label: {
                                Label("\(pendingCount) Buchung(en) warten auf SAP", systemImage: "arrow.triangle.2.circlepath")
                                    .foregroundStyle(.orange)
                            }
                        }
                    }

                    Section("Aufträge") {
                        ForEach(filteredOrders) { order in
                            NavigationLink {
                                SAPOrderDetailView(order: order)
                            } label: {
                                SAPWorkOrderRow(
                                    order: order,
                                    isActive: activeWorkOrderID == order.id.uuidString
                                )
                            }
                            .swipeActions(edge: .leading, allowsFullSwipe: true) {
                                Button {
                                    activeWorkOrderID = order.id.uuidString
                                } label: {
                                    Label("Aktiv", systemImage: "checkmark.circle.fill")
                                }
                                .tint(.blue)
                            }
                        }
                    }
                }
                .overlay {
                    if filteredOrders.isEmpty { ContentUnavailableView.search(text: searchText) }
                }
            }
        }
        .navigationTitle("SAP-Aufträge")
        .searchable(text: $searchText, prompt: "Auftrag, Kunde oder Equipment")
        .toolbar {
            ToolbarItemGroup(placement: .primaryAction) {
                Button(action: synchronize) {
                    if isSynchronizing {
                        ProgressView()
                    } else {
                        Image(systemName: "arrow.triangle.2.circlepath")
                    }
                }
                .disabled(isSynchronizing)
                .accessibilityLabel("Mit IH2Go und SAP synchronisieren")

                Menu {
                    Button {
                        importerPresented = true
                    } label: {
                        Label("JSON-Auftragsdatei importieren", systemImage: "square.and.arrow.down")
                    }
                    Button {
                        editorPresented = true
                    } label: {
                        Label("Auftrag manuell anlegen", systemImage: "square.and.pencil")
                    }
                    NavigationLink {
                        SAPConnectionSettingsView()
                    } label: {
                        Label("Schnittstelle konfigurieren", systemImage: "network")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .fileImporter(
            isPresented: $importerPresented,
            allowedContentTypes: [.json],
            allowsMultipleSelection: false
        ) { result in
            importOrders(result)
        }
        .sheet(isPresented: $editorPresented) {
            SAPManualOrderView { order in
                activeWorkOrderID = order.id.uuidString
            }
        }
        .alert("IH2Go/SAP", isPresented: Binding(
            get: { resultMessage != nil },
            set: { if !$0 { resultMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(resultMessage ?? "")
        }
        .alert("Vorgang fehlgeschlagen", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "Unbekannter Fehler")
        }
    }

    private func synchronize() {
        isSynchronizing = true
        Task { @MainActor in
            defer { isSynchronizing = false }
            do {
                let report = try await SAPIntegrationService.synchronize(in: modelContext)
                resultMessage = report.summary
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func importOrders(_ result: Result<[URL], Error>) {
        do {
            guard let url = try result.get().first else { return }
            let count = try SAPIntegrationService.importWorkOrders(from: url, into: modelContext)
            resultMessage = "\(count) Auftrag/Aufträge wurden übernommen."
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

private struct SAPWorkOrderRow: View {
    let order: SAPWorkOrder
    let isActive: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: isActive ? "checkmark.circle.fill" : order.status.systemImage)
                .font(.title3)
                .foregroundStyle(isActive ? Color.blue : Color.secondary)
                .frame(width: 26)

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("Auftrag \(order.orderNumber)")
                        .font(.headline)
                    if isActive {
                        Text("AKTIV")
                            .font(.caption2.bold())
                            .foregroundStyle(.blue)
                    }
                }
                Text(order.customerDisplayName)
                    .font(.subheadline)
                if !order.equipmentNumber.isEmpty || !order.shortText.isEmpty {
                    Text([order.equipmentNumber, order.shortText].filter { !$0.isEmpty }.joined(separator: " · "))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
            }
        }
        .padding(.vertical, 3)
    }
}

struct SAPOrderDetailView: View {
    let order: SAPWorkOrder
    @Query private var components: [SAPOrderComponent]
    @Query private var equipmentTypes: [EquipmentType]
    @AppStorage(SAPSettingsKey.activeWorkOrderID) private var activeWorkOrderID = ""

    init(order: SAPWorkOrder) {
        self.order = order
        let orderID = order.id
        _components = Query(
            filter: #Predicate<SAPOrderComponent> { $0.workOrderID == orderID },
            sort: \SAPOrderComponent.itemNumber
        )
    }

    private var equipmentType: EquipmentType? {
        guard let equipmentTypeID = order.equipmentTypeID else { return nil }
        return equipmentTypes.first(where: { $0.id == equipmentTypeID })
    }

    var body: some View {
        List {
            Section {
                Button {
                    activeWorkOrderID = order.id.uuidString
                } label: {
                    Label(
                        activeWorkOrderID == order.id.uuidString ? "Aktiver Auftrag" : "Für Buchungen auswählen",
                        systemImage: activeWorkOrderID == order.id.uuidString ? "checkmark.circle.fill" : "circle"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .disabled(order.isClosed)

                NavigationLink {
                    CompatibleSparePartsView(order: order)
                } label: {
                    Label("Passende Ersatzteile anzeigen", systemImage: "shippingbox.and.arrow.backward.fill")
                }
                .disabled(equipmentType == nil)
            }

            Section("Auftrag") {
                LabeledContent("SAP-Auftrag", value: order.orderNumber)
                LabeledContent("Status", value: order.status.rawValue)
                if !order.shortText.isEmpty { LabeledContent("Kurztext", value: order.shortText) }
                if let plannedStart = order.plannedStart {
                    LabeledContent("Geplant", value: plannedStart.formatted(date: .abbreviated, time: .omitted))
                }
                LabeledContent("Quelle", value: order.sourceSystem)
            }

            Section("Kunde und technisches Objekt") {
                LabeledContent("Kunde", value: order.customerDisplayName)
                if !order.equipmentNumber.isEmpty { LabeledContent("Equipment", value: order.equipmentNumber) }
                if !order.functionalLocation.isEmpty { LabeledContent("Technischer Platz", value: order.functionalLocation) }
                if let equipmentType {
                    LabeledContent(equipmentType.kind.rawValue, value: equipmentType.displayName)
                } else {
                    Label("Kein Regler-/Pilottyp zugeordnet", systemImage: "exclamationmark.triangle.fill")
                        .foregroundStyle(.orange)
                }
            }

            Section("Werk und Lagerort") {
                LabeledContent("Werk", value: order.plant.isEmpty ? "–" : order.plant)
                LabeledContent("Lagerort", value: order.storageLocation.isEmpty ? "–" : order.storageLocation)
            }

            Section("SAP-Komponenten") {
                if components.isEmpty {
                    Text("Für diesen Auftrag wurden keine geplanten Materialkomponenten geliefert.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(components) { component in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(component.descriptionText.isEmpty ? component.materialNumber : component.descriptionText)
                                .font(.headline)
                            Text("Material \(component.materialNumber) · Position \(component.itemNumber)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text("Bedarf \(component.requiredQuantity) · entnommen \(component.withdrawnQuantity) · offen \(component.remainingQuantity)")
                                .font(.caption.monospacedDigit())
                        }
                        .padding(.vertical, 3)
                    }
                }
            }
        }
        .navigationTitle("Auftrag \(order.orderNumber)")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct CompatibleSparePartsView: View {
    let order: SAPWorkOrder
    @Query(sort: \SparePart.partName) private var parts: [SparePart]
    @Query private var compatibilities: [PartCompatibility]
    @Query private var mappings: [SAPMaterialMapping]
    @Query private var components: [SAPOrderComponent]
    @Query private var barcodes: [PartBarcode]
    @Query private var drawers: [Drawer]

    @State private var searchText = ""
    @State private var selectedPart: SparePart?

    private var orderComponents: [SAPOrderComponent] {
        components.filter { $0.workOrderID == order.id }
    }

    private var compatibleParts: [SparePart] {
        guard let equipmentTypeID = order.equipmentTypeID else { return [] }
        let compatibleIDs = Set(
            compatibilities.filter { $0.equipmentTypeID == equipmentTypeID }.map(\.partID)
        )
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        return parts.filter { part in
            guard !part.isArchived, compatibleIDs.contains(part.id) else { return false }
            guard !query.isEmpty else { return true }
            let mapping = mappings.first(where: { $0.partID == part.id })
            return part.partName.localizedCaseInsensitiveContains(query) ||
                part.originalArticleNumber.localizedCaseInsensitiveContains(query) ||
                (mapping?.materialNumber.localizedCaseInsensitiveContains(query) ?? false)
        }
        .sorted { lhs, rhs in
            let lhsPlanned = orderComponents.contains { $0.partID == lhs.id }
            let rhsPlanned = orderComponents.contains { $0.partID == rhs.id }
            if lhsPlanned != rhsPlanned { return lhsPlanned }
            if (lhs.stockQuantity > 0) != (rhs.stockQuantity > 0) { return lhs.stockQuantity > 0 }
            return lhs.partName.localizedStandardCompare(rhs.partName) == .orderedAscending
        }
    }

    var body: some View {
        Group {
            if compatibleParts.isEmpty {
                ContentUnavailableView(
                    "Keine passenden Ersatzteile",
                    systemImage: "shippingbox",
                    description: Text("Prüfe die Reglerzuordnung des Auftrags und die gerätespezifischen Ersatzteilnummern im Teilekatalog.")
                )
            } else {
                List(compatibleParts) { part in
                    Button {
                        if part.stockQuantity > 0 { selectedPart = part }
                    } label: {
                        VStack(alignment: .leading, spacing: 7) {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(part.partName)
                                        .font(.headline)
                                        .foregroundStyle(.primary)
                                    Text("Original \(part.originalArticleNumber)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                StockBadge(part: part)
                            }

                            HStack(spacing: 10) {
                                if let deviceNumber = deviceNumber(for: part) {
                                    Label(deviceNumber, systemImage: "wrench.adjustable")
                                }
                                if let mapping = mapping(for: part) {
                                    Label(mapping.materialNumber, systemImage: "link")
                                }
                                if let drawer = drawer(for: part) {
                                    Label(drawer.code, systemImage: "cabinet.fill")
                                }
                            }
                            .font(.caption)
                            .foregroundStyle(.secondary)

                            if let component = orderComponents.first(where: { $0.partID == part.id }) {
                                Text("Im SAP-Auftrag geplant: noch \(component.remainingQuantity)")
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(.blue)
                            }
                            if part.stockQuantity == 0 {
                                Label("Nicht verfügbar", systemImage: "xmark.circle")
                                    .font(.caption)
                                    .foregroundStyle(.red)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    .buttonStyle(.plain)
                    .disabled(part.stockQuantity == 0)
                }
            }
        }
        .navigationTitle("Passende Ersatzteile")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $searchText, prompt: "Teil oder Materialnummer")
        .sheet(item: $selectedPart) { part in
            BookingFormView(
                part: part,
                initialKind: .outbound,
                barcodeUsed: barcodes.first(where: { $0.partID == part.id && $0.isPrimary })?.value ?? "",
                workOrder: order
            )
        }
    }

    private func deviceNumber(for part: SparePart) -> String? {
        guard let equipmentTypeID = order.equipmentTypeID else { return nil }
        return compatibilities.first {
            $0.partID == part.id && $0.equipmentTypeID == equipmentTypeID
        }?.deviceSparePartNumber
    }

    private func mapping(for part: SparePart) -> SAPMaterialMapping? {
        mappings.first(where: { $0.partID == part.id })
    }

    private func drawer(for part: SparePart) -> Drawer? {
        guard let drawerID = part.drawerID else { return nil }
        return drawers.first(where: { $0.id == drawerID })
    }
}

private struct SAPManualOrderView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \EquipmentType.designation) private var equipmentTypes: [EquipmentType]
    @AppStorage(SAPSettingsKey.defaultPlant) private var defaultPlant = ""
    @AppStorage(SAPSettingsKey.defaultStorageLocation) private var defaultStorageLocation = ""

    let onSave: (SAPWorkOrder) -> Void
    @State private var orderNumber = ""
    @State private var customerNumber = ""
    @State private var customerName = ""
    @State private var equipmentNumber = ""
    @State private var functionalLocation = ""
    @State private var equipmentTypeID: UUID?
    @State private var shortText = ""
    @State private var plant = ""
    @State private var storageLocation = ""
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("Auftrag und Kunde") {
                    TextField("SAP-Auftragsnummer", text: $orderNumber)
                    TextField("Kundennummer", text: $customerNumber)
                    TextField("Kundenname", text: $customerName)
                    TextField("Kurztext", text: $shortText)
                }
                Section("Technisches Objekt") {
                    TextField("SAP-Equipmentnummer", text: $equipmentNumber)
                    TextField("Technischer Platz", text: $functionalLocation)
                    Picker("Regler / Pilot", selection: $equipmentTypeID) {
                        Text("Bitte wählen").tag(Optional<UUID>.none)
                        ForEach(equipmentTypes) { equipment in
                            Text(equipment.displayName).tag(Optional(equipment.id))
                        }
                    }
                }
                Section("Lager") {
                    TextField("Werk", text: $plant)
                    TextField("Lagerort", text: $storageLocation)
                }
            }
            .navigationTitle("Auftrag anlegen")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern", action: save)
                        .disabled(
                            orderNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                            customerName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                            equipmentTypeID == nil
                        )
                }
            }
            .onAppear {
                if plant.isEmpty { plant = defaultPlant }
                if storageLocation.isEmpty { storageLocation = defaultStorageLocation }
            }
            .alert("Speichern fehlgeschlagen", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unbekannter Fehler")
            }
        }
    }

    private func save() {
        do {
            let order = try SAPIntegrationService.addManualOrder(
                orderNumber: orderNumber,
                customerNumber: customerNumber,
                customerName: customerName,
                equipmentNumber: equipmentNumber,
                functionalLocation: functionalLocation,
                equipmentTypeID: equipmentTypeID,
                shortText: shortText,
                plant: plant,
                storageLocation: storageLocation,
                in: modelContext
            )
            onSave(order)
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

struct SAPSyncQueueView: View {
    @Query(sort: \SAPSyncQueueItem.createdAt, order: .reverse) private var items: [SAPSyncQueueItem]
    @Query private var movements: [StockMovement]

    var body: some View {
        List(items) { item in
            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Label(item.operation.rawValue, systemImage: item.status.systemImage)
                        .font(.headline)
                    Spacer()
                    Text(item.status.rawValue)
                        .font(.caption)
                        .foregroundStyle(item.status == .failed || item.status == .mappingRequired ? .red : .secondary)
                }
                if let movement = movements.first(where: { $0.id == item.movementID }) {
                    Text([movement.sapOrderNumber, movement.sapMaterialNumber].filter { !$0.isEmpty }.joined(separator: " · "))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                if !item.lastError.isEmpty {
                    Text(item.lastError)
                        .font(.caption)
                        .foregroundStyle(.red)
                }
                Text("Versuche: \(item.attempts) · \(item.createdAt.formatted(date: .abbreviated, time: .shortened))")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 3)
        }
        .navigationTitle("SAP-Synchronisation")
        .navigationBarTitleDisplayMode(.inline)
    }
}
