# Gaslager – iOS-Lagerverwaltung für RMG-/Honeywell-Ersatzteile

Gaslager ist eine native SwiftUI-App für iPhone und iPad. Sie verwaltet Original-Ersatzteile von RMG-/Honeywell-Gasdruckreglern und Piloten anhand der vorhandenen Verpackungsbarcodes, Hersteller-Artikelnummern und gerätespezifischen Ersatzteilnummern.

## Enthaltene Funktionen

- Wareneingang und Entnahme per Kamera-Barcode-Scan
- Unterstützung mehrerer Original-Barcodes pro Ersatzteil
- Eigene durchsuchbare Barcode-Stammliste mit CSV-Export
- Original-Artikelnummer und gerätespezifische Ersatzteilnummer getrennt gespeichert
- Ein Ersatzteil kann mehreren Reglern/Piloten zugeordnet werden
- Schubladen sind jeweils genau einem Regler- oder Pilottyp zugeordnet
- Integrierter, durchsuchbarer Herstellerkatalog mit 66 öffentlich belegten Typen
- 42 Gasdruckregler und 24 Piloten, getrennt nach aktuellem Programm und dokumentierter Bestands-/Altanlage
- RMG-/HON-Schreibweisen werden beim CSV- und IH2Go-/SAP-Abgleich auf denselben eindeutigen Typ normalisiert
- Lückenloser Buchungsverlauf mit Zeit, Menge, Bestand danach, Referenz und Notiz
- Schutz vor negativen Lagerbeständen
- Individueller Mindestbestand pro Ersatzteil
- Pro Ersatzteil ein-/ausschaltbare lokale Mindestbestandswarnung
- CSV-Import und -Export für den Teilekatalog
- PDF-Import für Betriebsanleitungen, Wartungsunterlagen und Ersatzteillisten
- Offline-Anzeige importierter PDFs direkt in der App
- Verknüpfung offizieller Herstellerseiten und Online-Broschüren
- Automatische Verknüpfung der passenden offiziellen Produktseite bzw. Herstellerunterlage für alle Katalogtypen
- IH2Go-/SAP-Aufträge mit Kunde, Equipment, Technischem Platz und Regler-/Pilottyp
- Aktiver Kundenauftrag direkt im Scan- und Entnahmeablauf
- Automatisch gefilterte Ersatzteilliste passend zum Auftragsgerät und aktuellen Bestand
- Sperre für Barcodes, die nicht zum hinterlegten Regler/Piloten passen
- SAP-Materialnummer, Werk, Lagerort und Basiseinheit je Originalersatzteil
- Geplante SAP-Auftragskomponenten mit Bedarf, Entnahme und Restmenge
- Offline-Warteschlange mit Retry-Schutz über eindeutige Idempotenzschlüssel
- Rückmeldung der SAP-Materialbelegnummer zur lokalen Buchung
- Optionaler SAP-Bestandsabgleich mit erneuter Mindestbestandsprüfung
- HTTPS-Bridge für Live-Synchronisierung sowie JSON-/CSV-Dateiaustausch als Fallback

Die Datenbank und importierte PDFs liegen lokal auf dem Gerät. Freigegebene Auftrags-, Komponenten-, Buchungs- und Bestandsdaten können über eine kundenspezifisch konfigurierte IH2Go-/SAP-Bridge synchronisiert werden.

## Wichtig zu Originaldaten

Das Projekt enthält bewusst keine erfundenen Barcodes oder Ersatzteilnummern. Honeywell stellt den Bereich für Original-Ersatzteile bereit, zeigt bestimmte Teilelisten jedoch erst nach Anmeldung bzw. unterstützt bei der Auswahl anhand des installierten Bestands. Die echten Datensätze können über die mitgelieferte CSV-Vorlage importiert oder beim ersten Scan erfasst werden.

Offizielle Startpunkte:

- Original-Ersatzteile: <https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories/regulators-and-safety-accessories-spare-parts/spare-parts-regulators-and-safety-accessories>
- Regler und Sicherheitseinrichtungen: <https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories>
- Piloten: <https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories/pilot-for-gas-pressure-regulators>
- Deutsches Honeywell-Gas-Technologies-Dokumentarchiv: <https://www.hongastec.de/service/download-dokumente>

Der integrierte Katalog enthält das öffentlich auffindbare aktuelle Herstellerprogramm sowie zusätzliche Typen, die in offiziellen Honeywell-/RMG-Unterlagen für Bestandsanlagen belegt sind. Er ist keine Behauptung, dass damit jede jemals gebaute Sonderausführung erfasst sei. Druckstufe, Nennweite, Baujahr, Ausführung und Fabriknummer müssen vor der Übernahme einer Ersatzteilposition mit Typenschild und freigegebener Stückliste abgeglichen werden.

## Projekt öffnen und auf einem iPhone installieren

Voraussetzungen: ein Mac mit Xcode 16 oder neuer, ein iPhone/iPad mit iOS 17 oder neuer und eine Apple-ID für die Codesignierung.

1. `Gaslager.xcodeproj` in Xcode öffnen.
2. Links das Projekt **Gaslager**, danach das Target **Gaslager** auswählen.
3. Unter **Signing & Capabilities** das eigene Team auswählen.
4. Falls Xcode einen Konflikt meldet, die Bundle-ID `de.ansgarz.Gaslager` durch eine eigene eindeutige ID ersetzen.
5. Das entsperrte iPhone per Kabel oder über Xcode-WLAN verbinden und oben als Zielgerät auswählen.
6. In den iPhone-Einstellungen den Entwicklermodus aktivieren, falls iOS dazu auffordert.
7. In Xcode auf **Run** (▶) drücken.
8. Beim ersten Scan den Kamerazugriff und bei aktivierter Mindestbestandswarnung die Benachrichtigungen erlauben.

Der Barcode-Scanner benötigt ein echtes iPhone oder iPad; im Simulator steht die Kamera nicht zur Verfügung. Eine manuelle Barcodeeingabe bleibt möglich.

## Empfohlene Ersteinrichtung

1. Im Tab **Schubladen → + → Herstellerkatalog** die vorhandenen Regler- und Pilottypen einzeln oder gesammelt übernehmen. Bestands-/Altanlagen können ein- oder ausgeblendet werden.
2. Jedem Typ seine Schublade(n) zuordnen.
3. Unter **Herstellerunterlagen** die vorgeschlagenen offiziellen Links hinzufügen und vorhandene Wartungs-/Ersatzteillisten als PDF importieren.
4. Unter **Mehr** die leere CSV-Vorlage exportieren, mit den freigegebenen Originaldaten füllen und wieder importieren.
5. Alternativ jedes Teil einmal scannen und direkt anlegen.
6. Unter **Mehr → IH2Go / SAP** Werk, Lagerort und Schnittstelle konfigurieren.
7. Jedem Ersatzteil seine SAP-Materialnummer zuordnen oder diese Zuordnung mit der erweiterten CSV-Vorlage importieren.
8. Einen IH2Go-Auftrag synchronisieren/importieren und als aktiven Auftrag wählen.

Die erzeugte **Barcode-Liste** ist im Tab **Ersatzteile** über das Barcode-Symbol erreichbar. Ihr Export enthält pro Code Hersteller, Original-Artikelnummer, Bezeichnung, Gerätetyp, gerätespezifische Ersatzteilnummer, Schublade, Bestand und Mindestbestand.

Zusätzlich liegt unter `Katalogvorlage/RMG_Honeywell_Barcode-Stammliste_SAP.xlsx` eine formatierte Excel-Arbeitsmappe mit Prüfübersicht, 200 Eingabezeilen, Auswahllisten, Pflichtfeldkontrolle, SAP-Feldern, Importhilfe und verifizierten Hersteller-Startpunkten. Sie enthält bewusst keine erfundenen Originalcodes.

Unter `Katalogvorlage/RMG_Honeywell_Geraetetypen.csv` liegt derselbe 66-Typen-Katalog zusätzlich als einfache Referenzliste vor.

## CSV-Format

Die Vorlage liegt unter `Katalogvorlage/RMG_Honeywell_Katalogvorlage.csv`. Trennzeichen ist das Semikolon; UTF-8 und Windows-1252 werden akzeptiert.

| Spalte | Pflicht | Bedeutung |
| --- | --- | --- |
| `barcode` | ja | Originalwert des aufgedruckten Barcodes |
| `barcode_typ` | nein | z. B. Code 128, Data Matrix oder EAN-13 |
| `hersteller` | ja | z. B. Honeywell / RMG |
| `original_artikelnummer` | ja | Hersteller-Artikelnummer des Ersatzteils |
| `bezeichnung` | ja | Klartextbezeichnung |
| `schublade` | ja | Eindeutige Schubladenkennung |
| `lagerort` | nein | Schrank, Raum oder Regal |
| `geraetetyp` | ja | Konkreter Regler-/Pilottyp, z. B. HON 402 |
| `kategorie` | ja | `Gasdruckregler` oder `Pilot` |
| `ersatzteilnummer_am_geraet` | ja | Nummer/Position aus der gerätespezifischen Ersatzteilliste |
| `einheit` | nein | Standard: Stück |
| `bestand` | nein | Anfangsbestand; nur bei neu angelegten Artikeln übernommen |
| `mindestbestand` | nein | Individueller Grenzwert |
| `erinnerung` | nein | `ja` aktiviert die Warnung |
| `notiz` | nein | Freitext |
| `sap_materialnummer` | nein | SAP-Materialnummer, die den Originalartikel mit Materialbelegen verbindet |
| `sap_werk` | nein | Werk für Bestands- und Buchungsbezug |
| `sap_lagerort` | nein | SAP-Lagerort; nicht mit der physischen Schublade verwechseln |
| `sap_basiseinheit` | nein | SAP-Einheit, Standard `ST` |

Für mehrere Barcodes oder mehrere Gerätezuordnungen wird der Artikel in mehreren Zeilen wiederholt. Hersteller und Original-Artikelnummer bilden dabei gemeinsam den Artikel-Schlüssel. Beim erneuten Import wird der aktuelle Lagerbestand vorhandener Artikel aus Sicherheitsgründen nicht zurückgesetzt.

## IH2Go-/SAP-Ablauf

1. Gaslager liest offene Aufträge mit Kunde und technischem Objekt aus der Bridge oder aus einer JSON-Datei ein.
2. Der Auftrag verweist auf den konkreten Regler-/Pilottyp. Die App zeigt nur Teile, deren gerätespezifische Ersatzteilzuordnung dazu passt.
3. Der Techniker scannt den Originalbarcode. Ein falsches Teil wird vor der Entnahme blockiert.
4. Die lokale Buchung reduziert den Bestand sofort und landet zusätzlich in der Offline-Warteschlange.
5. Die Bridge erzeugt die freigegebene SAP-Materialbewegung und liefert die Materialbelegnummer zurück. Bei einem Fehler bleiben Fehlermeldung und Retry-Zähler sichtbar.
6. Beim Bestandsabruf kann SAP als führendes System konfiguriert werden. Jede Abweichung wird als nachvollziehbarer Bestandsabgleich protokolliert.

Convista beschreibt IH2Go als mobiles Werkzeug für SAP-gestützte Instandhaltungs-/Serviceprozesse. Eine öffentliche, für alle Kunden identische IH2Go-API-Spezifikation ist nicht verfügbar. Deshalb enthält dieses Projekt einen neutralen, dokumentierten HTTPS-Bridge-Vertrag. Er muss von der eigenen SAP-/IH2Go-Betreuung auf die im Unternehmen freigegebenen Services abgebildet werden; Serveradressen oder Zugangsdaten werden nicht erfunden.

Im Ordner `Schnittstelle` liegen:

- `IH2Go_Gaslager_OpenAPI.yaml` – maschinenlesbarer REST-Vertrag
- `IH2Go_Auftraege_Beispiel.json` – importierbare, klar als DEMO markierte Auftragsdatei
- `README_IH2Go_SAP.md` – Feldmapping und Produktiv-Checkliste

SAP stellt für S/4HANA unter anderem APIs für Instandhaltungsobjekte und Materialdokumente bereit. Welche davon verwendet werden dürfen, hängt von der SAP-Version, dem IH2Go-Ausbau und den Firmenberechtigungen ab. Die in der App vorbelegten Bewegungsarten `261` (Ausgang) und `101` (Eingang) sind Startwerte und müssen fachlich bestätigt oder geändert werden.

Offizielle technische Startpunkte:

- Convista Enterprise Asset Management / IH2Go: <https://www.convista.com/en/industry/enterprise-asset-management/>
- SAP Business Accelerator Hub: <https://api.sap.com/>
- SAP Material Documents – Read/Create: <https://help.sap.com/docs/SAP_S4HANA_ON-PREMISE/eb2a39dd0c124fed8252f684002d55e1/d4c919581bc30a02e10000000a44147b.html>

## Technischer Aufbau

- SwiftUI und SwiftData
- VisionKit DataScanner für Barcodes
- UserNotifications für lokale Mindestbestandswarnungen
- PDFKit für Offline-Unterlagen
- iOS Deployment Target 17.0
- Keine externen Softwarepakete oder Tracking-SDKs
- Security/Keychain für das optionale Bridge-Token
- Konfigurierbarer REST-/JSON-Adapter mit dokumentiertem OpenAPI-Vertrag

## Vor produktivem Einsatz prüfen

- Mindestens je einen echten Code-128-, Data-Matrix- und EAN-Barcode aus dem eigenen Lager testen.
- Artikelnummer und gerätespezifische Ersatzteilnummer gegen die freigegebene Herstellerunterlage prüfen.
- Einen Testeingang, Testausgang und die Mindestbestandswarnung vollständig durchführen.
- Vor größeren Katalogänderungen einen CSV-Export als Sicherung erstellen.
- Mit der SAP-/IH2Go-Betreuung den Bridge-Vertrag, Mandanten, Werk, Lagerort, Bewegungsarten, Berechtigungen, Storno- und Konfliktverfahren abnehmen.
- Produktiv ausschließlich HTTPS mit gültiger Zertifikatskette verwenden und Zugangstoken nicht in CSV, Quellcode oder Chat-Nachrichten weitergeben.
