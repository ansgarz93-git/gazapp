# Barcode- und Ersatzteildaten

## Benötigte Felder

Für einen belastbaren Originaldatensatz werden mindestens benötigt:

| Feld                      | Quelle                                                     |
| ------------------------- | ---------------------------------------------------------- |
| Barcode-Rohwert           | Scan vom Originaletikett oder freigegebene Herstellerdatei |
| Barcodeart                | Scannerergebnis, z. B. Code 128 oder Data Matrix           |
| Hersteller                | Originalverpackung/Stückliste                              |
| Original-Artikelnummer    | Herstelleretikett/Stückliste                               |
| Bezeichnung               | Herstellerstückliste                                       |
| Regler-/Pilottyp          | Typenschild und freigegebene Unterlage                     |
| Ersatzteilnummer am Gerät | typ- und ausführungsspezifische Ersatzteilliste            |
| Schublade                 | eigener Lagerplan                                          |

Mindestbestand, Anfangsbestand, Einheit und Notiz sind betriebliche Felder.

## Reichen Beispiele zur Algorithmenbestimmung?

Einige saubere Fotos plus die per Scanner ausgelesenen Rohwerte helfen, Symbologie, eventuelle GS1-Applikationskennzeichen und Prüfziffern zu erkennen. Sie reichen nicht, um unbekannte Originalnummern sicher zu ermitteln. Dafür ist eine Herstellerliste oder ein vorhandenes Originaletikett erforderlich.

Für die Analyse eines Beispiels bereitstellen:

- scharfes, frontales Foto des vollständigen Etiketts,
- unveränderten Scanner-Rohwert als Text,
- vom Scanner gemeldete Barcodeart,
- sichtbare Original-Artikelnummer,
- Regler-/Pilottyp und möglichst Fabriknummer/Baujahr,
- passende Ersatzteillistenposition.

Führende Nullen und GS1-Trennzeichen dürfen nicht entfernt werden. Gaslager speichert den sichtbaren Rohwert und verwendet zusätzlich nur einen internen Vergleichsschlüssel; daraus wird keine neue Herstellerkennung erfunden.

## CSV-Format

Trennzeichen ist `;`, Zeichensatz UTF-8 mit oder ohne BOM. Pflichtfelder sind `barcode`, `hersteller`, `original_artikelnummer` und `bezeichnung`. Für Schubladen und Gerätezuordnung zusätzlich `geraetetyp`, `kategorie` und `ersatzteilnummer_am_geraet` ausfüllen.

Wird ein Artikel mit mehreren Barcodes oder mehreren Gerätezuordnungen geführt, darf er in mehreren Zeilen vorkommen. Hersteller plus Original-Artikelnummer identifizieren denselben Artikel. Beim erneuten Import wird der laufende Bestand eines vorhandenen Artikels nicht überschrieben.

## Barcode nachbilden

Nur den belegten Rohwert in derselben bestätigten Symbologie reproduzieren. Danach immer einen Drucktest durchführen und sowohl mit Gaslager als auch mit dem betrieblich verwendeten Scanner lesen. Ein optisch ähnliches Etikett ist kein Nachweis für inhaltliche Gleichheit.

In der Weboberfläche das Ersatzteil öffnen. Bei einer unterstützten und
eingetragenen Barcodeart erscheint unter dem Rohwert eine Vorschau mit
**Etikett drucken**. GS1-Gruppentrennzeichen werden aus dem gespeicherten
ASCII-29-Zeichen wieder als FNC1 codiert. Der Rohwert bleibt unverändert.
