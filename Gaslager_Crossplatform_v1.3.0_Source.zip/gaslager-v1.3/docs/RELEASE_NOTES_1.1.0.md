# Gaslager 1.1.0

## Neu in Android

- Lokaler Offline-Datenbestand nach der ersten erfolgreichen Synchronisierung
- Offline-Suche nach Originalbarcode, Artikel, Schublade und Regler-/Pilotnummer
- Offline-Vormerkung von Ein- und Ausgängen mit sofort aktualisiertem lokalem Bestand
- Sichtbarer Synchronisationsbutton, Online-/Offline-Status, letzter Datenstand und Zahl der wartenden Buchungen
- Dauerhafte lokale Ablage einer PDF-Unterlage nach dem ersten Öffnen
- Ansicht **Teile → Mehrfachverwendung** mit allen Regler-/Pilotzuordnungen und gerätespezifischen Ersatzteilnummern je Originalteil

## Serveränderung

Offline-Buchungen erhalten eine eindeutige Übertragungskennung. Der Server verarbeitet dieselbe Kennung nur einmal. Das schützt insbesondere dann vor Doppelbuchungen, wenn die Verbindung unmittelbar nach einer erfolgreichen Übertragung abbricht.

Für den vollständigen Schutz muss der Server gemeinsam mit der Android-App aktualisiert werden. Bei einer Installation aus diesem Paket genügt:

```bash
sudo bash deploy/install-ubuntu.sh
```

Die vorhandene Datenbank, hochgeladene PDFs und die `.env`-Konfiguration bleiben laut Installer erhalten. Vor einem Update sollte trotzdem ein aktuelles Backup vorliegen.

## RMG-Mehrfachverwendung

Die Ansicht verwendet ausschließlich freigegebene Kompatibilitätsdatensätze aus Gaslager. Ein Teil erscheint, sobald ihm mindestens zwei unterschiedliche Regler oder Piloten zugeordnet sind. Die App erzeugt keine Artikel-, Barcode- oder Ersatzteilnummern.

Die bisherige Stammliste enthält 66 belegte Gerätefamilien, aber noch keine freigegebenen Ersatzteilzeilen. Eine vollständige Herstellerliste kann über den bestehenden CSV-Import eingelesen werden; wiederholte Zeilen mit derselben Original-Artikelnummer und unterschiedlichen Gerätetypen bilden dabei die Mehrfachverwendung.
