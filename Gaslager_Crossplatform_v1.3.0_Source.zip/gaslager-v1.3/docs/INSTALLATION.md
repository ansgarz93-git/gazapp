# Gaslager auf einem Ubuntu-PC installieren

## Voraussetzung

- Ubuntu Server 22.04, 24.04 oder 26.04 (x86-64/ARM64), mindestens 4 GB RAM; für viele PDFs deutlich mehr freien Plattenplatz einplanen.
- Feste private IPv4-Adresse oder DHCP-Reservierung, zum Beispiel `192.168.1.50`.
- Internet für die erstmalige Installation von Docker, Python-/Node-Paketen und Container-Images. Danach funktionieren Lager, Upload und Browserzugriff im LAN ohne Internet; nur externe Herstellerlinks benötigen es.
- ZIP dieses Pakets auf den PC übertragen und vollständig entpacken.

## Installation

Im entpackten Projektordner:

```bash
sudo bash deploy/install-ubuntu.sh --plan
sudo bash deploy/install-ubuntu.sh
```

Optional vor dem ersten Start eine bestimmte lokale IP, einen anderen Port oder ein anderes Datenlaufwerk festlegen:

```bash
sudo GASLAGER_BIND_IP=192.168.1.50 GASLAGER_WEB_PORT=8088 \
  GASLAGER_DATA_DIR=/mnt/datentraeger/gaslager bash deploy/install-ubuntu.sh
```

Der Installer installiert bei Bedarf Docker Engine/Compose aus dem offiziellen Ubuntu-Repository von Docker, kopiert die Anwendung nach `/opt/gaslager`, generiert Kennwörter, startet Datenbank/API/Weboberfläche und aktiviert tägliche Sicherungen. Die Zugangsdaten liegen nur für `root` lesbar in `/root/gaslager-zugang.txt`. Das Startpasswort nach der Anmeldung unter **Einstellungen** ändern.

| Auf dem PC | Inhalt |
| --- | --- |
| `/srv/gaslager/postgres` | Bestände, Barcodes, Regler-/Pilotzuordnungen, Aufträge |
| `/srv/gaslager/documents` | Hochgeladene PDF-Dateien |
| `/srv/gaslager/backups` | Tägliche vollständige Sicherungen |
| `/srv/gaslager/exports/mehrfachverwendung-aktuell.csv` | Aktueller abgeleiteter Export |
| `/opt/gaslager/.env` | Zugangsdaten und Konfiguration, nur root |

Bei `GASLAGER_DATA_DIR` liegen die ersten vier Verzeichnisse stattdessen darunter. Bestehende ältere Installationen behalten ihre Docker-Volumes und bestehende `.env`; ein Upgrade migriert sie **nicht** ungefragt in Bind-Mounts. Für eine kontrollierte Migration von älteren Volumes zuerst sichern und gesondert planen.

## Hochladen und Arbeiten

Am Windows-PC, Android oder iPhone/iPad im Browser die gemeldete Adresse öffnen, zum Beispiel `http://192.168.1.50:8080`.

1. **Unterlagen → Unterlage hinzufügen → PDF hochladen:** Einzelnen Regler/Pilot oder **Alle Regler/Piloten** wählen, Titel, Dokumentart und PDF auswählen. Handbücher, Broschüren und auch allgemeine PDF-Mehrfachverwendungslisten werden auf dem PC gespeichert; PDF maximal 30 MB pro Datei.
2. **Einstellungen → Mehrfachverwendung hochladen:** CSV-Vorlage herunterladen oder `.xlsx` wählen. Die Liste benötigt `hersteller`, `original_artikelnummer`, `geraetetyp`, `kategorie`, `ersatzteilnummer_am_geraet`; `notiz` ist optional. CSV mit Semikolon und UTF-8; Excel-Nummern als **Text** formatieren, damit führende Nullen erhalten bleiben. Maximal 10 MB und 10.000 Zeilen.
3. Zuerst **Datei prüfen**, Fehler im Bericht korrigieren, danach **Import übernehmen**. Der Import verknüpft nur bereits vorhandene, eindeutig passende Original-Artikel und Gerätetypen. Er erzeugt keine Artikel, Barcodes oder Herstellerangaben. Sind Fehler vorhanden, wird nichts gespeichert. Vorhandene identische Zuordnungen werden übersprungen.
4. Eine reine PDF-Liste wird nur archiviert; die App liest Zuordnungen daraus nicht automatisch aus. Für durchsuchbare Mehrfachverwendung die Daten als CSV/Excel aufbereiten.

Die native Android-App kann mit der LAN-Adresse synchronisieren. Die mitgelieferte native iOS-App arbeitet weiterhin mit ihrer lokalen Offline-Datenbank; für den **zentralen** Bestand auf iOS derzeit die responsive Weboberfläche in Safari verwenden. SAP/IH2Go sind deaktiviert.

## Sicherung und Wiederherstellung

`gaslager-backup.timer` startet täglich um 02:30 Uhr (mit bis zu 10 Minuten Verzögerung). Jede Sicherung enthält `database.dump`, `documents.tar.gz`, `mehrfachverwendung.csv`, `config.env` und `SHA256SUMS` in einem eigenen Ordner. Alte Backups werden **nicht automatisch gelöscht**. Freien Speicher regelmäßig kontrollieren und Backups zusätzlich verschlüsselt auf einen anderen Datenträger übertragen.

```bash
sudo systemctl start gaslager-backup.service
sudo journalctl -u gaslager-backup.service --since today
sudo du -sh /srv/gaslager/backups
```

Bei Wiederherstellung die App anhalten, passende Sicherung und Prüfsummen verifizieren, zuerst ein Zusatzbackup des aktuellen Stands anlegen und die PDF-Dateien vollständig wiederherstellen. Der folgende Ablauf ersetzt die **aktuellen** Daten durch die ausgewählte Sicherung und gehört in ein Wartungsfenster:

```bash
sudo -i
cd /opt/gaslager
BACKUP=/srv/gaslager/backups/backup-JJJJ-MM-TT_HH-MM-SS
(cd "$BACKUP" && sha256sum -c SHA256SUMS)
docker compose stop gateway web api
source .env
docker compose exec -T database pg_restore --clean --if-exists --no-owner \
  --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" < "$BACKUP/database.dump"
docker compose start api web gateway
docker compose exec -T api tar -C /data -xzf - < "$BACKUP/documents.tar.gz"
exit
```

Danach Anmeldung, bekannte Artikel/Barcodes und mehrere PDF-Dateien prüfen. Bei anderem Datenpfad entsprechend `BACKUP=` ändern. Für kritische Betriebsdaten einen Test-Restore auf einem zweiten PC durchführen. **Achtung:** Die Wiederherstellung überschreibt Daten seit dem Sicherungszeitpunkt.

## Update und Diagnose

Ein neues vollständiges Paket entpacken und dessen Installer erneut starten. Er erzeugt **vor** dem Austausch einen Backup-Ordner. `.env`, Docker-Volumes und hochgeladene PDFs werden nicht überschrieben. Kein `rsync --delete` auf dem Datenlaufwerk. Die Versionsänderung muss bei Schemaänderungen separat geprüft werden.

```bash
cd /opt/gaslager
sudo docker compose ps
sudo docker compose logs --tail=200 gateway web api database
sudo systemctl status gaslager gaslager-backup.timer
sudo /usr/local/sbin/gaslager-export
```

Für den Health-Endpunkt die gebundene LAN-IP/Port aus `.env` benutzen: `curl http://192.168.1.50:8080/api/v1/health`.

## Netzwerk und Sicherheit

Nur der Web-Port wird an die private IPv4-Adresse gebunden; Datenbank und API haben keinen separat veröffentlichten Port. Der Installer fügt bewusst **keine** UFW-Freigabe hinzu: von Docker veröffentlichte Ports können UFW-Regeln umgehen. LAN-Zugriff an Netz/Router/Firewall gezielt prüfen, keine Router-Portweiterleitung einrichten. HTTP ist für ein vertrauenswürdiges LAN gedacht; für VPN, fremde Netze oder Fernzugriff HTTPS, Zugriffskontrollen und ein Sicherheitskonzept ergänzen. Weder `/opt/gaslager/.env` noch Backups oder `/root/gaslager-zugang.txt` per SMB/Web öffentlich freigeben.
