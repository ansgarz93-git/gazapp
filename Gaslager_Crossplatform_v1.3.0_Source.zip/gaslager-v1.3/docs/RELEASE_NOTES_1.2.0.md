# Gaslager 1.2.0

## Neu

- Android kann als eigenständiger lokaler Gaslager-Server betrieben werden.
- Vollständige Offline-Weboberfläche ist in der APK enthalten.
- Zugriff von Windows-/Android-Geräten über den Handy-Hotspot ohne Internet.
- Lokale SQLite-Serverdatenbank mit Bestand, Barcodes, Schubladen, Aufträgen und Zuordnungen.
- Zufälliger sechsstelliger Zugangscode und Möglichkeit zur Code-Erneuerung.
- Vordergrunddienst mit Serverstatus, lokaler Adresse und Stoppschaltfläche.
- JSON-Sicherung und Wiederherstellung über die Browseroberfläche.
- 66 Regler-/Pilottypen werden bei leerem Bestand lokal vorbelegt.
- Mindestbestandswarnung wird auch bei einer Buchung über die Hotspot-Weboberfläche auf dem Server-Handy ausgelöst.

## Betrieb

SAP/IH2Go, Ubuntu-Server und Internetzugang bleiben optional. Der bisherige zentrale Ubuntu-Betrieb sowie der Offline-/Synchronisationsmodus der Android-App funktionieren weiterhin.

Externe Hersteller-Webseiten benötigen Internet. Die eigentliche Lagerverwaltung und alle in der APK enthaltenen Daten arbeiten vollständig lokal.
