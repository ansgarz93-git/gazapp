# Optionale SAP-/IH2Go-Integration

Gaslager läuft zunächst vollständig standalone. Die Felder und neutralen Endpunkte sind lediglich vorbereitet, damit später kein Datenmodellwechsel nötig ist.

## Vor einer Aktivierung benötigt

- konkrete SAP-Version und Betriebsmodell
- kundenspezifische IH2Go-Schnittstellenbeschreibung
- freigegebene Systemadresse und Authentifizierung
- Mandant, Werk, Lagerort und Basiseinheiten
- Materialnummern-Mapping zu den Originalartikeln
- freigegebene Bewegungsarten und Stornoverfahren
- Definition, welches System für Bestand und Auftrag führend ist
- Konflikt-, Offline-, Wiederholungs- und Idempotenzregeln
- Testmandant und fachliche Abnahme

## Vorbereitete Bridge

| Methode | Pfad | Zweck |
| --- | --- | --- |
| `GET` | `/api/gaslager/v1/work-orders` | Standalone-Aufträge im neutralen Austauschformat |
| `GET` | `/api/gaslager/v1/stock` | gemappte Materialbestände |
| `POST` | `/api/gaslager/v1/material-movements` | idempotente Materialbewegung |

Jede schreibende Bridge-Buchung benötigt einen eindeutigen `idempotency_key`. Im ausgelieferten Modus bleiben `SAP_ENABLED=false` und `IH2GO_ENABLED=false`; normale Buchungen erhalten deshalb den Synchronstatus „Nicht erforderlich“.

Eine produktive Aktivierung darf erst nach Prüfung durch SAP-/IH2Go-Betreuung und Instandhaltung erfolgen. Zugangsdaten gehören ausschließlich in Secret-/Umgebungsvariablen, niemals in CSV-Dateien oder Quellcode.

