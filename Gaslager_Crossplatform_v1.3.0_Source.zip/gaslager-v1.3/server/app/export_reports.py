from __future__ import annotations

import csv
import sys

from sqlalchemy import select

from .database import SessionLocal
from .models import EquipmentType, PartCompatibility, SparePart


def main() -> None:
    writer = csv.writer(sys.stdout, delimiter=";", lineterminator="\n")
    sys.stdout.write("\ufeff")
    writer.writerow(["hersteller", "original_artikelnummer", "geraetetyp", "kategorie", "ersatzteilnummer_am_geraet", "notiz"])
    with SessionLocal() as db:
        rows = db.execute(
            select(PartCompatibility, SparePart, EquipmentType)
            .join(SparePart, PartCompatibility.part_id == SparePart.id)
            .join(EquipmentType, PartCompatibility.equipment_type_id == EquipmentType.id)
            .order_by(SparePart.manufacturer, SparePart.original_article_number, EquipmentType.designation)
        )
        for mapping, part, equipment in rows:
            writer.writerow([
                part.manufacturer, part.original_article_number, equipment.designation,
                equipment.kind, mapping.device_spare_part_number, mapping.notes,
            ])


if __name__ == "__main__":
    main()
