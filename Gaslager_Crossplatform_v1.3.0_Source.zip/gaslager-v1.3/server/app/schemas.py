from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator


class APIModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=200)


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(min_length=1, max_length=200)
    new_password: str = Field(min_length=10, max_length=200)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class UserOut(APIModel):
    id: str
    username: str
    display_name: str
    is_admin: bool


class EquipmentBase(BaseModel):
    manufacturer: str = Field(min_length=1, max_length=100)
    designation: str = Field(min_length=1, max_length=180)
    kind: str = Field(pattern="^(Gasdruckregler|Pilot)$")
    series: str = Field(default="", max_length=120)
    status: str = Field(default="Aktuell", max_length=40)
    notes: str = ""


class EquipmentCreate(EquipmentBase):
    pass


class EquipmentUpdate(BaseModel):
    manufacturer: str | None = Field(default=None, min_length=1, max_length=100)
    designation: str | None = Field(default=None, min_length=1, max_length=180)
    kind: str | None = Field(default=None, pattern="^(Gasdruckregler|Pilot)$")
    series: str | None = Field(default=None, max_length=120)
    status: str | None = Field(default=None, max_length=40)
    notes: str | None = None


class EquipmentOut(EquipmentBase, APIModel):
    id: str
    created_at: datetime


class DrawerBase(BaseModel):
    code: str = Field(min_length=1, max_length=80)
    location: str = Field(default="", max_length=180)
    equipment_type_id: str
    notes: str = ""


class DrawerCreate(DrawerBase):
    pass


class DrawerUpdate(BaseModel):
    code: str | None = Field(default=None, min_length=1, max_length=80)
    location: str | None = Field(default=None, max_length=180)
    equipment_type_id: str | None = None
    notes: str | None = None


class DrawerOut(DrawerBase, APIModel):
    id: str
    created_at: datetime
    equipment_type: EquipmentOut | None = None


class BarcodeCreate(BaseModel):
    value: str = Field(min_length=1)
    symbology: str = Field(default="", max_length=80)
    is_primary: bool = False


class BarcodeOut(APIModel):
    id: str
    value: str
    symbology: str
    part_id: str
    is_primary: bool
    created_at: datetime


class CompatibilityCreate(BaseModel):
    equipment_type_id: str
    device_spare_part_number: str = Field(min_length=1, max_length=180)
    notes: str = ""


class CompatibilityOut(APIModel):
    id: str
    equipment_type_id: str
    device_spare_part_number: str
    notes: str
    equipment_type: EquipmentOut | None = None


class MaterialMapping(BaseModel):
    material_number: str = Field(default="", max_length=120)
    plant: str = Field(default="", max_length=40)
    storage_location: str = Field(default="", max_length=40)
    base_unit: str = Field(default="ST", max_length=20)


class MaterialMappingOut(MaterialMapping, APIModel):
    id: str
    part_id: str


class PartCreate(BaseModel):
    manufacturer: str = Field(min_length=1, max_length=100)
    original_article_number: str = Field(min_length=1, max_length=160)
    part_name: str = Field(min_length=1, max_length=240)
    unit: str = Field(default="Stück", min_length=1, max_length=40)
    drawer_id: str | None = None
    initial_stock: int = Field(default=0, ge=0)
    minimum_stock: int = Field(default=0, ge=0)
    reminder_enabled: bool = False
    notes: str = ""
    barcodes: list[BarcodeCreate] = Field(default_factory=list)
    compatibilities: list[CompatibilityCreate] = Field(default_factory=list)
    material_mapping: MaterialMapping | None = None


class PartUpdate(BaseModel):
    manufacturer: str | None = Field(default=None, min_length=1, max_length=100)
    original_article_number: str | None = Field(default=None, min_length=1, max_length=160)
    part_name: str | None = Field(default=None, min_length=1, max_length=240)
    unit: str | None = Field(default=None, min_length=1, max_length=40)
    drawer_id: str | None = None
    minimum_stock: int | None = Field(default=None, ge=0)
    reminder_enabled: bool | None = None
    notes: str | None = None
    is_archived: bool | None = None


class PartOut(APIModel):
    id: str
    manufacturer: str
    original_article_number: str
    part_name: str
    unit: str
    drawer_id: str | None
    stock_quantity: int
    minimum_stock: int
    reminder_enabled: bool
    notes: str
    is_archived: bool
    is_low_stock: bool
    created_at: datetime
    updated_at: datetime
    drawer: DrawerOut | None = None
    barcodes: list[BarcodeOut] = Field(default_factory=list)
    compatibilities: list[CompatibilityOut] = Field(default_factory=list)
    material_mapping: MaterialMappingOut | None = None


class MovementCreate(BaseModel):
    part_id: str | None = None
    barcode: str = ""
    kind: str = Field(pattern="^(Eingang|Ausgang)$")
    quantity: int = Field(ge=1, le=99999)
    reference: str = Field(default="", max_length=240)
    notes: str = ""
    work_order_id: str | None = None
    idempotency_key: str | None = Field(default=None, max_length=100)

    @field_validator("barcode")
    @classmethod
    def barcode_or_part_is_checked_in_route(cls, value: str) -> str:
        return value


class MovementOut(APIModel):
    id: str
    part_id: str
    kind: str
    quantity: int
    timestamp: datetime
    reference: str
    notes: str
    stock_after: int
    barcode_used: str
    work_order_id: str | None
    created_by_id: str
    sync_status: str
    part_name: str = ""
    article_number: str = ""
    created_by_name: str = ""


class ComponentCreate(BaseModel):
    item_number: str = Field(min_length=1, max_length=40)
    part_id: str | None = None
    material_number: str = Field(default="", max_length=120)
    description: str = Field(default="", max_length=300)
    required_quantity: int = Field(default=0, ge=0)
    withdrawn_quantity: int = Field(default=0, ge=0)


class ComponentOut(ComponentCreate, APIModel):
    id: str
    work_order_id: str


class WorkOrderCreate(BaseModel):
    order_number: str = Field(min_length=1, max_length=100)
    customer_number: str = Field(default="", max_length=100)
    customer_name: str = Field(min_length=1, max_length=240)
    equipment_number: str = Field(default="", max_length=120)
    functional_location: str = Field(default="", max_length=180)
    equipment_type_id: str | None = None
    short_text: str = Field(default="", max_length=300)
    status: str = Field(default="Offen", max_length=60)
    planned_start: datetime | None = None
    components: list[ComponentCreate] = Field(default_factory=list)


class WorkOrderUpdate(BaseModel):
    customer_number: str | None = Field(default=None, max_length=100)
    customer_name: str | None = Field(default=None, min_length=1, max_length=240)
    equipment_number: str | None = Field(default=None, max_length=120)
    functional_location: str | None = Field(default=None, max_length=180)
    equipment_type_id: str | None = None
    short_text: str | None = Field(default=None, max_length=300)
    status: str | None = Field(default=None, max_length=60)
    planned_start: datetime | None = None


class WorkOrderOut(APIModel):
    id: str
    order_number: str
    customer_number: str
    customer_name: str
    equipment_number: str
    functional_location: str
    equipment_type_id: str | None
    short_text: str
    status: str
    planned_start: datetime | None
    source_system: str
    created_at: datetime
    updated_at: datetime
    equipment_type: EquipmentOut | None = None
    components: list[ComponentOut] = Field(default_factory=list)


class DocumentLinkCreate(BaseModel):
    equipment_type_id: str | None = None
    title: str = Field(min_length=1, max_length=300)
    kind: str = Field(default="Sonstiges", max_length=80)
    source_url: HttpUrl
    is_official_manufacturer_source: bool = False


class DocumentOut(APIModel):
    id: str
    equipment_type_id: str | None
    title: str
    kind: str
    source_url: str
    original_filename: str
    is_official_manufacturer_source: bool
    added_at: datetime
    equipment_type: EquipmentOut | None = None
    download_url: str = ""


class DashboardOut(BaseModel):
    part_count: int
    stock_total: int
    low_stock_count: int
    open_order_count: int
    movement_count_today: int
    recent_movements: list[MovementOut]
    low_stock_parts: list[PartOut]


class SystemSettingsOut(BaseModel):
    standalone_mode: bool
    sap_enabled: bool
    ih2go_enabled: bool
    api_version: str


class ImportReport(BaseModel):
    created_parts: int = 0
    updated_parts: int = 0
    created_barcodes: int = 0
    created_equipment_types: int = 0
    created_drawers: int = 0
    errors: list[str] = Field(default_factory=list)
