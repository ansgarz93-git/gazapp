from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def new_id() -> str:
    return str(uuid.uuid4())


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    username: Mapped[str] = mapped_column(String(80), unique=True, nullable=False, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[str] = mapped_column(String(160), default="Administrator", nullable=False)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class EquipmentType(Base):
    __tablename__ = "equipment_types"
    __table_args__ = (
        UniqueConstraint("manufacturer", "designation", "kind", name="uq_equipment_identity"),
        Index("idx_equipment_kind_designation", "kind", "designation"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    manufacturer: Mapped[str] = mapped_column(String(100), nullable=False)
    designation: Mapped[str] = mapped_column(String(180), nullable=False)
    kind: Mapped[str] = mapped_column(String(40), nullable=False)
    series: Mapped[str] = mapped_column(String(120), default="", nullable=False)
    status: Mapped[str] = mapped_column(String(40), default="Aktuell", nullable=False)
    notes: Mapped[str] = mapped_column(Text, default="", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    drawers: Mapped[list[Drawer]] = relationship(back_populates="equipment_type")
    compatibilities: Mapped[list[PartCompatibility]] = relationship(
        back_populates="equipment_type", cascade="all, delete-orphan"
    )
    documents: Mapped[list[TechnicalDocument]] = relationship(
        back_populates="equipment_type", cascade="all, delete-orphan"
    )


class Drawer(Base):
    __tablename__ = "drawers"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    code: Mapped[str] = mapped_column(String(80), unique=True, nullable=False, index=True)
    location: Mapped[str] = mapped_column(String(180), default="", nullable=False)
    equipment_type_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("equipment_types.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    notes: Mapped[str] = mapped_column(Text, default="", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    equipment_type: Mapped[EquipmentType] = relationship(back_populates="drawers")
    parts: Mapped[list[SparePart]] = relationship(back_populates="drawer")


class SparePart(Base):
    __tablename__ = "spare_parts"
    __table_args__ = (
        UniqueConstraint("manufacturer", "original_article_number", name="uq_part_original_article"),
        CheckConstraint("stock_quantity >= 0", name="ck_part_stock_nonnegative"),
        CheckConstraint("minimum_stock >= 0", name="ck_part_minimum_nonnegative"),
        Index("idx_part_name", "part_name"),
        Index("idx_part_low_stock", "reminder_enabled", "stock_quantity", "minimum_stock"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    manufacturer: Mapped[str] = mapped_column(String(100), nullable=False)
    original_article_number: Mapped[str] = mapped_column(String(160), nullable=False)
    part_name: Mapped[str] = mapped_column(String(240), nullable=False)
    unit: Mapped[str] = mapped_column(String(40), default="Stück", nullable=False)
    drawer_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("drawers.id", ondelete="SET NULL"), nullable=True, index=True
    )
    stock_quantity: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    minimum_stock: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    reminder_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    notes: Mapped[str] = mapped_column(Text, default="", nullable=False)
    is_archived: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)

    drawer: Mapped[Drawer | None] = relationship(back_populates="parts")
    barcodes: Mapped[list[PartBarcode]] = relationship(
        back_populates="part", cascade="all, delete-orphan", order_by="PartBarcode.is_primary.desc()"
    )
    compatibilities: Mapped[list[PartCompatibility]] = relationship(
        back_populates="part", cascade="all, delete-orphan"
    )
    movements: Mapped[list[StockMovement]] = relationship(back_populates="part")
    material_mapping: Mapped[SAPMaterialMapping | None] = relationship(
        back_populates="part", cascade="all, delete-orphan", uselist=False
    )

    @property
    def is_low_stock(self) -> bool:
        return self.stock_quantity <= self.minimum_stock


class PartBarcode(Base):
    __tablename__ = "part_barcodes"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    match_key: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    symbology: Mapped[str] = mapped_column(String(80), default="", nullable=False)
    part_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("spare_parts.id", ondelete="CASCADE"), nullable=False, index=True
    )
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    part: Mapped[SparePart] = relationship(back_populates="barcodes")


class PartCompatibility(Base):
    __tablename__ = "part_compatibilities"
    __table_args__ = (
        UniqueConstraint(
            "part_id", "equipment_type_id", "device_spare_part_number", name="uq_part_compatibility"
        ),
        Index("idx_compatibility_equipment_part", "equipment_type_id", "part_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    part_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("spare_parts.id", ondelete="CASCADE"), nullable=False
    )
    equipment_type_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("equipment_types.id", ondelete="CASCADE"), nullable=False
    )
    device_spare_part_number: Mapped[str] = mapped_column(String(180), nullable=False)
    notes: Mapped[str] = mapped_column(Text, default="", nullable=False)

    part: Mapped[SparePart] = relationship(back_populates="compatibilities")
    equipment_type: Mapped[EquipmentType] = relationship(back_populates="compatibilities")


class WorkOrder(Base):
    __tablename__ = "work_orders"
    __table_args__ = (Index("idx_work_order_status_start", "status", "planned_start"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    order_number: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    customer_number: Mapped[str] = mapped_column(String(100), default="", nullable=False)
    customer_name: Mapped[str] = mapped_column(String(240), nullable=False)
    equipment_number: Mapped[str] = mapped_column(String(120), default="", nullable=False)
    functional_location: Mapped[str] = mapped_column(String(180), default="", nullable=False)
    equipment_type_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("equipment_types.id", ondelete="SET NULL"), nullable=True, index=True
    )
    short_text: Mapped[str] = mapped_column(String(300), default="", nullable=False)
    status: Mapped[str] = mapped_column(String(60), default="Offen", nullable=False)
    planned_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    source_system: Mapped[str] = mapped_column(String(80), default="Gaslager", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)

    equipment_type: Mapped[EquipmentType | None] = relationship()
    components: Mapped[list[OrderComponent]] = relationship(
        back_populates="work_order", cascade="all, delete-orphan"
    )
    movements: Mapped[list[StockMovement]] = relationship(back_populates="work_order")


class OrderComponent(Base):
    __tablename__ = "order_components"
    __table_args__ = (
        UniqueConstraint("work_order_id", "item_number", name="uq_order_component_item"),
        CheckConstraint("required_quantity >= 0", name="ck_component_required_nonnegative"),
        CheckConstraint("withdrawn_quantity >= 0", name="ck_component_withdrawn_nonnegative"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    work_order_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("work_orders.id", ondelete="CASCADE"), nullable=False, index=True
    )
    item_number: Mapped[str] = mapped_column(String(40), nullable=False)
    part_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("spare_parts.id", ondelete="SET NULL"), nullable=True
    )
    material_number: Mapped[str] = mapped_column(String(120), default="", nullable=False)
    description: Mapped[str] = mapped_column(String(300), default="", nullable=False)
    required_quantity: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    withdrawn_quantity: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    work_order: Mapped[WorkOrder] = relationship(back_populates="components")
    part: Mapped[SparePart | None] = relationship()


class StockMovement(Base):
    __tablename__ = "stock_movements"
    __table_args__ = (
        CheckConstraint("quantity > 0", name="ck_movement_quantity_positive"),
        CheckConstraint("stock_after >= 0", name="ck_movement_stock_nonnegative"),
        Index("idx_movement_part_timestamp", "part_id", "timestamp"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    part_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("spare_parts.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    kind: Mapped[str] = mapped_column(String(40), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False, index=True)
    reference: Mapped[str] = mapped_column(String(240), default="", nullable=False)
    notes: Mapped[str] = mapped_column(Text, default="", nullable=False)
    stock_after: Mapped[int] = mapped_column(Integer, nullable=False)
    barcode_used: Mapped[str] = mapped_column(Text, default="", nullable=False)
    work_order_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("work_orders.id", ondelete="SET NULL"), nullable=True, index=True
    )
    created_by_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    sync_status: Mapped[str] = mapped_column(String(60), default="Nicht erforderlich", nullable=False)
    external_idempotency_key: Mapped[str | None] = mapped_column(String(100), unique=True, nullable=True)

    part: Mapped[SparePart] = relationship(back_populates="movements")
    work_order: Mapped[WorkOrder | None] = relationship(back_populates="movements")
    created_by: Mapped[User] = relationship()


class TechnicalDocument(Base):
    __tablename__ = "technical_documents"
    __table_args__ = (Index("idx_document_equipment_title", "equipment_type_id", "title"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    equipment_type_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("equipment_types.id", ondelete="CASCADE"), nullable=True
    )
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    kind: Mapped[str] = mapped_column(String(80), default="Sonstiges", nullable=False)
    source_url: Mapped[str] = mapped_column(Text, default="", nullable=False)
    stored_filename: Mapped[str] = mapped_column(String(300), default="", nullable=False)
    original_filename: Mapped[str] = mapped_column(String(300), default="", nullable=False)
    is_official_manufacturer_source: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    added_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    equipment_type: Mapped[EquipmentType | None] = relationship(back_populates="documents")


class SAPMaterialMapping(Base):
    __tablename__ = "sap_material_mappings"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    part_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("spare_parts.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    material_number: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    plant: Mapped[str] = mapped_column(String(40), default="", nullable=False)
    storage_location: Mapped[str] = mapped_column(String(40), default="", nullable=False)
    base_unit: Mapped[str] = mapped_column(String(20), default="ST", nullable=False)

    part: Mapped[SparePart] = relationship(back_populates="material_mapping")
