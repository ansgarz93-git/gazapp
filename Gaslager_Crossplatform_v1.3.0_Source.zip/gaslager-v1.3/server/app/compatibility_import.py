from __future__ import annotations

import csv
import io
from zipfile import BadZipFile
from typing import Any

from openpyxl import load_workbook
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import EquipmentType, PartCompatibility, SparePart

HEADERS = (
    "hersteller", "original_artikelnummer", "geraetetyp", "kategorie",
    "ersatzteilnummer_am_geraet", "notiz",
)
REQUIRED = HEADERS[:-1]
MAX_ROWS = 10_000


def _as_rows(filename: str, raw: bytes) -> list[tuple[int, dict[str, str]]]:
    suffix = filename.lower().rsplit(".", 1)[-1]
    if suffix == "csv":
        try:
            content = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            content = raw.decode("cp1252")
        reader = csv.DictReader(io.StringIO(content), delimiter=";")
        if not reader.fieldnames:
            raise ValueError("Die CSV-Datei enthält keine Kopfzeile.")
        keys = [(key or "").strip().lower() for key in reader.fieldnames]
        _check_headers(keys)
        rows = []
        for number, original in enumerate(reader, start=2):
            if number > MAX_ROWS + 1:
                raise ValueError(f"Maximal {MAX_ROWS} Datenzeilen sind erlaubt.")
            if None in original:
                raise ValueError(f"Zeile {number}: Zu viele Spalten oder falsches Trennzeichen.")
            values = {key: (value or "").strip() for key, value in zip(keys, original.values())}
            if any(values.values()):
                rows.append((number, values))
        return rows
    if suffix == "xlsx":
        try:
            book = load_workbook(io.BytesIO(raw), read_only=True, data_only=False)
            sheet = book.active
            if sheet is None:
                raise ValueError("Die Excel-Datei enthält kein Tabellenblatt.")
            iterator = sheet.iter_rows()
            first = next(iterator, None)
            if first is None:
                raise ValueError("Die Excel-Datei enthält keine Kopfzeile.")
            keys = [str(cell.value or "").strip().lower() for cell in first]
            _check_headers(keys)
            rows = []
            for number, cells in enumerate(iterator, start=2):
                if number > MAX_ROWS + 1:
                    raise ValueError(f"Maximal {MAX_ROWS} Datenzeilen sind erlaubt.")
                values: dict[str, str] = {}
                for key, cell in zip(keys, cells):
                    if key in REQUIRED and cell.data_type in {"n", "f"} and cell.value is not None:
                        raise ValueError(
                            f"Zeile {number}, {key}: Nummern müssen als Text gespeichert sein "
                            "(sonst gehen führende Nullen verloren); Formeln sind nicht erlaubt."
                        )
                    values[key] = str(cell.value).strip() if cell.value is not None else ""
                if any(values.values()):
                    rows.append((number, values))
            return rows
        except (OSError, KeyError, BadZipFile) as exc:
            raise ValueError("Die Excel-Datei ist beschädigt oder nicht lesbar.") from exc
    raise ValueError("Erlaubt sind ausschließlich .csv (Semikolon) oder .xlsx.")


def _check_headers(keys: list[str]) -> None:
    missing = [name for name in REQUIRED if name not in keys]
    if missing:
        raise ValueError("Pflichtspalten fehlen: " + ", ".join(missing))
    if len(keys) != len(set(keys)):
        raise ValueError("Doppelte Spaltennamen sind nicht erlaubt.")


def preview_import(db: Session, filename: str, raw: bytes) -> tuple[dict[str, Any], list[tuple[str, str, str, str]]]:
    rows = _as_rows(filename, raw)
    parts: dict[tuple[str, str], list[SparePart]] = {}
    for part in db.scalars(select(SparePart)).all():
        parts.setdefault((part.manufacturer.casefold(), part.original_article_number.casefold()), []).append(part)
    equipment: dict[tuple[str, str, str], list[EquipmentType]] = {}
    for item in db.scalars(select(EquipmentType)).all():
        equipment.setdefault((item.manufacturer.casefold(), item.designation.casefold(), item.kind.casefold()), []).append(item)
    existing = {
        (item.part_id, item.equipment_type_id, item.device_spare_part_number.casefold())
        for item in db.scalars(select(PartCompatibility)).all()
    }
    proposed: list[tuple[str, str, str, str]] = []
    errors: list[str] = []
    already_present = 0
    seen = set(existing)
    for number, row in rows:
        missing = [name for name in REQUIRED if not row.get(name)]
        if missing:
            errors.append(f"Zeile {number}: Leere Pflichtfelder: {', '.join(missing)}")
            continue
        limits = {"hersteller": 100, "original_artikelnummer": 160, "geraetetyp": 180,
                  "kategorie": 40, "ersatzteilnummer_am_geraet": 180, "notiz": 5000}
        invalid = [name for name, limit in limits.items() if len(row.get(name, "")) > limit or "\x00" in row.get(name, "")]
        if invalid:
            errors.append(f"Zeile {number}: Zu lange oder ungültige Werte: {', '.join(invalid)}")
            continue
        part_candidates = parts.get((row["hersteller"].casefold(), row["original_artikelnummer"].casefold()), [])
        device_candidates = equipment.get((row["hersteller"].casefold(), row["geraetetyp"].casefold(), row["kategorie"].casefold()), [])
        if len(part_candidates) != 1 or len(device_candidates) != 1:
            errors.append(
                f"Zeile {number}: Teil oder Regler/Pilot nicht eindeutig vorhanden: "
                f"{row['hersteller']} / {row['original_artikelnummer']} / {row['geraetetyp']} / {row['kategorie']}."
            )
            continue
        part, device = part_candidates[0], device_candidates[0]
        key = (part.id, device.id, row["ersatzteilnummer_am_geraet"].casefold())
        if key in seen:
            already_present += 1
            continue
        seen.add(key)
        proposed.append((part.id, device.id, row["ersatzteilnummer_am_geraet"], row.get("notiz", "")))
    return {
        "rows_total": len(rows), "to_create": len(proposed), "already_present": already_present,
        "errors": errors, "committed": False,
    }, proposed
