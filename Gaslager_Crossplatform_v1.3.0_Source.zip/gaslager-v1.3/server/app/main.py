from __future__ import annotations

import csv
import io
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, time
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, Response, UploadFile, status
from fastapi.responses import FileResponse, StreamingResponse
from sqlalchemy import and_, func, or_, select, text as sql_text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from .barcodes import normalize_barcode
from .compatibility_import import HEADERS as COMPATIBILITY_HEADERS, preview_import
from .config import settings
from .database import Base, SessionLocal, engine
from .models import (
    Drawer,
    EquipmentType,
    OrderComponent,
    PartBarcode,
    PartCompatibility,
    SAPMaterialMapping,
    SparePart,
    StockMovement,
    TechnicalDocument,
    User,
    WorkOrder,
    utcnow,
)
from .schemas import (
    BarcodeCreate,
    BarcodeOut,
    ChangePasswordRequest,
    CompatibilityCreate,
    CompatibilityOut,
    ComponentOut,
    DashboardOut,
    DocumentLinkCreate,
    DocumentOut,
    DrawerCreate,
    DrawerOut,
    DrawerUpdate,
    EquipmentCreate,
    EquipmentOut,
    EquipmentUpdate,
    ImportReport,
    LoginRequest,
    MaterialMappingOut,
    MovementCreate,
    MovementOut,
    PartCreate,
    PartOut,
    PartUpdate,
    SystemSettingsOut,
    TokenResponse,
    UserOut,
    WorkOrderCreate,
    WorkOrderOut,
    WorkOrderUpdate,
)
from .security import COOKIE_NAME, create_access_token, current_user, get_db, hash_password, verify_password
from .seed import ensure_initial_data


API_VERSION = "1.3.0"


@asynccontextmanager
async def lifespan(_app: FastAPI):
    settings.documents_dir.mkdir(parents=True, exist_ok=True)
    Base.metadata.create_all(bind=engine)
    # One small, repeatable migration for older PostgreSQL installations.
    if engine.dialect.name == "postgresql":
        with engine.begin() as connection:
            connection.execute(sql_text("ALTER TABLE technical_documents ALTER COLUMN equipment_type_id DROP NOT NULL"))
    with SessionLocal() as db:
        ensure_initial_data(db)
    yield


app = FastAPI(
    title="Gaslager Server",
    version=API_VERSION,
    description="Zentrale Lager- und Barcodeverwaltung für RMG-/Honeywell-Ersatzteile",
    lifespan=lifespan,
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
)


def _conflict(db: Session, message: str, exc: Exception | None = None):
    db.rollback()
    raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=message) from exc


def _not_found(name: str = "Datensatz"):
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"{name} wurde nicht gefunden.")


def _part_statement():
    return select(SparePart).options(
        selectinload(SparePart.drawer).selectinload(Drawer.equipment_type),
        selectinload(SparePart.barcodes),
        selectinload(SparePart.compatibilities).selectinload(PartCompatibility.equipment_type),
        selectinload(SparePart.material_mapping),
    )


def _equipment_statement():
    return select(EquipmentType)


def _drawer_statement():
    return select(Drawer).options(selectinload(Drawer.equipment_type))


def _work_order_statement():
    return select(WorkOrder).options(
        selectinload(WorkOrder.equipment_type),
        selectinload(WorkOrder.components),
    )


def _document_statement():
    return select(TechnicalDocument).options(selectinload(TechnicalDocument.equipment_type))


def _movement_out(movement: StockMovement) -> MovementOut:
    return MovementOut(
        id=movement.id,
        part_id=movement.part_id,
        kind=movement.kind,
        quantity=movement.quantity,
        timestamp=movement.timestamp,
        reference=movement.reference,
        notes=movement.notes,
        stock_after=movement.stock_after,
        barcode_used=movement.barcode_used,
        work_order_id=movement.work_order_id,
        created_by_id=movement.created_by_id,
        sync_status=movement.sync_status,
        part_name=movement.part.part_name if movement.part else "",
        article_number=movement.part.original_article_number if movement.part else "",
        created_by_name=movement.created_by.display_name if movement.created_by else "",
    )


def _document_out(document: TechnicalDocument) -> DocumentOut:
    return DocumentOut(
        id=document.id,
        equipment_type_id=document.equipment_type_id,
        title=document.title,
        kind=document.kind,
        source_url=document.source_url,
        original_filename=document.original_filename,
        is_official_manufacturer_source=document.is_official_manufacturer_source,
        added_at=document.added_at,
        equipment_type=document.equipment_type,
        download_url=f"/api/v1/documents/{document.id}/file" if document.stored_filename else "",
    )


@app.get("/api/v1/health")
def health() -> dict[str, str | bool]:
    return {"status": "ok", "version": API_VERSION, "standalone": settings.standalone_mode}


@app.post("/api/v1/auth/login", response_model=TokenResponse)
def login(payload: LoginRequest, response: Response, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.username == payload.username, User.is_active.is_(True)))
    if user is None or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Benutzername oder Passwort ist falsch.")
    token, seconds = create_access_token(user)
    response.set_cookie(
        COOKIE_NAME,
        token,
        max_age=seconds,
        httponly=True,
        secure=False,
        samesite="lax",
        path="/",
    )
    return TokenResponse(access_token=token, expires_in=seconds)


@app.post("/api/v1/auth/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(response: Response):
    response.delete_cookie(COOKIE_NAME, path="/")


@app.get("/api/v1/auth/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user


@app.post("/api/v1/auth/change-password", status_code=status.HTTP_204_NO_CONTENT)
def change_password(
    payload: ChangePasswordRequest,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if not verify_password(payload.current_password, user.password_hash):
        raise HTTPException(status_code=400, detail="Das aktuelle Passwort ist nicht korrekt.")
    try:
        user.password_hash = hash_password(payload.new_password)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    db.commit()


@app.get("/api/v1/settings", response_model=SystemSettingsOut)
def system_settings(_user: User = Depends(current_user)):
    return SystemSettingsOut(
        standalone_mode=settings.standalone_mode,
        sap_enabled=settings.sap_enabled,
        ih2go_enabled=settings.ih2go_enabled,
        api_version=API_VERSION,
    )


@app.get("/api/v1/equipment", response_model=list[EquipmentOut])
def list_equipment(
    q: str = "",
    kind: str | None = None,
    include_legacy: bool = True,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    statement = _equipment_statement()
    if q.strip():
        pattern = f"%{q.strip()}%"
        statement = statement.where(
            or_(
                EquipmentType.designation.ilike(pattern),
                EquipmentType.manufacturer.ilike(pattern),
                EquipmentType.series.ilike(pattern),
            )
        )
    if kind:
        statement = statement.where(EquipmentType.kind == kind)
    if not include_legacy:
        statement = statement.where(EquipmentType.status != "Bestands-/Altanlage")
    return db.scalars(statement.order_by(EquipmentType.kind, EquipmentType.designation)).all()


@app.post("/api/v1/equipment", response_model=EquipmentOut, status_code=status.HTTP_201_CREATED)
def create_equipment(
    payload: EquipmentCreate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    equipment = EquipmentType(**payload.model_dump())
    db.add(equipment)
    try:
        db.commit()
    except IntegrityError as exc:
        _conflict(db, "Dieser Regler- oder Pilottyp ist bereits vorhanden.", exc)
    db.refresh(equipment)
    return equipment


@app.patch("/api/v1/equipment/{equipment_id}", response_model=EquipmentOut)
def update_equipment(
    equipment_id: str,
    payload: EquipmentUpdate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    equipment = db.get(EquipmentType, equipment_id)
    if equipment is None:
        _not_found("Gerätetyp")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(equipment, key, value)
    try:
        db.commit()
    except IntegrityError as exc:
        _conflict(db, "Die Gerätebezeichnung ist bereits vergeben.", exc)
    db.refresh(equipment)
    return equipment


@app.get("/api/v1/drawers", response_model=list[DrawerOut])
def list_drawers(
    q: str = "",
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    statement = _drawer_statement()
    if q.strip():
        pattern = f"%{q.strip()}%"
        statement = statement.where(or_(Drawer.code.ilike(pattern), Drawer.location.ilike(pattern)))
    return db.scalars(statement.order_by(Drawer.code)).all()


@app.post("/api/v1/drawers", response_model=DrawerOut, status_code=status.HTTP_201_CREATED)
def create_drawer(
    payload: DrawerCreate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if db.get(EquipmentType, payload.equipment_type_id) is None:
        _not_found("Gerätetyp")
    drawer = Drawer(**payload.model_dump())
    db.add(drawer)
    try:
        db.commit()
    except IntegrityError as exc:
        _conflict(db, "Diese Schubladenkennung ist bereits vorhanden.", exc)
    return db.scalar(_drawer_statement().where(Drawer.id == drawer.id))


@app.patch("/api/v1/drawers/{drawer_id}", response_model=DrawerOut)
def update_drawer(
    drawer_id: str,
    payload: DrawerUpdate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    drawer = db.get(Drawer, drawer_id)
    if drawer is None:
        _not_found("Schublade")
    values = payload.model_dump(exclude_unset=True)
    if "equipment_type_id" in values and db.get(EquipmentType, values["equipment_type_id"]) is None:
        _not_found("Gerätetyp")
    for key, value in values.items():
        setattr(drawer, key, value)
    try:
        db.commit()
    except IntegrityError as exc:
        _conflict(db, "Diese Schubladenkennung ist bereits vorhanden.", exc)
    return db.scalar(_drawer_statement().where(Drawer.id == drawer.id))


@app.get("/api/v1/parts", response_model=list[PartOut])
def list_parts(
    q: str = "",
    low_stock: bool | None = None,
    equipment_type_id: str | None = None,
    include_archived: bool = False,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    statement = _part_statement()
    if not include_archived:
        statement = statement.where(SparePart.is_archived.is_(False))
    if q.strip():
        pattern = f"%{q.strip()}%"
        barcode_part_ids = select(PartBarcode.part_id).where(PartBarcode.value.ilike(pattern))
        statement = statement.where(
            or_(
                SparePart.part_name.ilike(pattern),
                SparePart.manufacturer.ilike(pattern),
                SparePart.original_article_number.ilike(pattern),
                SparePart.id.in_(barcode_part_ids),
            )
        )
    if low_stock is True:
        statement = statement.where(SparePart.stock_quantity <= SparePart.minimum_stock)
    elif low_stock is False:
        statement = statement.where(SparePart.stock_quantity > SparePart.minimum_stock)
    if equipment_type_id:
        compatible_part_ids = select(PartCompatibility.part_id).where(
            PartCompatibility.equipment_type_id == equipment_type_id
        )
        statement = statement.where(SparePart.id.in_(compatible_part_ids))
    return db.scalars(statement.order_by(SparePart.part_name)).unique().all()


@app.get("/api/v1/parts/{part_id}", response_model=PartOut)
def get_part(
    part_id: str,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    part = db.scalar(_part_statement().where(SparePart.id == part_id))
    if part is None:
        _not_found("Ersatzteil")
    return part


@app.post("/api/v1/parts", response_model=PartOut, status_code=status.HTTP_201_CREATED)
def create_part(
    payload: PartCreate,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if payload.drawer_id and db.get(Drawer, payload.drawer_id) is None:
        _not_found("Schublade")
    duplicate = db.scalar(
        select(SparePart.id).where(
            func.lower(SparePart.manufacturer) == payload.manufacturer.strip().lower(),
            func.lower(SparePart.original_article_number) == payload.original_article_number.strip().lower(),
        )
    )
    if duplicate:
        raise HTTPException(status_code=409, detail="Hersteller und Original-Artikelnummer sind bereits vorhanden.")
    part = SparePart(
        manufacturer=payload.manufacturer.strip(),
        original_article_number=payload.original_article_number.strip(),
        part_name=payload.part_name.strip(),
        unit=payload.unit.strip(),
        drawer_id=payload.drawer_id,
        stock_quantity=payload.initial_stock,
        minimum_stock=payload.minimum_stock,
        reminder_enabled=payload.reminder_enabled,
        notes=payload.notes.strip(),
    )
    db.add(part)
    db.flush()

    seen_keys: set[str] = set()
    for index, barcode in enumerate(payload.barcodes):
        key = normalize_barcode(barcode.value)
        if not key:
            raise HTTPException(status_code=422, detail="Ein Barcode darf nicht leer sein.")
        if key in seen_keys or db.scalar(select(PartBarcode.id).where(PartBarcode.match_key == key)):
            raise HTTPException(status_code=409, detail=f"Barcode {barcode.value} ist bereits zugeordnet.")
        seen_keys.add(key)
        db.add(
            PartBarcode(
                value=barcode.value.strip(),
                match_key=key,
                symbology=barcode.symbology.strip(),
                part_id=part.id,
                is_primary=barcode.is_primary or (index == 0 and not any(item.is_primary for item in payload.barcodes)),
            )
        )

    for compatibility in payload.compatibilities:
        if db.get(EquipmentType, compatibility.equipment_type_id) is None:
            _not_found("Gerätetyp")
        db.add(PartCompatibility(part_id=part.id, **compatibility.model_dump()))

    if payload.material_mapping and payload.material_mapping.material_number.strip():
        db.add(SAPMaterialMapping(part_id=part.id, **payload.material_mapping.model_dump()))

    if payload.initial_stock > 0:
        db.add(
            StockMovement(
                part_id=part.id,
                kind="Bestandsübernahme",
                quantity=payload.initial_stock,
                reference="Erstanlage",
                stock_after=payload.initial_stock,
                created_by_id=user.id,
            )
        )
    try:
        db.commit()
    except IntegrityError as exc:
        _conflict(db, "Artikelnummer, Barcode oder SAP-Materialnummer ist bereits vergeben.", exc)
    return db.scalar(_part_statement().where(SparePart.id == part.id))


@app.patch("/api/v1/parts/{part_id}", response_model=PartOut)
def update_part(
    part_id: str,
    payload: PartUpdate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    part = db.get(SparePart, part_id)
    if part is None:
        _not_found("Ersatzteil")
    values = payload.model_dump(exclude_unset=True)
    if "drawer_id" in values and values["drawer_id"] and db.get(Drawer, values["drawer_id"]) is None:
        _not_found("Schublade")
    for key, value in values.items():
        if isinstance(value, str):
            value = value.strip()
        setattr(part, key, value)
    part.updated_at = utcnow()
    try:
        db.commit()
    except IntegrityError as exc:
        _conflict(db, "Hersteller und Original-Artikelnummer sind bereits vorhanden.", exc)
    return db.scalar(_part_statement().where(SparePart.id == part.id))


@app.post("/api/v1/parts/{part_id}/barcodes", response_model=BarcodeOut, status_code=status.HTTP_201_CREATED)
def add_barcode(
    part_id: str,
    payload: BarcodeCreate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    part = db.scalar(select(SparePart).options(selectinload(SparePart.barcodes)).where(SparePart.id == part_id))
    if part is None:
        _not_found("Ersatzteil")
    key = normalize_barcode(payload.value)
    if not key:
        raise HTTPException(status_code=422, detail="Barcode darf nicht leer sein.")
    if db.scalar(select(PartBarcode.id).where(PartBarcode.match_key == key)):
        raise HTTPException(status_code=409, detail="Dieser Barcode ist bereits einem Ersatzteil zugeordnet.")
    is_primary = payload.is_primary or not part.barcodes
    if is_primary:
        for existing in part.barcodes:
            existing.is_primary = False
    barcode = PartBarcode(
        value=payload.value.strip(),
        match_key=key,
        symbology=payload.symbology.strip(),
        part_id=part.id,
        is_primary=is_primary,
    )
    db.add(barcode)
    db.commit()
    db.refresh(barcode)
    return barcode


@app.delete("/api/v1/parts/{part_id}/barcodes/{barcode_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_barcode(
    part_id: str,
    barcode_id: str,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    barcode = db.scalar(
        select(PartBarcode).where(PartBarcode.id == barcode_id, PartBarcode.part_id == part_id)
    )
    if barcode is None:
        _not_found("Barcode")
    was_primary = barcode.is_primary
    db.delete(barcode)
    db.flush()
    if was_primary:
        replacement = db.scalar(
            select(PartBarcode).where(PartBarcode.part_id == part_id).order_by(PartBarcode.created_at).limit(1)
        )
        if replacement:
            replacement.is_primary = True
    db.commit()


@app.post(
    "/api/v1/parts/{part_id}/compatibilities",
    response_model=CompatibilityOut,
    status_code=status.HTTP_201_CREATED,
)
def add_compatibility(
    part_id: str,
    payload: CompatibilityCreate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if db.get(SparePart, part_id) is None:
        _not_found("Ersatzteil")
    if db.get(EquipmentType, payload.equipment_type_id) is None:
        _not_found("Gerätetyp")
    compatibility = PartCompatibility(part_id=part_id, **payload.model_dump())
    db.add(compatibility)
    try:
        db.commit()
    except IntegrityError as exc:
        _conflict(db, "Diese Gerätezuordnung ist bereits vorhanden.", exc)
    return db.scalar(
        select(PartCompatibility)
        .options(selectinload(PartCompatibility.equipment_type))
        .where(PartCompatibility.id == compatibility.id)
    )


@app.delete("/api/v1/parts/{part_id}/compatibilities/{compatibility_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_compatibility(
    part_id: str,
    compatibility_id: str,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    item = db.scalar(
        select(PartCompatibility).where(
            PartCompatibility.id == compatibility_id, PartCompatibility.part_id == part_id
        )
    )
    if item is None:
        _not_found("Gerätezuordnung")
    db.delete(item)
    db.commit()


@app.get("/api/v1/barcodes/resolve", response_model=PartOut)
def resolve_barcode(
    value: str = Query(min_length=1),
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    key = normalize_barcode(value)
    barcode = db.scalar(select(PartBarcode).where(PartBarcode.match_key == key))
    if barcode is None:
        _not_found("Barcode")
    part = db.scalar(_part_statement().where(SparePart.id == barcode.part_id))
    if part is None:
        _not_found("Ersatzteil")
    return part


@app.post("/api/v1/movements", response_model=MovementOut, status_code=status.HTTP_201_CREATED)
def create_movement(
    payload: MovementCreate,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if payload.idempotency_key:
        existing = db.scalar(
            select(StockMovement)
            .options(selectinload(StockMovement.part), selectinload(StockMovement.created_by))
            .where(StockMovement.external_idempotency_key == payload.idempotency_key)
        )
        if existing is not None:
            return _movement_out(existing)

    part_id = payload.part_id
    barcode_value = payload.barcode.strip()
    if barcode_value:
        key = normalize_barcode(barcode_value)
        barcode_record = db.scalar(select(PartBarcode).where(PartBarcode.match_key == key))
        if barcode_record is None:
            _not_found("Barcode")
        if part_id and part_id != barcode_record.part_id:
            raise HTTPException(status_code=409, detail="Barcode und ausgewähltes Ersatzteil stimmen nicht überein.")
        part_id = barcode_record.part_id
    if not part_id:
        raise HTTPException(status_code=422, detail="Ersatzteil oder Barcode muss angegeben werden.")

    part = db.scalar(select(SparePart).where(SparePart.id == part_id).with_for_update())
    if part is None or part.is_archived:
        _not_found("Ersatzteil")

    work_order = None
    if payload.work_order_id:
        work_order = db.get(WorkOrder, payload.work_order_id)
        if work_order is None:
            _not_found("Auftrag")
        if payload.kind == "Ausgang" and work_order.equipment_type_id:
            is_compatible = db.scalar(
                select(func.count())
                .select_from(PartCompatibility)
                .where(
                    PartCompatibility.part_id == part.id,
                    PartCompatibility.equipment_type_id == work_order.equipment_type_id,
                )
            )
            if not is_compatible:
                raise HTTPException(
                    status_code=409,
                    detail="Dieses Ersatzteil ist dem im Auftrag hinterlegten Regler/Piloten nicht zugeordnet.",
                )

    if payload.kind == "Ausgang" and part.stock_quantity < payload.quantity:
        raise HTTPException(
            status_code=409,
            detail=f"Nicht genügend Bestand. Verfügbar: {part.stock_quantity} {part.unit}.",
        )

    delta = payload.quantity if payload.kind == "Eingang" else -payload.quantity
    part.stock_quantity += delta
    part.updated_at = utcnow()
    movement = StockMovement(
        part_id=part.id,
        kind=payload.kind,
        quantity=payload.quantity,
        reference=payload.reference.strip(),
        notes=payload.notes.strip(),
        stock_after=part.stock_quantity,
        barcode_used=barcode_value,
        work_order_id=work_order.id if work_order else None,
        created_by_id=user.id,
        sync_status="Ausstehend" if (settings.sap_enabled or settings.ih2go_enabled) else "Nicht erforderlich",
        external_idempotency_key=payload.idempotency_key,
    )
    db.add(movement)

    if work_order and payload.kind == "Ausgang":
        component = db.scalar(
            select(OrderComponent)
            .where(OrderComponent.work_order_id == work_order.id, OrderComponent.part_id == part.id)
            .order_by(OrderComponent.item_number)
            .limit(1)
        )
        if component:
            component.withdrawn_quantity += payload.quantity

    db.commit()
    loaded = db.scalar(
        select(StockMovement)
        .options(selectinload(StockMovement.part), selectinload(StockMovement.created_by))
        .where(StockMovement.id == movement.id)
    )
    if loaded is None:
        _not_found("Buchung")
    return _movement_out(loaded)


@app.get("/api/v1/movements", response_model=list[MovementOut])
def list_movements(
    part_id: str | None = None,
    work_order_id: str | None = None,
    limit: int = Query(default=100, ge=1, le=1000),
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    statement = select(StockMovement).options(
        selectinload(StockMovement.part), selectinload(StockMovement.created_by)
    )
    if part_id:
        statement = statement.where(StockMovement.part_id == part_id)
    if work_order_id:
        statement = statement.where(StockMovement.work_order_id == work_order_id)
    rows = db.scalars(statement.order_by(StockMovement.timestamp.desc()).limit(limit)).all()
    return [_movement_out(row) for row in rows]


@app.get("/api/v1/dashboard", response_model=DashboardOut)
def dashboard(
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    active_filter = SparePart.is_archived.is_(False)
    part_count = db.scalar(select(func.count()).select_from(SparePart).where(active_filter)) or 0
    stock_total = db.scalar(select(func.coalesce(func.sum(SparePart.stock_quantity), 0)).where(active_filter)) or 0
    low_stock_count = db.scalar(
        select(func.count()).select_from(SparePart).where(
            active_filter,
            SparePart.reminder_enabled.is_(True),
            SparePart.stock_quantity <= SparePart.minimum_stock,
        )
    ) or 0
    open_order_count = db.scalar(
        select(func.count()).select_from(WorkOrder).where(
            WorkOrder.status.notin_(["Abgeschlossen", "Technisch abgeschlossen"])
        )
    ) or 0
    local_now = datetime.now().astimezone()
    start_local = datetime.combine(local_now.date(), time.min, tzinfo=local_now.tzinfo)
    movement_count_today = db.scalar(
        select(func.count()).select_from(StockMovement).where(StockMovement.timestamp >= start_local)
    ) or 0
    recent = db.scalars(
        select(StockMovement)
        .options(selectinload(StockMovement.part), selectinload(StockMovement.created_by))
        .order_by(StockMovement.timestamp.desc())
        .limit(10)
    ).all()
    low_parts = db.scalars(
        _part_statement()
        .where(
            active_filter,
            SparePart.reminder_enabled.is_(True),
            SparePart.stock_quantity <= SparePart.minimum_stock,
        )
        .order_by((SparePart.minimum_stock - SparePart.stock_quantity).desc(), SparePart.part_name)
        .limit(25)
    ).unique().all()
    return DashboardOut(
        part_count=part_count,
        stock_total=stock_total,
        low_stock_count=low_stock_count,
        open_order_count=open_order_count,
        movement_count_today=movement_count_today,
        recent_movements=[_movement_out(row) for row in recent],
        low_stock_parts=low_parts,
    )


@app.get("/api/v1/work-orders", response_model=list[WorkOrderOut])
def list_work_orders(
    q: str = "",
    open_only: bool = False,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    statement = _work_order_statement()
    if q.strip():
        pattern = f"%{q.strip()}%"
        statement = statement.where(
            or_(
                WorkOrder.order_number.ilike(pattern),
                WorkOrder.customer_name.ilike(pattern),
                WorkOrder.customer_number.ilike(pattern),
                WorkOrder.equipment_number.ilike(pattern),
            )
        )
    if open_only:
        statement = statement.where(WorkOrder.status.notin_(["Abgeschlossen", "Technisch abgeschlossen"]))
    return db.scalars(statement.order_by(WorkOrder.planned_start, WorkOrder.order_number)).unique().all()


@app.post("/api/v1/work-orders", response_model=WorkOrderOut, status_code=status.HTTP_201_CREATED)
def create_work_order(
    payload: WorkOrderCreate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if payload.equipment_type_id and db.get(EquipmentType, payload.equipment_type_id) is None:
        _not_found("Gerätetyp")
    if db.scalar(select(WorkOrder.id).where(WorkOrder.order_number == payload.order_number.strip())):
        raise HTTPException(status_code=409, detail="Diese Auftragsnummer ist bereits vorhanden.")
    values = payload.model_dump(exclude={"components"})
    values["order_number"] = payload.order_number.strip()
    order = WorkOrder(**values, source_system="Gaslager Standalone")
    db.add(order)
    db.flush()
    for component in payload.components:
        if component.part_id and db.get(SparePart, component.part_id) is None:
            _not_found("Ersatzteil")
        db.add(OrderComponent(work_order_id=order.id, **component.model_dump()))
    try:
        db.commit()
    except IntegrityError as exc:
        _conflict(db, "Diese Auftragsnummer ist bereits vorhanden.", exc)
    return db.scalar(_work_order_statement().where(WorkOrder.id == order.id))


@app.patch("/api/v1/work-orders/{order_id}", response_model=WorkOrderOut)
def update_work_order(
    order_id: str,
    payload: WorkOrderUpdate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    order = db.get(WorkOrder, order_id)
    if order is None:
        _not_found("Auftrag")
    values = payload.model_dump(exclude_unset=True)
    if "equipment_type_id" in values and values["equipment_type_id"] and db.get(EquipmentType, values["equipment_type_id"]) is None:
        _not_found("Gerätetyp")
    for key, value in values.items():
        setattr(order, key, value)
    order.updated_at = utcnow()
    db.commit()
    return db.scalar(_work_order_statement().where(WorkOrder.id == order.id))


@app.get("/api/v1/work-orders/{order_id}/compatible-parts", response_model=list[PartOut])
def compatible_parts(
    order_id: str,
    in_stock_only: bool = False,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    order = db.get(WorkOrder, order_id)
    if order is None:
        _not_found("Auftrag")
    statement = _part_statement().where(SparePart.is_archived.is_(False))
    if order.equipment_type_id:
        ids = select(PartCompatibility.part_id).where(
            PartCompatibility.equipment_type_id == order.equipment_type_id
        )
        statement = statement.where(SparePart.id.in_(ids))
    if in_stock_only:
        statement = statement.where(SparePart.stock_quantity > 0)
    return db.scalars(statement.order_by(SparePart.part_name)).unique().all()


@app.get("/api/v1/documents", response_model=list[DocumentOut])
def list_documents(
    equipment_type_id: str | None = None,
    q: str = "",
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    statement = _document_statement()
    if equipment_type_id:
        statement = statement.where(TechnicalDocument.equipment_type_id == equipment_type_id)
    if q.strip():
        pattern = f"%{q.strip()}%"
        statement = statement.where(TechnicalDocument.title.ilike(pattern))
    documents = db.scalars(statement.order_by(TechnicalDocument.title)).unique().all()
    return [_document_out(document) for document in documents]


@app.post("/api/v1/documents/link", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
def create_document_link(
    payload: DocumentLinkCreate,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if payload.equipment_type_id and db.get(EquipmentType, payload.equipment_type_id) is None:
        _not_found("Gerätetyp")
    document = TechnicalDocument(
        equipment_type_id=payload.equipment_type_id,
        title=payload.title.strip(),
        kind=payload.kind.strip(),
        source_url=str(payload.source_url),
        is_official_manufacturer_source=payload.is_official_manufacturer_source,
    )
    db.add(document)
    db.commit()
    return _document_out(db.scalar(_document_statement().where(TechnicalDocument.id == document.id)))


@app.post("/api/v1/documents/upload", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_document(
    equipment_type_id: str = Form(default=""),
    title: str = Form(),
    kind: str = Form(default="Sonstiges"),
    is_official_manufacturer_source: bool = Form(default=False),
    file: UploadFile = File(),
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if equipment_type_id and db.get(EquipmentType, equipment_type_id) is None:
        _not_found("Gerätetyp")
    if not title.strip():
        raise HTTPException(status_code=422, detail="Dokumenttitel fehlt.")
    original_name = Path(file.filename or "unterlage.pdf").name
    if file.content_type not in {"application/pdf", "application/octet-stream"} or not original_name.lower().endswith(".pdf"):
        raise HTTPException(status_code=415, detail="Es werden ausschließlich PDF-Dateien akzeptiert.")
    header = await file.read(5)
    if header != b"%PDF-":
        raise HTTPException(status_code=415, detail="Die Datei ist kein gültiges PDF-Dokument.")
    await file.seek(0)
    document_id = str(uuid.uuid4())
    stored_name = f"{document_id}.pdf"
    destination = settings.documents_dir / stored_name
    size = 0
    with destination.open("wb") as output:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > settings.max_upload_mb * 1024 * 1024:
                output.close()
                destination.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail=f"PDF darf höchstens {settings.max_upload_mb} MB groß sein.")
            output.write(chunk)
    document = TechnicalDocument(
        id=document_id,
        equipment_type_id=equipment_type_id or None,
        title=title.strip(),
        kind=kind.strip() or "Sonstiges",
        stored_filename=stored_name,
        original_filename=original_name,
        is_official_manufacturer_source=is_official_manufacturer_source,
    )
    db.add(document)
    try:
        db.commit()
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    return _document_out(db.scalar(_document_statement().where(TechnicalDocument.id == document.id)))


@app.get("/api/v1/documents/{document_id}/file")
def download_document(
    document_id: str,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    document = db.get(TechnicalDocument, document_id)
    if document is None or not document.stored_filename:
        _not_found("PDF-Datei")
    path = settings.documents_dir / document.stored_filename
    if not path.is_file():
        _not_found("PDF-Datei")
    return FileResponse(path, media_type="application/pdf", filename=document.original_filename or "unterlage.pdf")


@app.delete("/api/v1/documents/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_document(
    document_id: str,
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    document = db.get(TechnicalDocument, document_id)
    if document is None:
        _not_found("Unterlage")
    stored_name = document.stored_filename
    db.delete(document)
    db.commit()
    if stored_name:
        (settings.documents_dir / stored_name).unlink(missing_ok=True)


CATALOG_HEADER = [
    "barcode",
    "barcode_typ",
    "hersteller",
    "original_artikelnummer",
    "bezeichnung",
    "schublade",
    "lagerort",
    "geraetetyp",
    "kategorie",
    "ersatzteilnummer_am_geraet",
    "einheit",
    "bestand",
    "mindestbestand",
    "erinnerung",
    "notiz",
    "sap_materialnummer",
    "sap_werk",
    "sap_lagerort",
    "sap_basiseinheit",
]


def _csv_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "ja", "j", "true", "wahr", "aktiv"}


def _csv_int(value: str, default: int = 0) -> int:
    if not value.strip():
        return default
    parsed = int(value)
    if parsed < 0:
        raise ValueError("negative Zahl")
    return parsed


@app.get("/api/v1/catalog/export")
def export_catalog(
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    parts = db.scalars(_part_statement().order_by(SparePart.manufacturer, SparePart.original_article_number)).unique().all()
    output = io.StringIO()
    writer = csv.writer(output, delimiter=";", lineterminator="\r\n")
    writer.writerow(CATALOG_HEADER)
    for part in parts:
        barcodes = part.barcodes or [None]
        compatibilities = part.compatibilities or [None]
        for barcode in barcodes:
            for compatibility in compatibilities:
                equipment = compatibility.equipment_type if compatibility else (part.drawer.equipment_type if part.drawer else None)
                mapping = part.material_mapping
                writer.writerow(
                    [
                        barcode.value if barcode else "",
                        barcode.symbology if barcode else "",
                        part.manufacturer,
                        part.original_article_number,
                        part.part_name,
                        part.drawer.code if part.drawer else "",
                        part.drawer.location if part.drawer else "",
                        equipment.designation if equipment else "",
                        equipment.kind if equipment else "",
                        compatibility.device_spare_part_number if compatibility else "",
                        part.unit,
                        part.stock_quantity,
                        part.minimum_stock,
                        "ja" if part.reminder_enabled else "nein",
                        part.notes,
                        mapping.material_number if mapping else "",
                        mapping.plant if mapping else "",
                        mapping.storage_location if mapping else "",
                        mapping.base_unit if mapping else "",
                    ]
                )
    content = "\ufeff" + output.getvalue()
    return StreamingResponse(
        iter([content.encode("utf-8")]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=Gaslager_Katalog.csv"},
    )


@app.get("/api/v1/compatibilities/template")
def compatibility_template(user: User = Depends(current_user)):
    output = io.StringIO()
    writer = csv.writer(output, delimiter=";", lineterminator="\n")
    writer.writerow(COMPATIBILITY_HEADERS)
    return StreamingResponse(
        iter([("\ufeff" + output.getvalue()).encode("utf-8")]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=Gaslager_Mehrfachverwendung_Vorlage.csv"},
    )


@app.get("/api/v1/compatibilities/export")
def compatibility_export(user: User = Depends(current_user), db: Session = Depends(get_db)):
    output = io.StringIO()
    writer = csv.writer(output, delimiter=";", lineterminator="\n")
    writer.writerow(COMPATIBILITY_HEADERS)
    rows = db.execute(
        select(PartCompatibility, SparePart, EquipmentType)
        .join(SparePart, PartCompatibility.part_id == SparePart.id)
        .join(EquipmentType, PartCompatibility.equipment_type_id == EquipmentType.id)
        .order_by(SparePart.manufacturer, SparePart.original_article_number, EquipmentType.designation)
    )
    for mapping, part, equipment in rows:
        writer.writerow([
            part.manufacturer, part.original_article_number, equipment.designation,
            equipment.kind, mapping.device_spare_part_number, mapping.notes,
        ])
    return StreamingResponse(
        iter([("\ufeff" + output.getvalue()).encode("utf-8")]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=Gaslager_Mehrfachverwendung.csv"},
    )


@app.post("/api/v1/compatibilities/import")
async def import_compatibilities(
    file: UploadFile = File(),
    commit: bool = Query(default=False),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    raw = await file.read(10 * 1024 * 1024 + 1)
    if len(raw) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="CSV-/Excel-Datei darf höchstens 10 MB groß sein.")
    try:
        report, proposed = preview_import(db, file.filename or "", raw)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if commit and not report["errors"]:
        for part_id, equipment_type_id, number, note in proposed:
            db.add(PartCompatibility(
                part_id=part_id, equipment_type_id=equipment_type_id,
                device_spare_part_number=number, notes=note,
            ))
        try:
            db.commit()
        except IntegrityError as exc:
            _conflict(db, "Eine Zuordnung wurde inzwischen geändert. Bitte die Datei erneut prüfen.", exc)
        report["committed"] = True
    return report


@app.post("/api/v1/catalog/import", response_model=ImportReport)
async def import_catalog(
    file: UploadFile = File(),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    raw = await file.read(10 * 1024 * 1024 + 1)
    if len(raw) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="CSV-Datei darf höchstens 10 MB groß sein.")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252")
    reader = csv.DictReader(io.StringIO(text), delimiter=";")
    if not reader.fieldnames:
        raise HTTPException(status_code=422, detail="CSV-Datei enthält keine Kopfzeile.")
    fields = {name.strip().lower() for name in reader.fieldnames if name}
    required = {"barcode", "hersteller", "original_artikelnummer", "bezeichnung"}
    missing = sorted(required - fields)
    if missing:
        raise HTTPException(status_code=422, detail=f"Pflichtspalten fehlen: {', '.join(missing)}")

    report = ImportReport()
    for row_number, original_row in enumerate(reader, start=2):
        row = {(key or "").strip().lower(): (value or "").strip() for key, value in original_row.items()}
        if not any(row.values()):
            continue
        created_part = created_barcode = created_equipment = created_drawer = False
        try:
            manufacturer = row.get("hersteller", "")
            article = row.get("original_artikelnummer", "")
            part_name = row.get("bezeichnung", "")
            barcode_value = row.get("barcode", "")
            if not all([manufacturer, article, part_name, barcode_value]):
                raise ValueError("Barcode, Hersteller, Original-Artikelnummer und Bezeichnung sind Pflichtfelder")
            minimum = _csv_int(row.get("mindestbestand", ""))
            initial_stock = _csv_int(row.get("bestand", ""))

            equipment = None
            equipment_designation = row.get("geraetetyp", "")
            equipment_kind = row.get("kategorie", "")
            if equipment_designation:
                if equipment_kind not in {"Gasdruckregler", "Pilot"}:
                    raise ValueError("Kategorie muss Gasdruckregler oder Pilot sein")
                equipment = db.scalar(
                    select(EquipmentType).where(
                        func.lower(EquipmentType.manufacturer) == manufacturer.lower(),
                        func.lower(EquipmentType.designation) == equipment_designation.lower(),
                        EquipmentType.kind == equipment_kind,
                    )
                )
                if equipment is None:
                    equipment = EquipmentType(
                        manufacturer=manufacturer,
                        designation=equipment_designation,
                        kind=equipment_kind,
                        status="Eigener Bestandstyp",
                    )
                    db.add(equipment)
                    db.flush()
                    created_equipment = True

            drawer = None
            drawer_code = row.get("schublade", "")
            if drawer_code:
                if equipment is None:
                    raise ValueError("Für eine Schublade muss ein Gerätetyp angegeben sein")
                drawer = db.scalar(select(Drawer).where(func.lower(Drawer.code) == drawer_code.lower()))
                if drawer is None:
                    drawer = Drawer(
                        code=drawer_code,
                        location=row.get("lagerort", ""),
                        equipment_type_id=equipment.id,
                    )
                    db.add(drawer)
                    db.flush()
                    created_drawer = True
                elif drawer.equipment_type_id != equipment.id:
                    raise ValueError("Schublade gehört bereits zu einem anderen Gerätetyp")

            part = db.scalar(
                select(SparePart).where(
                    func.lower(SparePart.manufacturer) == manufacturer.lower(),
                    func.lower(SparePart.original_article_number) == article.lower(),
                )
            )
            if part is None:
                part = SparePart(
                    manufacturer=manufacturer,
                    original_article_number=article,
                    part_name=part_name,
                    unit=row.get("einheit", "") or "Stück",
                    drawer_id=drawer.id if drawer else None,
                    stock_quantity=initial_stock,
                    minimum_stock=minimum,
                    reminder_enabled=_csv_bool(row.get("erinnerung", "")),
                    notes=row.get("notiz", ""),
                )
                db.add(part)
                db.flush()
                created_part = True
                if initial_stock:
                    db.add(
                        StockMovement(
                            part_id=part.id,
                            kind="Bestandsübernahme",
                            quantity=initial_stock,
                            reference="CSV-Import",
                            stock_after=initial_stock,
                            barcode_used=barcode_value,
                            created_by_id=user.id,
                        )
                    )
            else:
                part.part_name = part_name
                part.unit = row.get("einheit", "") or part.unit
                part.drawer_id = drawer.id if drawer else part.drawer_id
                part.minimum_stock = minimum
                part.reminder_enabled = _csv_bool(row.get("erinnerung", ""))
                part.notes = row.get("notiz", "")
                part.updated_at = utcnow()

            key = normalize_barcode(barcode_value)
            assigned = db.scalar(select(PartBarcode).where(PartBarcode.match_key == key))
            if assigned and assigned.part_id != part.id:
                raise ValueError("Barcode ist bereits einem anderen Artikel zugeordnet")
            if assigned is None:
                has_barcode = db.scalar(select(func.count()).select_from(PartBarcode).where(PartBarcode.part_id == part.id))
                db.add(
                    PartBarcode(
                        value=barcode_value,
                        match_key=key,
                        symbology=row.get("barcode_typ", ""),
                        part_id=part.id,
                        is_primary=not bool(has_barcode),
                    )
                )
                created_barcode = True

            device_number = row.get("ersatzteilnummer_am_geraet", "")
            if equipment and device_number:
                existing = db.scalar(
                    select(PartCompatibility).where(
                        PartCompatibility.part_id == part.id,
                        PartCompatibility.equipment_type_id == equipment.id,
                        func.lower(PartCompatibility.device_spare_part_number) == device_number.lower(),
                    )
                )
                if existing is None:
                    db.add(
                        PartCompatibility(
                            part_id=part.id,
                            equipment_type_id=equipment.id,
                            device_spare_part_number=device_number,
                        )
                    )

            material_number = row.get("sap_materialnummer", "")
            if material_number:
                mapping = db.scalar(select(SAPMaterialMapping).where(SAPMaterialMapping.part_id == part.id))
                if mapping is None:
                    db.add(
                        SAPMaterialMapping(
                            part_id=part.id,
                            material_number=material_number,
                            plant=row.get("sap_werk", ""),
                            storage_location=row.get("sap_lagerort", ""),
                            base_unit=row.get("sap_basiseinheit", "") or "ST",
                        )
                    )
                else:
                    mapping.material_number = material_number
                    mapping.plant = row.get("sap_werk", "")
                    mapping.storage_location = row.get("sap_lagerort", "")
                    mapping.base_unit = row.get("sap_basiseinheit", "") or "ST"
            db.commit()
            if created_part:
                report.created_parts += 1
            else:
                report.updated_parts += 1
            if created_barcode:
                report.created_barcodes += 1
            if created_equipment:
                report.created_equipment_types += 1
            if created_drawer:
                report.created_drawers += 1
        except (ValueError, IntegrityError) as exc:
            db.rollback()
            message = str(exc.orig) if isinstance(exc, IntegrityError) else str(exc)
            report.errors.append(f"Zeile {row_number}: {message}")
    return report


# Neutraler IH2Go-/SAP-Bridge-Vertrag. Die Routen bleiben auch im Standalone-Modus
# lesbar, lösen ohne aktivierte Integration jedoch keine externe Synchronisierung aus.
@app.get("/api/gaslager/v1/work-orders")
def bridge_work_orders(
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    orders = db.scalars(_work_order_statement()).unique().all()
    return {
        "mode": "standalone" if settings.standalone_mode else "integration",
        "items": [
            {
                "order_number": order.order_number,
                "customer_number": order.customer_number,
                "customer_name": order.customer_name,
                "equipment_number": order.equipment_number,
                "functional_location": order.functional_location,
                "equipment_manufacturer": order.equipment_type.manufacturer if order.equipment_type else "",
                "equipment_type": order.equipment_type.designation if order.equipment_type else "",
                "equipment_kind": order.equipment_type.kind if order.equipment_type else "Gasdruckregler",
                "short_text": order.short_text,
                "status": order.status,
                "planned_start": order.planned_start,
                "plant": "",
                "storage_location": "",
                "components": [
                    {
                        "item_number": item.item_number,
                        "material_number": item.material_number,
                        "description": item.description,
                        "required_quantity": item.required_quantity,
                        "withdrawn_quantity": item.withdrawn_quantity,
                    }
                    for item in order.components
                ],
            }
            for order in orders
        ]
    }


@app.get("/api/gaslager/v1/stock")
def bridge_stock(
    _user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    mappings = db.scalars(select(SAPMaterialMapping).options(selectinload(SAPMaterialMapping.part))).all()
    return {
        "mode": "standalone" if settings.standalone_mode else "integration",
        "items": [
            {
                "material_number": mapping.material_number,
                "plant": mapping.plant,
                "storage_location": mapping.storage_location,
                "available_quantity": mapping.part.stock_quantity,
            }
            for mapping in mappings
        ]
    }


@app.post("/api/gaslager/v1/material-movements")
def bridge_material_movement(
    payload: dict,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    key = str(payload.get("idempotency_key", "")).strip()
    if not key:
        raise HTTPException(status_code=422, detail="idempotency_key fehlt.")
    existing = db.scalar(select(StockMovement).where(StockMovement.external_idempotency_key == key))
    if existing:
        return {
            "accepted": True,
            "mode": "standalone" if settings.standalone_mode else "integration",
            "material_document": existing.id,
            "message": "Bereits verarbeitet",
        }
    mapping = db.scalar(
        select(SAPMaterialMapping).where(SAPMaterialMapping.material_number == str(payload.get("material_number", "")))
    )
    if mapping is None:
        raise HTTPException(status_code=409, detail="SAP-Materialnummer ist keinem Ersatzteil zugeordnet.")
    operation = str(payload.get("operation", ""))
    if operation not in {"WARENAUSGANG", "WARENEINGANG"}:
        raise HTTPException(status_code=422, detail="operation muss WARENAUSGANG oder WARENEINGANG sein.")
    kind = "Ausgang" if operation == "WARENAUSGANG" else "Eingang"
    quantity = int(payload.get("quantity", 0))
    if quantity <= 0:
        raise HTTPException(status_code=422, detail="Menge muss größer als 0 sein.")
    part = db.scalar(select(SparePart).where(SparePart.id == mapping.part_id).with_for_update())
    if part is None:
        _not_found("Ersatzteil")
    if kind == "Ausgang" and part.stock_quantity < quantity:
        raise HTTPException(status_code=409, detail="Nicht genügend Bestand.")
    part.stock_quantity += quantity if kind == "Eingang" else -quantity
    order = db.scalar(select(WorkOrder).where(WorkOrder.order_number == str(payload.get("order_number", ""))))
    movement = StockMovement(
        part_id=part.id,
        kind=kind,
        quantity=quantity,
        reference=str(payload.get("reference", "")),
        notes=str(payload.get("note", "")),
        stock_after=part.stock_quantity,
        barcode_used=str(payload.get("barcode", "")),
        work_order_id=order.id if order else None,
        created_by_id=user.id,
        sync_status="Nicht erforderlich" if settings.standalone_mode else "Synchronisiert",
        external_idempotency_key=key,
    )
    db.add(movement)
    db.commit()
    return {
        "accepted": True,
        "mode": "standalone" if settings.standalone_mode else "integration",
        "material_document": movement.id,
        "message": "Lokal gebucht",
    }
