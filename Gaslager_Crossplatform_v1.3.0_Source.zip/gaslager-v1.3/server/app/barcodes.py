from __future__ import annotations


def normalize_barcode(value: str) -> str:
    """Matches the iOS normalizer while preserving leading zeros and GS1 separators."""
    normalized = value.replace("\u200b", "").strip()
    if len(normalized) >= 3 and normalized[0] == "]":
        prefix = normalized[:3]
        if all(char.isalnum() for char in prefix[1:]):
            normalized = normalized[3:]
    return normalized
