from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "ja", "on"}


@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./gaslager.db")
    secret_key: str = os.getenv("SECRET_KEY", "development-only-change-me")
    admin_username: str = os.getenv("ADMIN_USERNAME", "admin")
    admin_password: str = os.getenv("ADMIN_PASSWORD", "gaslager")
    token_hours: int = int(os.getenv("TOKEN_HOURS", "12"))
    documents_dir: Path = Path(os.getenv("DOCUMENTS_DIR", "/data/documents"))
    standalone_mode: bool = _bool("STANDALONE_MODE", True)
    sap_enabled: bool = _bool("SAP_ENABLED", False)
    ih2go_enabled: bool = _bool("IH2GO_ENABLED", False)
    seed_catalog: bool = _bool("SEED_EQUIPMENT_CATALOG", True)
    max_upload_mb: int = int(os.getenv("MAX_UPLOAD_MB", "30"))


settings = Settings()
