from __future__ import annotations

import csv
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .config import settings
from .models import EquipmentType, TechnicalDocument, User
from .security import hash_password


REGULATORS_URL = "https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories"
PILOTS_URL = f"{REGULATORS_URL}/pilot-for-gas-pressure-regulators"
SPARE_PARTS_URL = (
    f"{REGULATORS_URL}/regulators-and-safety-accessories-spare-parts/"
    "spare-parts-regulators-and-safety-accessories"
)
DOCUMENT_ARCHIVE_URL = "https://www.hongastec.de/service/download-dokumente"
BROCHURES = {
    "HON 402": (
        "HON 402 – Produktbroschüre",
        "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/"
        "regulators---safety-accessories/high-pressure-regulators-up-to-pn40-(ansi-300)/hon-402/"
        "hon-402-brochure.pdf?download=false",
    ),
    "HON 503": (
        "HON 503 – Produktbroschüre",
        "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/"
        "regulators---safety-accessories/high-pressure-regulators-up-to-ansi-600/hon-503/"
        "hon-503-brochure.pdf?download=false",
    ),
    "HON 630": (
        "HON 630 / HON 630a – Produktbroschüre",
        "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/"
        "regulators---safety-accessories/series-600-pilot-regulators-for-pilot-operated-gas-pressure-regulators/"
        "hon-630/hon-630-english.pdf?download=false",
    ),
    "HON 650": (
        "HON 650 – Produktbroschüre",
        "https://prod-edam.honeywell.com/content/dam/honeywell-edam/pmt/hps/products/pmc/gas/"
        "regulators---safety-accessories/series-600-pilot-regulators-for-pilot-operated-gas-pressure-regulators/"
        "hon-650/hon-650-english.pdf?download=false",
    ),
}


def ensure_initial_data(db: Session) -> None:
    user = db.scalar(select(User).where(User.username == settings.admin_username))
    if user is None:
        db.add(
            User(
                username=settings.admin_username,
                password_hash=hash_password(settings.admin_password),
                display_name="Administrator",
                is_admin=True,
            )
        )

    equipment_count = db.scalar(select(func.count()).select_from(EquipmentType)) or 0
    if settings.seed_catalog and equipment_count == 0:
        seed_path = Path(__file__).resolve().parent.parent / "seed" / "equipment_catalog.csv"
        with seed_path.open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle, delimiter=";"):
                db.add(
                    EquipmentType(
                        manufacturer=row["hersteller"].strip(),
                        designation=row["geraetetyp"].strip(),
                        kind=row["kategorie"].strip(),
                        series=row["baureihe_druckstufe"].strip(),
                        status=row["portfolio_status"].strip(),
                        notes=row["hinweis"].strip(),
                    )
                )

    db.flush()
    document_count = db.scalar(select(func.count()).select_from(TechnicalDocument)) or 0
    if settings.seed_catalog and document_count == 0:
        equipment_rows = db.scalars(select(EquipmentType)).all()
        for equipment in equipment_rows:
            is_legacy = "Altanlage" in equipment.status or "Bestands" in equipment.status
            source_url = DOCUMENT_ARCHIVE_URL if is_legacy else (PILOTS_URL if equipment.kind == "Pilot" else REGULATORS_URL)
            db.add(
                TechnicalDocument(
                    equipment_type_id=equipment.id,
                    title=f"{equipment.designation} – offizielle Herstellerquelle",
                    kind="Herstellerseite",
                    source_url=source_url,
                    is_official_manufacturer_source=True,
                )
            )

        by_designation = {item.designation: item for item in equipment_rows}
        for designation, (title, source_url) in BROCHURES.items():
            equipment = by_designation.get(designation)
            if equipment:
                db.add(
                    TechnicalDocument(
                        equipment_type_id=equipment.id,
                        title=title,
                        kind="Broschüre",
                        source_url=source_url,
                        is_official_manufacturer_source=True,
                    )
                )
        first_equipment = equipment_rows[0] if equipment_rows else None
        if first_equipment:
            db.add(
                TechnicalDocument(
                    equipment_type_id=first_equipment.id,
                    title="Honeywell – Original-Ersatzteile und Service",
                    kind="Herstellerseite",
                    source_url=SPARE_PARTS_URL,
                    is_official_manufacturer_source=True,
                )
            )
    db.commit()
