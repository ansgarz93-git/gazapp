import unittest

from app.barcodes import normalize_barcode
from app.schemas import BarcodeCreate, MovementCreate, PartCreate


class BarcodeNormalizerTests(unittest.TestCase):
    def test_preserves_leading_zeros(self):
        self.assertEqual(normalize_barcode("0012345678905"), "0012345678905")

    def test_strips_scanner_whitespace_and_aim_prefix(self):
        self.assertEqual(normalize_barcode("  ]C11234567890\n"), "1234567890")

    def test_preserves_gs1_group_separator(self):
        raw = "010123456789012817300101\x1d10ABC"
        self.assertEqual(normalize_barcode(raw), raw)

    def test_removes_zero_width_scanner_artifact(self):
        self.assertEqual(normalize_barcode("ABC\u200b123"), "ABC123")


class SchemaDefaultTests(unittest.TestCase):
    def test_part_lists_do_not_share_mutable_defaults(self):
        first = PartCreate(manufacturer="RMG", original_article_number="1", part_name="Teil")
        second = PartCreate(manufacturer="RMG", original_article_number="2", part_name="Teil")
        first.barcodes.append(BarcodeCreate(value="123"))
        self.assertEqual(second.barcodes, [])

    def test_offline_movement_accepts_idempotency_key(self):
        movement = MovementCreate(
            part_id="part-1",
            kind="Ausgang",
            quantity=1,
            idempotency_key="android-offline-123",
        )
        self.assertEqual(movement.idempotency_key, "android-offline-123")


if __name__ == "__main__":
    unittest.main()
