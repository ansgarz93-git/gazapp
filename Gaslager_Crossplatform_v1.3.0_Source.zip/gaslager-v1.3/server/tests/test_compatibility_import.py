import io
import asyncio
import unittest

from openpyxl import Workbook
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session
from fastapi import UploadFile

from app.compatibility_import import preview_import
from app.database import Base
from app.models import EquipmentType, PartCompatibility, SparePart
from app.main import import_compatibilities


class CompatibilityImportTests(unittest.TestCase):
    def setUp(self):
        self.engine = create_engine("sqlite:///:memory:")
        Base.metadata.create_all(self.engine)
        self.db = Session(self.engine)
        self.db.add(EquipmentType(id="device", manufacturer="RMG", designation="HON 402", kind="Gasdruckregler"))
        self.db.add(SparePart(id="part", manufacturer="RMG", original_article_number="00123", part_name="Dichtung"))
        self.db.commit()

    def tearDown(self):
        self.db.close()
        self.engine.dispose()

    def csv_file(self, *lines):
        return ("hersteller;original_artikelnummer;geraetetyp;kategorie;ersatzteilnummer_am_geraet;notiz\n" + "\n".join(lines)).encode("utf-8")

    def test_preview_does_not_write_and_detects_duplicates(self):
        raw = self.csv_file("RMG;00123;HON 402;Gasdruckregler;A-9;", "RMG;00123;HON 402;Gasdruckregler;A-9;")
        report, proposed = preview_import(self.db, "liste.csv", raw)
        self.assertEqual((report["to_create"], report["already_present"]), (1, 1))
        self.assertEqual(len(proposed), 1)
        self.assertEqual(self.db.scalar(select(PartCompatibility)), None)

    def test_unknown_part_is_error(self):
        report, proposed = preview_import(self.db, "liste.csv", self.csv_file("RMG;999;HON 402;Gasdruckregler;A-9;"))
        self.assertTrue(report["errors"])
        self.assertEqual(proposed, [])

    def test_existing_mapping_is_skipped(self):
        self.db.add(PartCompatibility(part_id="part", equipment_type_id="device", device_spare_part_number="A-9"))
        self.db.commit()
        report, _ = preview_import(self.db, "liste.csv", self.csv_file("RMG;00123;HON 402;Gasdruckregler;A-9;"))
        self.assertEqual((report["to_create"], report["already_present"]), (0, 1))

    def test_api_preview_then_commit(self):
        raw = self.csv_file("RMG;00123;HON 402;Gasdruckregler;A-9;")

        async def run(commit, content):
            return await import_compatibilities(
                file=UploadFile(filename="liste.csv", file=io.BytesIO(content)),
                commit=commit, user=None, db=self.db,
            )

        preview = asyncio.run(run(False, raw))
        self.assertEqual(preview["to_create"], 1)
        self.assertFalse(preview["committed"])
        self.assertEqual(self.db.scalar(select(PartCompatibility)), None)
        committed = asyncio.run(run(True, raw))
        self.assertTrue(committed["committed"])
        self.assertEqual(self.db.scalar(select(PartCompatibility)).device_spare_part_number, "A-9")
        duplicate = asyncio.run(run(True, raw))
        self.assertEqual(duplicate["already_present"], 1)

    def test_api_rejects_entire_file_if_one_row_invalid(self):
        raw = self.csv_file("RMG;00123;HON 402;Gasdruckregler;A-9;", "RMG;999;HON 402;Gasdruckregler;X-2;")
        result = asyncio.run(import_compatibilities(
            file=UploadFile(filename="liste.csv", file=io.BytesIO(raw)),
            commit=True, user=None, db=self.db,
        ))
        self.assertFalse(result["committed"])
        self.assertTrue(result["errors"])
        self.assertEqual(self.db.scalar(select(PartCompatibility)), None)

    def test_excel_text_identifier_preserves_zero(self):
        book = Workbook()
        sheet = book.active
        sheet.append(["hersteller", "original_artikelnummer", "geraetetyp", "kategorie", "ersatzteilnummer_am_geraet"])
        sheet.append(["RMG", "00123", "HON 402", "Gasdruckregler", "A-9"])
        output = io.BytesIO()
        book.save(output)
        report, _ = preview_import(self.db, "liste.xlsx", output.getvalue())
        self.assertEqual(report["to_create"], 1)
        book = Workbook()
        sheet = book.active
        sheet.append(["hersteller", "original_artikelnummer", "geraetetyp", "kategorie", "ersatzteilnummer_am_geraet"])
        sheet.append(["RMG", 123, "HON 402", "Gasdruckregler", "A-9"])
        output = io.BytesIO()
        book.save(output)
        with self.assertRaisesRegex(ValueError, "führende Nullen"):
            preview_import(self.db, "liste.xlsx", output.getvalue())


if __name__ == "__main__":
    unittest.main()
