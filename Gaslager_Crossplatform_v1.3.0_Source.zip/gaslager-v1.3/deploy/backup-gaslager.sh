#!/usr/bin/env bash
set -Eeuo pipefail

readonly INSTALL_DIR="${GASLAGER_INSTALL_DIR:-/opt/gaslager}"
[[ -f "${INSTALL_DIR}/.env" ]] || { echo 'Gaslager-Konfiguration fehlt.' >&2; exit 1; }
# Nur eine vom Administrator verwaltete .env verwenden.
# shellcheck disable=SC1091
source "${INSTALL_DIR}/.env"
readonly BACKUP_DIR="${GASLAGER_BACKUP_DIR:-/var/backups/gaslager}"
[[ ${BACKUP_DIR} == /* && ${BACKUP_DIR} != / && ${BACKUP_DIR} != *..* ]] || { echo 'Ungültiges Backup-Verzeichnis.' >&2; exit 1; }
install -d -m 0700 "${BACKUP_DIR}"
exec 9>"${BACKUP_DIR}/.backup.lock"
flock -n 9 || { echo 'Eine Datensicherung läuft bereits.' >&2; exit 1; }
cd "${INSTALL_DIR}"
stamp="$(date +%Y-%m-%d_%H-%M-%S)"
work="$(mktemp -d "${BACKUP_DIR}/.incomplete-${stamp}-XXXXXX")"
chmod 0700 "${work}"
echo "Sicherung wird erstellt: ${work}"
docker compose exec -T database pg_dump --username "${POSTGRES_USER}" --dbname "${POSTGRES_DB}" --format=custom > "${work}/database.dump"
docker compose exec -T api tar -C /data -czf - documents > "${work}/documents.tar.gz"
docker compose exec -T api python -m app.export_reports > "${work}/mehrfachverwendung.csv"
cp -- .env "${work}/config.env"
chmod 0600 "${work}"/*
(cd "${work}" && sha256sum database.dump documents.tar.gz mehrfachverwendung.csv config.env > SHA256SUMS)
final="${BACKUP_DIR}/backup-${stamp}"
[[ ! -e "${final}" ]] || { echo "Backup-Ziel existiert bereits: ${final}" >&2; exit 1; }
mv -- "${work}" "${final}"
echo "Sicherung vollständig: ${final}"
echo 'Es werden keine älteren Sicherungen automatisch gelöscht; freien Speicher regelmäßig prüfen.'
