#!/usr/bin/env bash
set -Eeuo pipefail

readonly INSTALL_DIR="${GASLAGER_INSTALL_DIR:-/opt/gaslager}"
[[ -f "${INSTALL_DIR}/.env" ]] || { echo 'Gaslager-Konfiguration fehlt.' >&2; exit 1; }
# shellcheck disable=SC1091
source "${INSTALL_DIR}/.env"
readonly EXPORT_DIR="${GASLAGER_EXPORT_DIR:-/var/lib/gaslager/exports}"
[[ ${EXPORT_DIR} == /* && ${EXPORT_DIR} != / && ${EXPORT_DIR} != *..* ]] || { echo 'Ungültiges Export-Verzeichnis.' >&2; exit 1; }
install -d -m 0700 "${EXPORT_DIR}"
cd "${INSTALL_DIR}"
temp="$(mktemp "${EXPORT_DIR}/.mehrfachverwendung-XXXXXX")"
trap 'rm -f -- "${temp}"' EXIT
docker compose exec -T api python -m app.export_reports > "${temp}"
chmod 0600 "${temp}"
mv -- "${temp}" "${EXPORT_DIR}/mehrfachverwendung-aktuell.csv"
echo "Export: ${EXPORT_DIR}/mehrfachverwendung-aktuell.csv"
