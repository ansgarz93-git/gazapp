#!/usr/bin/env bash
set -Eeuo pipefail

readonly INSTALL_DIR=/opt/gaslager
readonly SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
readonly WEB_PORT="${GASLAGER_WEB_PORT:-8080}"
readonly ADMIN_USER="${GASLAGER_ADMIN_USER:-admin}"
readonly DATA_DIR="${GASLAGER_DATA_DIR:-/srv/gaslager}"
readonly REQUESTED_BIND="${GASLAGER_BIND_IP:-}"

fail() { echo "Fehler: $*" >&2; exit 1; }
trap 'echo "Installation abgebrochen (Zeile ${LINENO}); vorhandene Lagerdaten wurden nicht gelöscht." >&2' ERR

[[ ${EUID} -eq 0 ]] || fail 'Bitte mit sudo ausführen.'
[[ -f /etc/os-release ]] || fail 'Ubuntu nicht erkannt.'
# shellcheck disable=SC1091
source /etc/os-release
[[ ${ID:-} == ubuntu && ${VERSION_ID:-} =~ ^(22\.04|24\.04|26\.04)$ ]] || fail 'Unterstützt werden Ubuntu Server 22.04, 24.04 und 26.04.'
[[ -f "${SOURCE_DIR}/docker-compose.yml" && -f "${SOURCE_DIR}/server/Dockerfile" ]] || fail 'Skript aus dem entpackten vollständigen Quellpaket ausführen.'
[[ ${WEB_PORT} =~ ^[0-9]+$ ]] && (( WEB_PORT >= 1024 && WEB_PORT <= 65535 )) || fail 'GASLAGER_WEB_PORT muss zwischen 1024 und 65535 liegen.'
[[ ${ADMIN_USER} =~ ^[A-Za-z][A-Za-z0-9_.-]{2,31}$ ]] || fail 'Ungültiger GASLAGER_ADMIN_USER.'
[[ ${DATA_DIR} == /* && ${DATA_DIR} == */gaslager && ${DATA_DIR} != *..* ]] || fail 'GASLAGER_DATA_DIR muss ein absoluter Pfad mit Endung /gaslager sein.'

private_ip() {
  local ip=$1 a b c d octet
  [[ ${ip} =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || return 1
  IFS=. read -r a b c d <<< "${ip}"
  for octet in "${a}" "${b}" "${c}" "${d}"; do
    [[ ${octet} == 0 || ${octet} != 0* ]] || return 1
    (( 10#${octet} <= 255 )) || return 1
  done
  (( a == 10 || (a == 172 && b >= 16 && b <= 31) || (a == 192 && b == 168) ))
}

detect_lan_ip() {
  local candidate
  if [[ -n ${REQUESTED_BIND} ]]; then
    private_ip "${REQUESTED_BIND}" || fail 'GASLAGER_BIND_IP muss eine private IPv4-Adresse sein.'
    ip -o -4 addr show | grep -Eq "[[:space:]]${REQUESTED_BIND}/" || fail 'GASLAGER_BIND_IP ist nicht diesem PC zugeordnet.'
    printf '%s' "${REQUESTED_BIND}"
    return
  fi
  while read -r candidate; do
    candidate=${candidate%%/*}
    if private_ip "${candidate}"; then printf '%s' "${candidate}"; return; fi
  done < <(ip -o -4 addr show scope global | awk '{print $4}')
  fail 'Keine private IPv4-Adresse gefunden; GASLAGER_BIND_IP ausdrücklich setzen.'
}

command -v ip >/dev/null || fail 'iproute2 fehlt; bitte installieren.'
bind_ip="$(detect_lan_ip)"
if [[ ${1:-} == --plan ]]; then
  echo "Plan: Ubuntu ${VERSION_ID}, Adresse ${bind_ip}:${WEB_PORT}, Daten ${DATA_DIR}, Anwendung ${INSTALL_DIR}."
  echo 'Docker/Compose werden bei Bedarf installiert. Vor einem Update erfolgt eine Datensicherung; SAP/IH2Go bleiben deaktiviert.'
  exit 0
fi
[[ $# -eq 0 ]] || fail 'Unbekanntes Argument. Optional: --plan.'

echo '[1/7] Vorhandene Installation prüfen und ggf. sichern'
if [[ -f "${INSTALL_DIR}/.env" ]]; then
  [[ -f "${INSTALL_DIR}/docker-compose.yml" ]] || fail 'Vorhandene .env ohne Docker-Compose-Datei; manuelle Prüfung nötig.'
  command -v docker >/dev/null && docker compose version >/dev/null || fail 'Update erfordert funktionierendes Docker Compose.'
  if ! (cd "${INSTALL_DIR}" && docker compose ps --status running --services | grep -qx database); then
    fail 'Datenbank läuft nicht; Update erst nach Prüfung/Backup durchführen.'
  fi
  GASLAGER_INSTALL_DIR="${INSTALL_DIR}" bash "${SOURCE_DIR}/deploy/backup-gaslager.sh"
  echo 'Bestehende .env und Speichervolumes bleiben unverändert; keine automatische Migration.'
fi

echo '[2/7] Systempakete und Docker Compose installieren'
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl gnupg openssl rsync gzip tar iproute2 util-linux
if ! command -v docker >/dev/null || ! docker compose version >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  docker_arch="$(dpkg --print-architecture)"
  printf 'Types: deb\nURIs: https://download.docker.com/linux/ubuntu\nSuites: %s\nComponents: stable\nArchitectures: %s\nSigned-By: /etc/apt/keyrings/docker.asc\n' "${VERSION_CODENAME}" "${docker_arch}" > /etc/apt/sources.list.d/docker.sources
  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi
systemctl enable --now docker

echo '[3/7] Datenträger und Anwendung vorbereiten'
install -d -m 0700 "${DATA_DIR}" "${DATA_DIR}/postgres" "${DATA_DIR}/documents" "${DATA_DIR}/backups" "${DATA_DIR}/exports"
chown 1000:1000 "${DATA_DIR}/documents"
install -d -m 0755 "${INSTALL_DIR}"
rsync -a --exclude='.env' --exclude='.git' --exclude='.next' --exclude='node_modules' --exclude='*.pem' --exclude='*.key' "${SOURCE_DIR}/" "${INSTALL_DIR}/"
first_install=false
if [[ ! -f "${INSTALL_DIR}/.env" ]]; then
  first_install=true
  umask 077
  database_password="$(openssl rand -hex 24)"
  secret_key="$(openssl rand -hex 48)"
  admin_password="$(openssl rand -hex 12)"
  {
    printf 'POSTGRES_DB=gaslager\nPOSTGRES_USER=gaslager\n'
    printf 'POSTGRES_PASSWORD=%s\nSECRET_KEY=%s\n' "${database_password}" "${secret_key}"
    printf 'ADMIN_USERNAME=%s\nADMIN_PASSWORD=%s\n' "${ADMIN_USER}" "${admin_password}"
    printf 'WEB_PORT=%s\nGASLAGER_BIND_IP=%s\n' "${WEB_PORT}" "${bind_ip}"
    printf 'GASLAGER_STORAGE_TYPE=bind\nGASLAGER_DATA_DIR=%s\n' "${DATA_DIR}"
    printf 'GASLAGER_DB_SOURCE=%s/postgres\nGASLAGER_DOCUMENTS_SOURCE=%s/documents\n' "${DATA_DIR}" "${DATA_DIR}"
    printf 'GASLAGER_BACKUP_DIR=%s/backups\nGASLAGER_EXPORT_DIR=%s/exports\n' "${DATA_DIR}" "${DATA_DIR}"
    printf 'TOKEN_HOURS=12\nMAX_UPLOAD_MB=30\nTZ=Europe/Berlin\nSTANDALONE_MODE=true\nSAP_ENABLED=false\nIH2GO_ENABLED=false\nSEED_EQUIPMENT_CATALOG=true\n'
  } > "${INSTALL_DIR}/.env"
  chmod 0600 "${INSTALL_DIR}/.env"
else
  # Existing installations may still use Docker named volumes; do not silently switch them.
  bind_ip="$(sed -n 's/^GASLAGER_BIND_IP=//p' "${INSTALL_DIR}/.env" | head -1)"
  [[ -n ${bind_ip} ]] || bind_ip=0.0.0.0
  WEB_PORT_ACTIVE="$(sed -n 's/^WEB_PORT=//p' "${INSTALL_DIR}/.env" | head -1)"
  [[ -n ${WEB_PORT_ACTIVE} ]] || WEB_PORT_ACTIVE=8080
  if [[ ${bind_ip} == 0.0.0.0 ]]; then
    echo 'WARNUNG: Bestehende Installation bindet an alle Netzwerkschnittstellen. Bitte .env/GASLAGER_BIND_IP auf Ihre LAN-IP setzen.' >&2
  fi
fi

echo '[4/7] Autostart und tägliche Sicherung einrichten'
install -m 0644 "${INSTALL_DIR}/deploy/systemd/gaslager.service" /etc/systemd/system/gaslager.service
install -m 0755 "${INSTALL_DIR}/deploy/backup-gaslager.sh" /usr/local/sbin/gaslager-backup
install -m 0755 "${INSTALL_DIR}/deploy/export-gaslager.sh" /usr/local/sbin/gaslager-export
install -m 0644 "${INSTALL_DIR}/deploy/systemd/gaslager-backup.service" /etc/systemd/system/gaslager-backup.service
install -m 0644 "${INSTALL_DIR}/deploy/systemd/gaslager-backup.timer" /etc/systemd/system/gaslager-backup.timer
systemctl daemon-reload
systemctl enable gaslager.service gaslager-backup.timer
systemctl start gaslager-backup.timer

echo '[5/7] Konfiguration prüfen'
cd "${INSTALL_DIR}"
docker compose config --quiet

echo '[6/7] Datenbank, API und Weboberfläche starten'
docker compose up -d --build --remove-orphans

echo '[7/7] Gesundheit prüfen und Export erstellen'
active_port="${WEB_PORT_ACTIVE:-${WEB_PORT}}"
check_ip="${bind_ip}"
[[ ${check_ip} == 0.0.0.0 ]] && check_ip=127.0.0.1
ready=false
for _attempt in $(seq 1 90); do
  if curl --noproxy '*' -fsS "http://${check_ip}:${active_port}/api/v1/health" >/dev/null 2>&1; then ready=true; break; fi
  sleep 2
done
if [[ ${ready} != true ]]; then
  docker compose ps
  fail 'Dienst ist nicht erreichbar; docker compose logs prüfen.'
fi
bash deploy/export-gaslager.sh
if [[ ${first_install} == true ]]; then
  umask 077
  {
    printf 'Gaslager: http://%s:%s\n' "${bind_ip}" "${WEB_PORT}"
    printf 'Benutzername: %s\nStartpasswort: %s\n' "${ADMIN_USER}" "${admin_password}"
  } > /root/gaslager-zugang.txt
  chmod 0600 /root/gaslager-zugang.txt
  echo 'Start-Zugangsdaten: /root/gaslager-zugang.txt (nur root lesbar).'
fi
echo "Fertig: http://${bind_ip}:${active_port}"
echo 'PDF-Upload: Unterlagen. CSV-/XLSX-Import: Einstellungen → Mehrfachverwendung.'
echo 'Ohne Internet im lokalen Netz nutzbar; SAP und IH2Go sind deaktiviert.'
