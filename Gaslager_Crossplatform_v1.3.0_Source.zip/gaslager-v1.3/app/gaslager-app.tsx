"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Barcode,
  BookOpenText,
  Boxes,
  ClipboardList,
  Gauge,
  LogOut,
  Menu,
  PackagePlus,
  Settings,
  Warehouse,
  X,
} from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BookingView } from "./gaslager/booking-view";
import { DashboardView } from "./gaslager/dashboard-view";
import { DocumentsView } from "./gaslager/documents-view";
import { OrdersView } from "./gaslager/orders-view";
import { PartsView } from "./gaslager/parts-view";
import { SettingsView } from "./gaslager/settings-view";
import { StorageView } from "./gaslager/storage-view";

type ViewName = "Übersicht" | "Buchen" | "Ersatzteile" | "Schubladen & Geräte" | "Aufträge" | "Unterlagen" | "Einstellungen";

const navigation: Array<{ label: ViewName; icon: typeof Gauge }> = [
  { label: "Übersicht", icon: Gauge },
  { label: "Buchen", icon: Barcode },
  { label: "Ersatzteile", icon: Boxes },
  { label: "Schubladen & Geräte", icon: Warehouse },
  { label: "Aufträge", icon: ClipboardList },
  { label: "Unterlagen", icon: BookOpenText },
  { label: "Einstellungen", icon: Settings },
];

export default function GaslagerApp() {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [active, setActive] = useState<ViewName>("Übersicht");
  const [refreshKey, setRefreshKey] = useState(0);
  const [mobileOpen, setMobileOpen] = useState(false);

  const signOut = useCallback(async () => {
    await fetch("/api/v1/auth/logout", { method: "POST", credentials: "include" });
    setAuthenticated(false);
  }, []);

  useEffect(() => {
    fetch("/api/v1/auth/me", { credentials: "include" })
      .then((response) => setAuthenticated(response.ok))
      .catch(() => setAuthenticated(false));
    const unauthorized = () => setAuthenticated(false);
    window.addEventListener("gaslager:unauthorized", unauthorized);
    return () => window.removeEventListener("gaslager:unauthorized", unauthorized);
  }, []);

  if (authenticated === null) {
    return <div className="grid min-h-screen place-items-center bg-background text-muted-foreground">Gaslager wird geladen …</div>;
  }
  if (!authenticated) {
    return <><Login onSuccess={() => setAuthenticated(true)} /><Toaster richColors position="top-right" /></>;
  }

  const changed = () => setRefreshKey((value) => value + 1);
  const navigate = (view: ViewName) => { setActive(view); setMobileOpen(false); };

  return (
    <div className="min-h-screen bg-background text-foreground lg:grid lg:grid-cols-[17rem_1fr]">
      <aside className={`${mobileOpen ? "fixed inset-0 z-40 block" : "hidden"} border-sidebar-border bg-sidebar px-5 py-5 lg:sticky lg:top-0 lg:block lg:h-screen lg:border-r`}>
        <div className="mb-6 flex items-center gap-3 px-2">
          <div className="grid size-10 place-items-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"><Warehouse className="size-5" /></div>
          <div className="text-sidebar-foreground"><p className="font-semibold tracking-tight">Gaslager</p><p className="text-xs opacity-70">RMG / Honeywell</p></div>
          <Button size="icon" variant="ghost" className="ml-auto text-sidebar-foreground lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Menü schließen"><X className="size-5" /></Button>
        </div>
        <nav aria-label="Hauptnavigation" className="space-y-1">
          {navigation.map(({ label, icon: Icon }) => (
            <button key={label} onClick={() => navigate(label)} className={`flex min-h-11 w-full items-center gap-3 rounded-lg px-3 text-left text-sm font-medium transition ${active === label ? "bg-sidebar-primary text-sidebar-primary-foreground" : "text-sidebar-foreground hover:bg-sidebar-accent"}`}><Icon className="size-4 shrink-0" /><span>{label}</span></button>
          ))}
        </nav>
        <Button variant="ghost" className="mt-6 w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground" onClick={signOut}><LogOut className="size-4" /> Abmelden</Button>
      </aside>

      <main className="min-w-0 p-4 sm:p-7 xl:p-10">
        <header className="mb-7 flex flex-wrap items-end justify-between gap-4">
          <div className="flex items-center gap-3"><Button size="icon" variant="outline" className="lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Menü öffnen"><Menu className="size-5" /></Button><div><p className="mb-1 text-sm font-medium text-primary">Zentrales Lager</p><h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{active}</h1></div></div>
          {active !== "Buchen" && <Button onClick={() => navigate("Buchen")}><PackagePlus className="size-4" /> Ein- oder Ausgang buchen</Button>}
        </header>
        {active === "Übersicht" && <DashboardView refreshKey={refreshKey} />}
        {active === "Buchen" && <BookingView onBooked={changed} />}
        {active === "Ersatzteile" && <PartsView refreshKey={refreshKey} onChanged={changed} />}
        {active === "Schubladen & Geräte" && <StorageView refreshKey={refreshKey} onChanged={changed} />}
        {active === "Aufträge" && <OrdersView refreshKey={refreshKey} onChanged={changed} />}
        {active === "Unterlagen" && <DocumentsView refreshKey={refreshKey} onChanged={changed} />}
        {active === "Einstellungen" && <SettingsView onChanged={changed} />}
      </main>
      <Toaster richColors position="top-right" />
    </div>
  );
}

function Login({ onSuccess }: { onSuccess: () => void }) {
  const [username, setUsername] = useState("admin"); const [password, setPassword] = useState(""); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(event: React.FormEvent) { event.preventDefault(); setBusy(true); setError(""); try { const response = await fetch("/api/v1/auth/login", { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username, password }) }); if (!response.ok) throw new Error(); onSuccess(); } catch { setError("Benutzername oder Passwort ist nicht korrekt."); } finally { setBusy(false); } }
  return <main className="grid min-h-screen place-items-center bg-login px-5 py-12"><Card className="w-full max-w-md border-white/10 bg-card/95 shadow-2xl backdrop-blur"><CardHeader className="space-y-4"><div className="grid size-12 place-items-center rounded-xl bg-primary text-primary-foreground"><Warehouse className="size-6" /></div><div><CardTitle className="text-2xl">Gaslager anmelden</CardTitle><p className="mt-2 text-sm text-muted-foreground">Zugriff auf Bestand, Barcodes und Schubladen.</p></div></CardHeader><CardContent><form onSubmit={submit} className="space-y-4"><div className="space-y-2"><Label htmlFor="username">Benutzername</Label><Input id="username" value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" /></div><div className="space-y-2"><Label htmlFor="password">Passwort</Label><Input id="password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" autoFocus /></div>{error && <p className="text-sm text-destructive">{error}</p>}<Button className="w-full" type="submit" disabled={busy || !password}>{busy ? "Anmeldung läuft …" : "Anmelden"}</Button></form></CardContent></Card></main>;
}
