"use client";

import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Barcode, Boxes, Plus, Search } from "lucide-react";
import { toast } from "sonner";
import { api, jsonBody } from "./api";
import { BarcodeLabel } from "./barcode-label";
import type { Drawer, Equipment, Part } from "./types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";

export function PartsView({
  refreshKey = 0,
  onChanged,
}: {
  refreshKey?: number;
  onChanged?: () => void;
}) {
  const [parts, setParts] = useState<Part[]>([]);
  const [drawers, setDrawers] = useState<Drawer[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [selected, setSelected] = useState<Part | null>(null);

  async function load() {
    setLoading(true);
    try {
      const [partRows, drawerRows, equipmentRows] = await Promise.all([
        api<Part[]>("/api/v1/parts"),
        api<Drawer[]>("/api/v1/drawers"),
        api<Equipment[]>("/api/v1/equipment"),
      ]);
      setParts(partRows);
      setDrawers(drawerRows);
      setEquipment(equipmentRows);
      if (selected)
        setSelected(partRows.find((part) => part.id === selected.id) ?? null);
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Ersatzteile konnten nicht geladen werden.",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    let active = true;
    Promise.all([
      api<Part[]>("/api/v1/parts"),
      api<Drawer[]>("/api/v1/drawers"),
      api<Equipment[]>("/api/v1/equipment"),
    ])
      .then(([partRows, drawerRows, equipmentRows]) => {
        if (!active) return;
        setParts(partRows);
        setDrawers(drawerRows);
        setEquipment(equipmentRows);
      })
      .catch((reason) => {
        if (active)
          toast.error(
            reason instanceof Error
              ? reason.message
              : "Ersatzteile konnten nicht geladen werden.",
          );
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [refreshKey]);

  const filtered = useMemo(() => {
    const term = search.trim().toLocaleLowerCase("de");
    if (!term) return parts;
    return parts.filter((part) =>
      [
        part.part_name,
        part.manufacturer,
        part.original_article_number,
        ...part.barcodes.map((item) => item.value),
      ].some((value) => value.toLocaleLowerCase("de").includes(term)),
    );
  }, [parts, search]);

  async function changed() {
    await load();
    onChanged?.();
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative w-full max-w-xl">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Bezeichnung, Artikelnummer oder Barcode"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>
        <Button onClick={() => setCreateOpen(true)}>
          <Plus className="size-4" /> Ersatzteil anlegen
        </Button>
      </div>

      <div className="overflow-hidden rounded-xl border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Ersatzteil</TableHead>
              <TableHead>Original Art.-Nr.</TableHead>
              <TableHead>Schublade / Gerät</TableHead>
              <TableHead className="text-right">Bestand</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((part) => (
              <TableRow
                key={part.id}
                className="cursor-pointer"
                onClick={() => setSelected(part)}
              >
                <TableCell>
                  <p className="font-medium">{part.part_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {part.manufacturer} · {part.barcodes.length} Barcode
                    {part.barcodes.length === 1 ? "" : "s"}
                  </p>
                </TableCell>
                <TableCell className="font-mono">
                  {part.original_article_number}
                </TableCell>
                <TableCell>
                  <p>{part.drawer?.code ?? "Nicht zugeordnet"}</p>
                  <p className="text-xs text-muted-foreground">
                    {part.drawer?.equipment_type?.designation ?? "–"}
                  </p>
                </TableCell>
                <TableCell className="text-right font-mono text-lg font-semibold">
                  {part.stock_quantity}{" "}
                  <span className="text-xs font-normal text-muted-foreground">
                    {part.unit}
                  </span>
                </TableCell>
                <TableCell>
                  {part.is_low_stock ? (
                    <Badge
                      className="border-warning/30 bg-warning/10 text-warning"
                      variant="outline"
                    >
                      <AlertTriangle className="size-3" /> Mindestbestand
                    </Badge>
                  ) : (
                    <Badge variant="secondary">Verfügbar</Badge>
                  )}
                </TableCell>
              </TableRow>
            ))}
            {!loading && !filtered.length && (
              <TableRow>
                <TableCell
                  colSpan={5}
                  className="h-36 text-center text-muted-foreground"
                >
                  <Boxes className="mx-auto mb-2 size-6" />
                  Keine passenden Ersatzteile.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <NewPartDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        drawers={drawers}
        equipment={equipment}
        onSaved={changed}
      />
      {selected && (
        <PartDialog
          key={selected.id}
          part={selected}
          onOpenChange={(open) => !open && setSelected(null)}
          drawers={drawers}
          equipment={equipment}
          onSaved={changed}
        />
      )}
    </div>
  );
}

function NewPartDialog({
  open,
  onOpenChange,
  drawers,
  equipment,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (value: boolean) => void;
  drawers: Drawer[];
  equipment: Equipment[];
  onSaved: () => Promise<void>;
}) {
  const initial = {
    manufacturer: "Honeywell / RMG",
    article: "",
    name: "",
    barcode: "",
    symbology: "",
    drawerId: "none",
    stock: "0",
    minimum: "0",
    reminder: true,
    equipmentId: "none",
    deviceNumber: "",
    notes: "",
  };
  const [form, setForm] = useState(initial);
  const [busy, setBusy] = useState(false);

  function update<K extends keyof typeof form>(
    key: K,
    value: (typeof form)[K],
  ) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function save() {
    setBusy(true);
    try {
      await api<Part>("/api/v1/parts", {
        method: "POST",
        ...jsonBody({
          manufacturer: form.manufacturer,
          original_article_number: form.article,
          part_name: form.name,
          unit: "Stück",
          drawer_id: form.drawerId === "none" ? null : form.drawerId,
          initial_stock: Number(form.stock),
          minimum_stock: Number(form.minimum),
          reminder_enabled: form.reminder,
          notes: form.notes,
          barcodes: form.barcode
            ? [
                {
                  value: form.barcode,
                  symbology: form.symbology,
                  is_primary: true,
                },
              ]
            : [],
          compatibilities:
            form.equipmentId !== "none" && form.deviceNumber
              ? [
                  {
                    equipment_type_id: form.equipmentId,
                    device_spare_part_number: form.deviceNumber,
                    notes: "",
                  },
                ]
              : [],
        }),
      });
      toast.success("Ersatzteil wurde angelegt.");
      setForm(initial);
      onOpenChange(false);
      await onSaved();
    } catch (reason) {
      toast.error(
        reason instanceof Error ? reason.message : "Speichern fehlgeschlagen.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Ersatzteil anlegen</DialogTitle>
          <DialogDescription>
            Originalkennzeichnung und Lagerzuordnung gemeinsam erfassen.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Hersteller">
            <Input
              value={form.manufacturer}
              onChange={(event) => update("manufacturer", event.target.value)}
            />
          </Field>
          <Field label="Original-Artikelnummer">
            <Input
              value={form.article}
              onChange={(event) => update("article", event.target.value)}
            />
          </Field>
          <Field label="Bezeichnung" className="sm:col-span-2">
            <Input
              value={form.name}
              onChange={(event) => update("name", event.target.value)}
            />
          </Field>
          <Field label="Barcode">
            <Input
              value={form.barcode}
              onChange={(event) => update("barcode", event.target.value)}
              className="font-mono"
            />
          </Field>
          <Field label="Barcode-Typ">
            <Input
              placeholder="z. B. Code 128"
              value={form.symbology}
              onChange={(event) => update("symbology", event.target.value)}
            />
          </Field>
          <Field label="Schublade">
            <SelectControl
              value={form.drawerId}
              onChange={(value) => {
                const drawer = drawers.find((item) => item.id === value);
                setForm((current) => ({
                  ...current,
                  drawerId: value,
                  equipmentId: drawer?.equipment_type_id ?? current.equipmentId,
                }));
              }}
              placeholder="Nicht zugeordnet"
              items={[
                { value: "none", label: "Nicht zugeordnet" },
                ...drawers.map((item) => ({
                  value: item.id,
                  label: `${item.code} · ${item.equipment_type?.designation ?? ""}`,
                })),
              ]}
            />
          </Field>
          <Field label="Regler / Pilot">
            <SelectControl
              value={form.equipmentId}
              onChange={(value) => update("equipmentId", value)}
              placeholder="Nicht zugeordnet"
              items={[
                { value: "none", label: "Nicht zugeordnet" },
                ...equipment.map((item) => ({
                  value: item.id,
                  label: `${item.designation} · ${item.kind}`,
                })),
              ]}
            />
          </Field>
          <Field label="Ersatzteilnummer am Gerät" className="sm:col-span-2">
            <Input
              value={form.deviceNumber}
              onChange={(event) => update("deviceNumber", event.target.value)}
            />
          </Field>
          <Field label="Anfangsbestand">
            <Input
              type="number"
              min="0"
              value={form.stock}
              onChange={(event) => update("stock", event.target.value)}
            />
          </Field>
          <Field label="Mindestbestand">
            <Input
              type="number"
              min="0"
              value={form.minimum}
              onChange={(event) => update("minimum", event.target.value)}
            />
          </Field>
          <div className="flex items-center justify-between rounded-lg border p-3 sm:col-span-2">
            <Label htmlFor="new-reminder">Erinnerung bei Mindestbestand</Label>
            <Switch
              id="new-reminder"
              checked={form.reminder}
              onCheckedChange={(value) => update("reminder", value)}
            />
          </div>
          <Field label="Notiz" className="sm:col-span-2">
            <Textarea
              value={form.notes}
              onChange={(event) => update("notes", event.target.value)}
            />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Abbrechen
          </Button>
          <Button
            disabled={
              busy ||
              !form.article.trim() ||
              !form.name.trim() ||
              !form.manufacturer.trim()
            }
            onClick={save}
          >
            {busy ? "Speichert …" : "Anlegen"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PartDialog({
  part,
  onOpenChange,
  drawers,
  equipment,
  onSaved,
}: {
  part: Part;
  onOpenChange: (value: boolean) => void;
  drawers: Drawer[];
  equipment: Equipment[];
  onSaved: () => Promise<void>;
}) {
  const [minimum, setMinimum] = useState(String(part.minimum_stock));
  const [drawerId, setDrawerId] = useState(part.drawer_id ?? "none");
  const [reminder, setReminder] = useState(part.reminder_enabled);
  const [barcode, setBarcode] = useState("");
  const [symbology, setSymbology] = useState("");
  const [equipmentId, setEquipmentId] = useState("none");
  const [deviceNumber, setDeviceNumber] = useState("");

  async function saveBase() {
    try {
      await api(`/api/v1/parts/${part.id}`, {
        method: "PATCH",
        ...jsonBody({
          drawer_id: drawerId === "none" ? null : drawerId,
          minimum_stock: Number(minimum),
          reminder_enabled: reminder,
        }),
      });
      toast.success("Ersatzteil wurde aktualisiert.");
      await onSaved();
    } catch (reason) {
      toast.error(
        reason instanceof Error ? reason.message : "Speichern fehlgeschlagen.",
      );
    }
  }

  async function addBarcode() {
    try {
      await api(`/api/v1/parts/${part.id}/barcodes`, {
        method: "POST",
        ...jsonBody({
          value: barcode,
          symbology,
          is_primary: part.barcodes.length === 0,
        }),
      });
      setBarcode("");
      setSymbology("");
      toast.success("Barcode wurde hinzugefügt.");
      await onSaved();
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Barcode konnte nicht gespeichert werden.",
      );
    }
  }

  async function addCompatibility() {
    try {
      await api(`/api/v1/parts/${part.id}/compatibilities`, {
        method: "POST",
        ...jsonBody({
          equipment_type_id: equipmentId,
          device_spare_part_number: deviceNumber,
          notes: "",
        }),
      });
      setEquipmentId("none");
      setDeviceNumber("");
      toast.success("Gerätezuordnung wurde hinzugefügt.");
      await onSaved();
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Zuordnung konnte nicht gespeichert werden.",
      );
    }
  }

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>{part.part_name}</DialogTitle>
          <DialogDescription>
            {part.manufacturer} · Original Art.-Nr.{" "}
            {part.original_article_number}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-5 md:grid-cols-2">
          <section className="space-y-3 rounded-xl border p-4">
            <h3 className="font-semibold">Lagerbestand</h3>
            <p className="font-mono text-4xl font-semibold">
              {part.stock_quantity}{" "}
              <span className="text-base text-muted-foreground">
                {part.unit}
              </span>
            </p>
            <Field label="Schublade">
              <SelectControl
                value={drawerId}
                onChange={setDrawerId}
                items={[
                  { value: "none", label: "Nicht zugeordnet" },
                  ...drawers.map((item) => ({
                    value: item.id,
                    label: `${item.code} · ${item.equipment_type?.designation ?? ""}`,
                  })),
                ]}
              />
            </Field>
            <Field label="Mindestbestand">
              <Input
                type="number"
                min="0"
                value={minimum}
                onChange={(event) => setMinimum(event.target.value)}
              />
            </Field>
            <div className="flex items-center justify-between">
              <Label>Erinnerung</Label>
              <Switch checked={reminder} onCheckedChange={setReminder} />
            </div>
            <Button className="w-full" onClick={saveBase}>
              Änderungen speichern
            </Button>
          </section>
          <section className="space-y-3 rounded-xl border p-4">
            <h3 className="flex items-center gap-2 font-semibold">
              <Barcode className="size-4" /> Barcodes
            </h3>
            {part.barcodes.map((item) => (
              <div key={item.id} className="rounded-lg bg-muted p-3">
                <p className="break-all font-mono text-sm">{item.value}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {item.is_primary ? "Hauptbarcode" : "Weiterer Barcode"}
                  {item.symbology ? ` · ${item.symbology}` : ""}
                </p>
                <BarcodeLabel barcode={item} part={part} />
              </div>
            ))}
            <Input
              placeholder="Neuen Barcode eingeben"
              className="font-mono"
              value={barcode}
              onChange={(event) => setBarcode(event.target.value)}
            />
            <Input
              placeholder="Barcode-Typ"
              value={symbology}
              onChange={(event) => setSymbology(event.target.value)}
            />
            <Button
              variant="outline"
              className="w-full"
              disabled={!barcode.trim()}
              onClick={addBarcode}
            >
              <Plus className="size-4" /> Barcode hinzufügen
            </Button>
          </section>
          <section className="space-y-3 rounded-xl border p-4 md:col-span-2">
            <h3 className="font-semibold">Regler- / Pilotzuordnung</h3>
            <div className="grid gap-2 sm:grid-cols-2">
              {part.compatibilities.map((item) => (
                <div key={item.id} className="rounded-lg bg-muted p-3">
                  <p className="font-medium">
                    {item.equipment_type?.designation ?? "Gerät"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Ersatzteil-Nr. {item.device_spare_part_number}
                  </p>
                </div>
              ))}
            </div>
            <div className="grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
              <SelectControl
                value={equipmentId}
                onChange={setEquipmentId}
                items={[
                  { value: "none", label: "Regler / Pilot wählen" },
                  ...equipment.map((item) => ({
                    value: item.id,
                    label: `${item.designation} · ${item.kind}`,
                  })),
                ]}
              />
              <Input
                placeholder="Ersatzteilnummer am Gerät"
                value={deviceNumber}
                onChange={(event) => setDeviceNumber(event.target.value)}
              />
              <Button
                variant="outline"
                disabled={equipmentId === "none" || !deviceNumber.trim()}
                onClick={addCompatibility}
              >
                <Plus className="size-4" /> Hinzufügen
              </Button>
            </div>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`space-y-2 ${className}`}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function SelectControl({
  value,
  onChange,
  items,
  placeholder = "Bitte wählen",
}: {
  value: string;
  onChange: (value: string) => void;
  items: Array<{ value: string; label: string }>;
  placeholder?: string;
}) {
  return (
    <Select value={value} onValueChange={(next) => next && onChange(next)}>
      <SelectTrigger className="w-full">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {items.map((item) => (
          <SelectItem key={item.value} value={item.value}>
            {item.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
