"use client";

import { useEffect, useRef, useState } from "react";
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  Barcode,
  Camera,
  Search,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { api, jsonBody } from "./api";
import type { Part, WorkOrder } from "./types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

type Detector = {
  detect(
    source: ImageBitmapSource,
  ): Promise<Array<{ rawValue: string; format: string }>>;
};
type DetectorConstructor = new (options?: { formats?: string[] }) => Detector;

export function BookingView({ onBooked }: { onBooked?: () => void }) {
  const [kind, setKind] = useState<"Eingang" | "Ausgang">("Eingang");
  const [barcode, setBarcode] = useState("");
  const [part, setPart] = useState<Part | null>(null);
  const [parts, setParts] = useState<Part[]>([]);
  const [orders, setOrders] = useState<WorkOrder[]>([]);
  const [quantity, setQuantity] = useState("1");
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [orderId, setOrderId] = useState("none");
  const [scannerOpen, setScannerOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    Promise.all([
      api<Part[]>("/api/v1/parts"),
      api<WorkOrder[]>("/api/v1/work-orders?open_only=true"),
    ])
      .then(([partRows, orderRows]) => {
        setParts(partRows);
        setOrders(orderRows);
      })
      .catch((reason) =>
        toast.error(
          reason instanceof Error
            ? reason.message
            : "Stammdaten konnten nicht geladen werden.",
        ),
      );
  }, []);

  async function resolve(value = barcode) {
    if (!value.trim()) return;
    setBusy(true);
    try {
      const result = await api<Part>(
        `/api/v1/barcodes/resolve?value=${encodeURIComponent(value)}`,
      );
      setPart(result);
      setBarcode(value);
      toast.success(`${result.part_name} erkannt.`);
    } catch (reason) {
      setPart(null);
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Barcode ist noch nicht hinterlegt.",
      );
    } finally {
      setBusy(false);
    }
  }

  async function book() {
    if (!part) return;
    setBusy(true);
    try {
      const movement = await api<{ stock_after: number }>("/api/v1/movements", {
        method: "POST",
        ...jsonBody({
          part_id: part.id,
          barcode,
          kind,
          quantity: Number(quantity),
          reference,
          notes,
          work_order_id: orderId === "none" ? null : orderId,
        }),
      });
      toast.success(
        `${kind} gebucht. Neuer Bestand: ${movement.stock_after} ${part.unit}.`,
      );
      setPart(null);
      setBarcode("");
      setQuantity("1");
      setReference("");
      setNotes("");
      onBooked?.();
      setParts(await api<Part[]>("/api/v1/parts"));
    } catch (reason) {
      toast.error(
        reason instanceof Error ? reason.message : "Buchung fehlgeschlagen.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
      <Card>
        <CardHeader>
          <CardTitle>Buchungsart und Barcode</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <Tabs
            value={kind}
            onValueChange={(value) => setKind(value as "Eingang" | "Ausgang")}
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="Eingang">
                <ArrowDownToLine className="size-4" /> Eingang
              </TabsTrigger>
              <TabsTrigger value="Ausgang">
                <ArrowUpFromLine className="size-4" /> Ausgang
              </TabsTrigger>
            </TabsList>
          </Tabs>
          <div className="space-y-2">
            <Label htmlFor="booking-barcode">Original-Barcode</Label>
            <div className="flex gap-2">
              <Input
                id="booking-barcode"
                className="font-mono"
                autoFocus
                placeholder="Scannen oder eingeben"
                value={barcode}
                onChange={(event) => {
                  setBarcode(event.target.value);
                  setPart(null);
                }}
                onKeyDown={(event) => {
                  if (event.key === "Enter") void resolve();
                }}
              />
              <Button
                variant="outline"
                onClick={() => resolve()}
                disabled={busy || !barcode.trim()}
                aria-label="Barcode suchen"
              >
                <Search className="size-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Ein USB-Barcodescanner unter Windows kann direkt in dieses Feld
              scannen.
            </p>
          </div>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => setScannerOpen(true)}
          >
            <Camera className="size-4" /> Kamera verwenden
          </Button>
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-card px-2 text-muted-foreground">
                oder Ersatzteil auswählen
              </span>
            </div>
          </div>
          <Select
            value={part?.id ?? "none"}
            onValueChange={(id) => {
              if (id && id !== "none") {
                const selected = parts.find((item) => item.id === id) ?? null;
                setPart(selected);
                setBarcode(
                  selected?.barcodes.find((item) => item.is_primary)?.value ??
                    "",
                );
              }
            }}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Ersatzteil wählen" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">Bitte wählen</SelectItem>
              {parts.map((item) => (
                <SelectItem key={item.id} value={item.id}>
                  {item.part_name} · {item.original_article_number}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card className={part ? "border-primary/30" : "border-dashed"}>
        <CardHeader>
          <CardTitle>
            {part ? "Buchung bestätigen" : "Noch kein Ersatzteil ausgewählt"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!part ? (
            <div className="flex min-h-80 flex-col items-center justify-center text-center text-muted-foreground">
              <Barcode className="mb-3 size-10 opacity-50" />
              <p>Barcode scannen oder ein Ersatzteil aus der Liste wählen.</p>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="rounded-xl bg-muted p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-xl font-semibold">{part.part_name}</p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {part.manufacturer} · {part.original_article_number}
                    </p>
                  </div>
                  <Badge
                    variant={part.is_low_stock ? "destructive" : "secondary"}
                  >
                    {part.stock_quantity} {part.unit} verfügbar
                  </Badge>
                </div>
                <p className="mt-3 text-sm">
                  Schublade:{" "}
                  <strong>{part.drawer?.code ?? "nicht zugeordnet"}</strong>
                  {part.drawer?.equipment_type
                    ? ` · ${part.drawer.equipment_type.designation}`
                    : ""}
                </p>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Menge</Label>
                  <Input
                    type="number"
                    min="1"
                    max={kind === "Ausgang" ? part.stock_quantity : 99999}
                    value={quantity}
                    onChange={(event) => setQuantity(event.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Auftrag (optional)</Label>
                  <Select
                    value={orderId}
                    onValueChange={(value) => value && setOrderId(value)}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Ohne Auftrag</SelectItem>
                      {orders.map((order) => (
                        <SelectItem key={order.id} value={order.id}>
                          {order.order_number} · {order.customer_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Referenz</Label>
                <Input
                  placeholder="z. B. Lieferschein oder Monteur"
                  value={reference}
                  onChange={(event) => setReference(event.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Notiz</Label>
                <Textarea
                  value={notes}
                  onChange={(event) => setNotes(event.target.value)}
                />
              </div>
              <Button
                className="w-full"
                size="lg"
                disabled={
                  busy ||
                  Number(quantity) < 1 ||
                  (kind === "Ausgang" && Number(quantity) > part.stock_quantity)
                }
                onClick={book}
              >
                {kind === "Eingang" ? (
                  <ArrowDownToLine className="size-5" />
                ) : (
                  <ArrowUpFromLine className="size-5" />
                )}
                {busy ? "Bucht …" : `${kind} verbindlich buchen`}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      <CameraScanner
        open={scannerOpen}
        onOpenChange={setScannerOpen}
        onDetected={(value) => {
          setScannerOpen(false);
          setBarcode(value);
          void resolve(value);
        }}
      />
    </div>
  );
}

function CameraScanner({
  open,
  onOpenChange,
  onDetected,
}: {
  open: boolean;
  onOpenChange: (value: boolean) => void;
  onDetected: (value: string) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [message, setMessage] = useState("Kamera wird gestartet …");

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    let stream: MediaStream | null = null;
    let frame = 0;
    async function start() {
      const DetectorClass = (
        window as unknown as { BarcodeDetector?: DetectorConstructor }
      ).BarcodeDetector;
      if (!window.isSecureContext) {
        setMessage(
          "Kamerazugriff benötigt HTTPS. Unter Windows bitte einen USB-Scanner oder die manuelle Eingabe verwenden.",
        );
        return;
      }
      if (!DetectorClass || !navigator.mediaDevices?.getUserMedia) {
        setMessage(
          "Dieser Browser unterstützt den Kamera-Barcode-Scanner nicht.",
        );
        return;
      }
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: "environment" },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });
        if (cancelled || !videoRef.current) return;
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setMessage("Barcode mittig und scharf vor die Kamera halten.");
        const detector = new DetectorClass({
          formats: [
            "code_128",
            "code_39",
            "ean_13",
            "ean_8",
            "data_matrix",
            "qr_code",
            "itf",
            "upc_a",
            "upc_e",
            "pdf417",
            "aztec",
          ],
        });
        const scan = async () => {
          if (cancelled || !videoRef.current) return;
          try {
            const found = await detector.detect(videoRef.current);
            if (found[0]?.rawValue) {
              onDetected(found[0].rawValue);
              return;
            }
          } catch {
            /* nächstes Bild versuchen */
          }
          frame = requestAnimationFrame(scan);
        };
        frame = requestAnimationFrame(scan);
      } catch {
        setMessage(
          "Kamera konnte nicht geöffnet werden. Bitte Berechtigung prüfen.",
        );
      }
    }
    void start();
    return () => {
      cancelled = true;
      cancelAnimationFrame(frame);
      stream?.getTracks().forEach((track) => track.stop());
    };
  }, [open, onDetected]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Barcode scannen</DialogTitle>
          <DialogDescription>{message}</DialogDescription>
        </DialogHeader>
        <div className="relative aspect-video overflow-hidden rounded-xl bg-slate-950">
          <video
            ref={videoRef}
            className="h-full w-full object-cover"
            muted
            playsInline
          />
          <div className="pointer-events-none absolute inset-[18%] rounded-xl border-2 border-white/80 shadow-[0_0_0_999px_rgb(0_0_0/35%)]" />
        </div>
        <Button variant="outline" onClick={() => onOpenChange(false)}>
          <X className="size-4" /> Schließen
        </Button>
      </DialogContent>
    </Dialog>
  );
}
