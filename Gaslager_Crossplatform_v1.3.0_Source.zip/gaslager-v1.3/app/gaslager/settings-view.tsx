"use client";

import { useEffect, useState } from "react";
import {
  CheckCircle2,
  Download,
  FileSpreadsheet,
  LockKeyhole,
  Server,
  ShieldCheck,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { api, jsonBody } from "./api";
import type { SystemSettings } from "./types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type ImportReport = {
  created_parts: number;
  updated_parts: number;
  created_barcodes: number;
  created_equipment_types: number;
  created_drawers: number;
  errors: string[];
};

type CompatibilityReport = {
  rows_total: number;
  to_create: number;
  already_present: number;
  errors: string[];
  committed: boolean;
};

export function SettingsView({ onChanged }: { onChanged?: () => void }) {
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [passwordBusy, setPasswordBusy] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [report, setReport] = useState<ImportReport | null>(null);
  const [compatibilityFile, setCompatibilityFile] = useState<File | null>(null);
  const [compatibilityReport, setCompatibilityReport] =
    useState<CompatibilityReport | null>(null);
  const [compatibilityBusy, setCompatibilityBusy] = useState(false);
  useEffect(() => {
    api<SystemSettings>("/api/v1/settings")
      .then(setSettings)
      .catch((reason) =>
        toast.error(
          reason instanceof Error
            ? reason.message
            : "Einstellungen konnten nicht geladen werden.",
        ),
      );
  }, []);
  async function importCsv() {
    if (!file) return;
    setBusy(true);
    try {
      const data = new FormData();
      data.set("file", file);
      const result = await api<ImportReport>("/api/v1/catalog/import", {
        method: "POST",
        body: data,
      });
      setReport(result);
      toast.success("CSV-Import wurde abgeschlossen.");
      onChanged?.();
    } catch (reason) {
      toast.error(
        reason instanceof Error ? reason.message : "Import fehlgeschlagen.",
      );
    } finally {
      setBusy(false);
    }
  }
  async function importCompatibilities(commit: boolean) {
    if (!compatibilityFile) return;
    setCompatibilityBusy(true);
    try {
      const data = new FormData();
      data.set("file", compatibilityFile);
      const result = await api<CompatibilityReport>(
        `/api/v1/compatibilities/import?commit=${commit}`,
        { method: "POST", body: data },
      );
      setCompatibilityReport(result);
      if (result.committed) {
        toast.success(`${result.to_create} Zuordnungen übernommen.`);
        onChanged?.();
      } else if (result.errors.length) {
        toast.error("Die Datei enthält Fehler. Es wurde nichts übernommen.");
      } else {
        toast.success("Datei geprüft. Jetzt können Sie die Zuordnungen übernehmen.");
      }
    } catch (reason) {
      toast.error(reason instanceof Error ? reason.message : "Prüfung fehlgeschlagen.");
    } finally {
      setCompatibilityBusy(false);
    }
  }
  async function changePassword() {
    if (newPassword.length < 10) {
      toast.error("Das neue Passwort muss mindestens 10 Zeichen lang sein.");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("Die neuen Passwörter stimmen nicht überein.");
      return;
    }
    setPasswordBusy(true);
    try {
      await api<void>("/api/v1/auth/change-password", {
        method: "POST",
        ...jsonBody({
          current_password: currentPassword,
          new_password: newPassword,
        }),
      });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      toast.success("Passwort wurde geändert.");
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Passwort konnte nicht geändert werden.",
      );
    } finally {
      setPasswordBusy(false);
    }
  }
  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="size-5 text-primary" /> Betriebsart
          </CardTitle>
          <CardDescription>
            Das Lager arbeitet unabhängig von SAP und IH2Go.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Status
            label="Standalone-Betrieb"
            active={settings?.standalone_mode ?? true}
            activeText="Aktiv"
          />
          <Status
            label="SAP-Synchronisierung"
            active={settings?.sap_enabled ?? false}
            activeText="Aktiviert"
            inactiveText="Deaktiviert"
          />
          <Status
            label="IH2Go-Synchronisierung"
            active={settings?.ih2go_enabled ?? false}
            activeText="Aktiviert"
            inactiveText="Deaktiviert"
          />
          <div className="rounded-lg bg-muted p-3 text-sm text-muted-foreground">
            SAP und IH2Go können später über die Server-Konfiguration aktiviert
            werden. Für den normalen Lagerbetrieb sind sie nicht erforderlich.
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheck className="size-5 text-primary" /> Server
          </CardTitle>
          <CardDescription>
            Zentrale Datenquelle für Browser, Android und optional iOS.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between border-b pb-3">
            <span className="text-muted-foreground">Adresse</span>
            <code>
              {typeof window !== "undefined" ? window.location.origin : ""}
            </code>
          </div>
          <div className="flex justify-between border-b pb-3">
            <span className="text-muted-foreground">API-Version</span>
            <span>{settings?.api_version ?? "–"}</span>
          </div>
          <Button asChild variant="outline">
            <a href="/api/docs" target="_blank" rel="noreferrer">
              Technische API-Dokumentation
            </a>
          </Button>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <LockKeyhole className="size-5 text-primary" /> Passwort ändern
          </CardTitle>
          <CardDescription>
            Das bei der Installation erzeugte Administratorpasswort ersetzen.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="current-password">Aktuelles Passwort</Label>
            <Input
              id="current-password"
              type="password"
              autoComplete="current-password"
              value={currentPassword}
              onChange={(event) => setCurrentPassword(event.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="new-password">Neues Passwort</Label>
            <Input
              id="new-password"
              type="password"
              autoComplete="new-password"
              minLength={10}
              value={newPassword}
              onChange={(event) => setNewPassword(event.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirm-password">Neues Passwort bestätigen</Label>
            <Input
              id="confirm-password"
              type="password"
              autoComplete="new-password"
              minLength={10}
              value={confirmPassword}
              onChange={(event) => setConfirmPassword(event.target.value)}
            />
          </div>
          <Button
            onClick={changePassword}
            disabled={
              passwordBusy ||
              !currentPassword ||
              !newPassword ||
              !confirmPassword
            }
          >
            <LockKeyhole className="size-4" />
            {passwordBusy ? "Wird geändert …" : "Passwort speichern"}
          </Button>
        </CardContent>
      </Card>
      <Card className="xl:col-span-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="size-5 text-primary" /> Katalog
            importieren und sichern
          </CardTitle>
          <CardDescription>
            Semikolongetrennte CSV-Dateien im Format der iOS-Vorlage. Vorhandene
            Bestände werden beim Import nicht überschrieben.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6 lg:grid-cols-2">
          <div className="space-y-3">
            <Label htmlFor="catalog-file">CSV-Katalog auswählen</Label>
            <Input
              id="catalog-file"
              type="file"
              accept=".csv,text/csv"
              onChange={(event) => setFile(event.target.files?.[0] ?? null)}
            />
            <Button onClick={importCsv} disabled={!file || busy}>
              <Upload className="size-4" />{" "}
              {busy ? "Importiert …" : "CSV importieren"}
            </Button>
          </div>
          <div className="space-y-3">
            <p className="text-sm font-medium">Vollständige Sicherung</p>
            <p className="text-sm text-muted-foreground">
              Exportiert Barcodes, Original-Artikelnummern, Gerätezuordnungen,
              Schubladen und aktuelle Bestände.
            </p>
            <Button asChild variant="outline">
              <a href="/api/v1/catalog/export" download>
                <Download className="size-4" /> Katalog als CSV exportieren
              </a>
            </Button>
          </div>
          {report && (
            <div className="rounded-xl border bg-muted/40 p-4 lg:col-span-2">
              <p className="mb-3 flex items-center gap-2 font-semibold">
                <CheckCircle2 className="size-4 text-primary" /> Importbericht
              </p>
              <div className="grid gap-2 text-sm sm:grid-cols-5">
                <Result label="Neue Teile" value={report.created_parts} />
                <Result label="Aktualisiert" value={report.updated_parts} />
                <Result label="Neue Barcodes" value={report.created_barcodes} />
                <Result
                  label="Gerätetypen"
                  value={report.created_equipment_types}
                />
                <Result label="Schubladen" value={report.created_drawers} />
              </div>
              {report.errors.length > 0 && (
                <div className="mt-4 rounded-lg border border-destructive/20 bg-destructive/5 p-3 text-sm text-destructive">
                  <p className="font-semibold">Hinweise/Fehler</p>
                  {report.errors.slice(0, 20).map((error) => (
                    <p key={error}>{error}</p>
                  ))}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      <Card className="xl:col-span-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="size-5 text-primary" /> Mehrfachverwendung hochladen
          </CardTitle>
          <CardDescription>
            CSV (Semikolon) oder Excel (.xlsx) mit Original-Artikelnummer,
            Regler/Pilot und Ersatzteilnummer am Gerät. Erst prüfen, dann übernehmen.
            Vorhandene Teile und Gerätetypen müssen bereits im Katalog stehen.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline"><a href="/api/v1/compatibilities/template" download>
              <Download className="size-4" /> CSV-Vorlage
            </a></Button>
            <Button asChild variant="outline"><a href="/api/v1/compatibilities/export" download>
              <Download className="size-4" /> Aktuelle Zuordnungen
            </a></Button>
          </div>
          <div className="max-w-xl space-y-2">
            <Label htmlFor="compatibility-file">Mehrfachverwendungsliste auswählen</Label>
            <Input id="compatibility-file" type="file" accept=".csv,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              onChange={(event) => {
                setCompatibilityFile(event.target.files?.[0] ?? null);
                setCompatibilityReport(null);
              }} />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => importCompatibilities(false)} disabled={!compatibilityFile || compatibilityBusy}>
              <Upload className="size-4" /> {compatibilityBusy ? "Prüft …" : "Datei prüfen"}
            </Button>
            <Button variant="secondary" onClick={() => importCompatibilities(true)}
              disabled={!compatibilityFile || compatibilityBusy || !compatibilityReport ||
                compatibilityReport.committed || compatibilityReport.errors.length > 0 || compatibilityReport.to_create === 0}>
              Import übernehmen
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            Eine PDF-Mehrfachverwendungsliste können Sie unter „Unterlagen“ archivieren.
            Die Zuordnungen daraus müssen für den Import als CSV/Excel vorliegen.
            Artikelnummern in Excel bitte als Text formatieren, damit führende Nullen erhalten bleiben.
          </p>
          {compatibilityReport && <div className="rounded-xl border bg-muted/40 p-4 text-sm space-y-2">
            <p className="font-semibold">{compatibilityReport.committed ? "Import abgeschlossen" : "Prüfbericht"}</p>
            <p>{compatibilityReport.rows_total} Zeilen · {compatibilityReport.to_create} neue Zuordnungen · {compatibilityReport.already_present} bereits vorhanden</p>
            {compatibilityReport.errors.length > 0 && <div className="text-destructive">
              <p className="font-semibold">{compatibilityReport.errors.length} Fehler – keine Speicherung</p>
              {compatibilityReport.errors.slice(0, 30).map((error, index) => <p key={`${index}-${error}`}>{error}</p>)}
              {compatibilityReport.errors.length > 30 && <p>Weitere Fehler vorhanden. Bitte die Datei korrigieren.</p>}
            </div>}
          </div>}
        </CardContent>
      </Card>
    </div>
  );
}

function Status({
  label,
  active,
  activeText,
  inactiveText = "Aus",
}: {
  label: string;
  active: boolean;
  activeText: string;
  inactiveText?: string;
}) {
  return (
    <div className="flex items-center justify-between rounded-lg border p-3">
      <span>{label}</span>
      <Badge variant={active ? "secondary" : "outline"}>
        {active ? activeText : inactiveText}
      </Badge>
    </div>
  );
}
function Result({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg bg-card p-3">
      <p className="text-2xl font-semibold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
