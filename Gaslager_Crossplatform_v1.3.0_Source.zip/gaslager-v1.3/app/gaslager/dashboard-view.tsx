"use client";

import { useEffect, useState } from "react";
import {
  AlertTriangle,
  Boxes,
  ClipboardList,
  PackageCheck,
  RefreshCw,
} from "lucide-react";
import { api } from "./api";
import type { Dashboard } from "./types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export function DashboardView({ refreshKey = 0 }: { refreshKey?: number }) {
  const [data, setData] = useState<Dashboard | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    setError("");
    try {
      setData(await api<Dashboard>("/api/v1/dashboard"));
    } catch (reason) {
      setError(
        reason instanceof Error
          ? reason.message
          : "Dashboard konnte nicht geladen werden.",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    let active = true;
    api<Dashboard>("/api/v1/dashboard")
      .then((result) => {
        if (active) setData(result);
      })
      .catch((reason) => {
        if (active)
          setError(
            reason instanceof Error
              ? reason.message
              : "Dashboard konnte nicht geladen werden.",
          );
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [refreshKey]);

  if (error) {
    return <ErrorCard message={error} retry={load} />;
  }

  return (
    <div className="space-y-6">
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Metric
          title="Ersatzteile"
          value={data?.part_count ?? "–"}
          detail="aktive Artikel"
          icon={Boxes}
          loading={loading}
        />
        <Metric
          title="Gesamtbestand"
          value={data?.stock_total ?? "–"}
          detail="Stück über alle Schubladen"
          icon={PackageCheck}
          loading={loading}
        />
        <Metric
          title="Mindestbestand"
          value={data?.low_stock_count ?? "–"}
          detail="Artikel am oder unter Grenzwert"
          icon={AlertTriangle}
          warning
          loading={loading}
        />
        <Metric
          title="Offene Aufträge"
          value={data?.open_order_count ?? "–"}
          detail={`${data?.movement_count_today ?? 0} Buchungen heute`}
          icon={ClipboardList}
          loading={loading}
        />
      </section>

      <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>Letzte Buchungen</CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={load}
              aria-label="Aktualisieren"
            >
              <RefreshCw className="size-4" />
            </Button>
          </CardHeader>
          <CardContent className="px-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Teil</TableHead>
                  <TableHead>Art</TableHead>
                  <TableHead className="text-right">Menge</TableHead>
                  <TableHead>Zeit</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data?.recent_movements.map((movement) => (
                  <TableRow key={movement.id}>
                    <TableCell>
                      <p className="font-medium">{movement.part_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {movement.article_number}
                      </p>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{movement.kind}</Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono font-semibold">
                      {movement.kind === "Ausgang" ? "−" : "+"}
                      {movement.quantity}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {formatDate(movement.timestamp)}
                    </TableCell>
                  </TableRow>
                ))}
                {!loading && !data?.recent_movements.length && (
                  <TableRow>
                    <TableCell
                      colSpan={4}
                      className="h-28 text-center text-muted-foreground"
                    >
                      Noch keine Buchungen vorhanden.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="border-warning/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="size-5 text-warning" /> Mindestbestand
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {data?.low_stock_parts.map((part) => (
              <div
                key={part.id}
                className="flex items-center justify-between gap-4 rounded-lg border bg-card p-3"
              >
                <div className="min-w-0">
                  <p className="truncate font-medium">{part.part_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {part.drawer?.code ?? "Ohne Schublade"} ·{" "}
                    {part.original_article_number}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="font-mono text-lg font-semibold text-warning">
                    {part.stock_quantity}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    min. {part.minimum_stock}
                  </p>
                </div>
              </div>
            ))}
            {!loading && !data?.low_stock_parts.length && (
              <p className="py-12 text-center text-sm text-muted-foreground">
                Alle Bestände liegen über ihrem Grenzwert.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Metric({
  title,
  value,
  detail,
  icon: Icon,
  warning = false,
  loading = false,
}: {
  title: string;
  value: string | number;
  detail: string;
  icon: typeof Boxes;
  warning?: boolean;
  loading?: boolean;
}) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between text-sm font-medium text-muted-foreground">
          {title}
          <Icon
            className={`size-4 ${warning ? "text-warning" : "text-primary"}`}
          />
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p
          className={`text-3xl font-semibold tracking-tight ${loading ? "animate-pulse text-muted-foreground" : warning && Number(value) > 0 ? "text-warning" : ""}`}
        >
          {value}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">{detail}</p>
      </CardContent>
    </Card>
  );
}

function ErrorCard({ message, retry }: { message: string; retry: () => void }) {
  return (
    <Card>
      <CardContent className="flex min-h-52 flex-col items-center justify-center gap-3 text-center">
        <AlertTriangle className="size-7 text-destructive" />
        <p>{message}</p>
        <Button variant="outline" onClick={retry}>
          Erneut versuchen
        </Button>
      </CardContent>
    </Card>
  );
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("de-DE", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(new Date(value));
}
