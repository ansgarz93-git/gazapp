"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, Printer } from "lucide-react";
import type { Part, PartBarcode } from "./types";
import { Button } from "@/components/ui/button";

type BarcodeOptions = {
  bcid: string;
  text: string;
  scale: number;
  height?: number;
  padding: number;
  includetext?: boolean;
  parsefnc?: boolean;
  backgroundcolor: string;
};

const LINEAR = new Set([
  "code128",
  "code39",
  "code93",
  "ean13",
  "ean8",
  "upca",
  "upce",
  "interleaved2of5",
  "itf14",
  "rationalizedCodabar",
]);

function normalizedType(value: string) {
  return value.toLocaleLowerCase("de").replace(/[\s_./-]+/g, "");
}

function renderOptions(barcode: PartBarcode): BarcodeOptions | null {
  const type = normalizedType(barcode.symbology);
  const direct: Record<string, string> = {
    code128: "code128",
    code39: "code39",
    code93: "code93",
    ean13: "ean13",
    ean8: "ean8",
    upca: "upca",
    upce: "upce",
    itf: "interleaved2of5",
    interleaved2of5: "interleaved2of5",
    itf14: "itf14",
    codabar: "rationalizedCodabar",
    qrcode: "qrcode",
    qr: "qrcode",
    datamatrix: "datamatrix",
    pdf417: "pdf417",
    aztec: "azteccode",
    azteccode: "azteccode",
  };
  const gs1: Record<string, string> = {
    gs1128: "code128",
    ean128: "code128",
    ucc128: "code128",
    gs1datamatrix: "datamatrix",
    gs1qr: "qrcode",
    gs1qrcode: "qrcode",
  };
  const gs1Bcid = gs1[type];
  const bcid = direct[type] ?? gs1Bcid;
  if (!bcid) return null;

  const isLinear = LINEAR.has(bcid);
  const text = gs1Bcid
    ? `^FNC1${barcode.value.replaceAll("\u001d", "^FNC1")}`
    : barcode.value;
  return {
    bcid,
    text,
    scale: isLinear ? 2 : 3,
    ...(isLinear ? { height: 13 } : {}),
    padding: 5,
    includetext: false,
    ...(gs1Bcid ? { parsefnc: true } : {}),
    backgroundcolor: "FFFFFF",
  };
}

function printableRaw(value: string) {
  return value.replaceAll("\u001d", "<GS>");
}

export function BarcodeLabel({
  barcode,
  part,
}: {
  barcode: PartBarcode;
  part: Part;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState("");
  const [ready, setReady] = useState(false);
  const options = useMemo(() => renderOptions(barcode), [barcode]);

  useEffect(() => {
    let active = true;
    if (!options || !canvasRef.current) return;
    setReady(false);
    import("@bwip-js/browser")
      .then(({ default: bwipjs }) => {
        if (!active || !canvasRef.current) return;
        bwipjs.toCanvas(canvasRef.current, options);
        setError("");
        setReady(true);
      })
      .catch((reason: unknown) => {
        if (!active) return;
        setError(
          reason instanceof Error
            ? reason.message
            : "Barcode konnte nicht dargestellt werden.",
        );
      });
    return () => {
      active = false;
    };
  }, [options]);

  function printLabel() {
    const canvas = canvasRef.current;
    if (!canvas || error || !options || !ready) return;
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;
    printWindow.opener = null;
    const document = printWindow.document;
    document.title = `Etikett ${part.original_article_number}`;

    const style = document.createElement("style");
    style.textContent = `
      @page { margin: 5mm; }
      body { margin: 0; color: #000; font-family: Arial, sans-serif; }
      main { box-sizing: border-box; width: 100%; max-width: 95mm; border: 1px solid #000; padding: 4mm; }
      h1 { margin: 0 0 1.5mm; font-size: 13pt; }
      p { margin: 1mm 0; font-size: 9pt; }
      img { display: block; max-width: 100%; max-height: 30mm; margin: 3mm auto; image-rendering: crisp-edges; }
      .raw { overflow-wrap: anywhere; font-family: monospace; font-size: 8pt; text-align: center; }
      .strong { font-weight: 700; }
    `;
    document.head.appendChild(style);

    const main = document.createElement("main");
    const title = document.createElement("h1");
    title.textContent = part.part_name;
    main.appendChild(title);

    const article = document.createElement("p");
    article.className = "strong";
    article.textContent = `${part.manufacturer} · Original Art.-Nr. ${part.original_article_number}`;
    main.appendChild(article);

    const deviceNumbers = part.compatibilities
      .map((item) => item.device_spare_part_number)
      .filter(Boolean)
      .join(" · ");
    if (deviceNumbers) {
      const device = document.createElement("p");
      device.textContent = `Ersatzteil-Nr. am Gerät: ${deviceNumbers}`;
      main.appendChild(device);
    }
    if (part.drawer) {
      const drawer = document.createElement("p");
      drawer.textContent = `Schublade: ${part.drawer.code}${part.drawer.location ? ` · ${part.drawer.location}` : ""}`;
      main.appendChild(drawer);
    }

    const image = document.createElement("img");
    image.alt = `${barcode.symbology} ${printableRaw(barcode.value)}`;
    image.addEventListener("load", () => {
      printWindow.focus();
      printWindow.print();
    });
    image.src = canvas.toDataURL("image/png");
    main.appendChild(image);

    const raw = document.createElement("p");
    raw.className = "raw";
    raw.textContent = `${barcode.symbology}: ${printableRaw(barcode.value)}`;
    main.appendChild(raw);
    document.body.appendChild(main);
  }

  if (!options) {
    return (
      <p className="mt-2 flex items-start gap-2 rounded-md border border-warning/25 bg-warning/5 p-2 text-xs text-warning">
        <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
        Barcode-Typ zuerst bestätigen. Erst danach kann ein prüfbares Etikett
        erzeugt werden.
      </p>
    );
  }

  return (
    <div className="mt-3 rounded-lg border bg-white p-3 text-slate-950">
      <div className="overflow-x-auto text-center">
        <canvas ref={canvasRef} className="mx-auto max-h-28 max-w-full" />
      </div>
      {error ? (
        <p className="mt-2 text-xs text-red-700">{error}</p>
      ) : (
        <Button
          type="button"
          size="sm"
          variant="outline"
          className="mt-3 w-full border-slate-300 bg-white text-slate-950 hover:bg-slate-100"
          disabled={!ready}
          onClick={printLabel}
        >
          <Printer className="size-4" />
          {ready ? "Etikett drucken" : "Barcode wird erzeugt …"}
        </Button>
      )}
    </div>
  );
}
