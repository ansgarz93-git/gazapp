"use client";

import { useEffect, useState } from "react";
import { ClipboardList, Plus, Search, Wrench } from "lucide-react";
import { toast } from "sonner";
import { api, jsonBody } from "./api";
import type { Equipment, Part, WorkOrder } from "./types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";

export function OrdersView({
  refreshKey = 0,
  onChanged,
}: {
  refreshKey?: number;
  onChanged?: () => void;
}) {
  const [orders, setOrders] = useState<WorkOrder[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [query, setQuery] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [selected, setSelected] = useState<WorkOrder | null>(null);
  async function load() {
    try {
      const [orderRows, equipmentRows] = await Promise.all([
        api<WorkOrder[]>(`/api/v1/work-orders?q=${encodeURIComponent(query)}`),
        api<Equipment[]>("/api/v1/equipment"),
      ]);
      setOrders(orderRows);
      setEquipment(equipmentRows);
      if (selected)
        setSelected(orderRows.find((item) => item.id === selected.id) ?? null);
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Aufträge konnten nicht geladen werden.",
      );
    }
  }
  useEffect(() => {
    let active = true;
    Promise.all([
      api<WorkOrder[]>("/api/v1/work-orders"),
      api<Equipment[]>("/api/v1/equipment"),
    ])
      .then(([orderRows, equipmentRows]) => {
        if (!active) return;
        setOrders(orderRows);
        setEquipment(equipmentRows);
      })
      .catch((reason) => {
        if (active)
          toast.error(
            reason instanceof Error
              ? reason.message
              : "Aufträge konnten nicht geladen werden.",
          );
      });
    return () => {
      active = false;
    };
  }, [refreshKey]);
  async function changed() {
    await load();
    onChanged?.();
  }
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative w-full max-w-xl">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Auftragsnummer, Kunde oder Equipment"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            onKeyDown={(event) => event.key === "Enter" && void load()}
          />
        </div>
        <Button onClick={() => setFormOpen(true)}>
          <Plus className="size-4" /> Auftrag anlegen
        </Button>
      </div>
      <div className="overflow-hidden rounded-xl border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Auftrag</TableHead>
              <TableHead>Kunde</TableHead>
              <TableHead>Regler / Pilot</TableHead>
              <TableHead>Termin</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((order) => (
              <TableRow
                key={order.id}
                className="cursor-pointer"
                onClick={() => setSelected(order)}
              >
                <TableCell>
                  <p className="font-mono font-semibold">
                    {order.order_number}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {order.short_text || "Kein Kurztext"}
                  </p>
                </TableCell>
                <TableCell>
                  <p className="font-medium">{order.customer_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {order.customer_number || "Ohne Kundennummer"}
                  </p>
                </TableCell>
                <TableCell>
                  <p>
                    {order.equipment_type?.designation ?? "Nicht hinterlegt"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {order.equipment_number || order.functional_location || "–"}
                  </p>
                </TableCell>
                <TableCell>
                  {order.planned_start ? formatDate(order.planned_start) : "–"}
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      order.status === "Abgeschlossen" ? "secondary" : "outline"
                    }
                  >
                    {order.status}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
            {!orders.length && (
              <TableRow>
                <TableCell
                  colSpan={5}
                  className="h-36 text-center text-muted-foreground"
                >
                  <ClipboardList className="mx-auto mb-2 size-6" />
                  Noch keine Aufträge.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      <NewOrderDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        equipment={equipment}
        onSaved={changed}
      />
      {selected && (
        <OrderDialog
          key={selected.id}
          order={selected}
          equipment={equipment}
          onClose={() => setSelected(null)}
          onSaved={changed}
        />
      )}
    </div>
  );
}

function NewOrderDialog({
  open,
  onOpenChange,
  equipment,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (value: boolean) => void;
  equipment: Equipment[];
  onSaved: () => Promise<void>;
}) {
  const [number, setNumber] = useState("");
  const [customerNumber, setCustomerNumber] = useState("");
  const [customer, setCustomer] = useState("");
  const [equipmentNumber, setEquipmentNumber] = useState("");
  const [functionalLocation, setFunctionalLocation] = useState("");
  const [equipmentId, setEquipmentId] = useState("none");
  const [text, setText] = useState("");
  const [start, setStart] = useState("");
  async function save() {
    try {
      await api("/api/v1/work-orders", {
        method: "POST",
        ...jsonBody({
          order_number: number,
          customer_number: customerNumber,
          customer_name: customer,
          equipment_number: equipmentNumber,
          functional_location: functionalLocation,
          equipment_type_id: equipmentId === "none" ? null : equipmentId,
          short_text: text,
          status: "Offen",
          planned_start: start ? new Date(start).toISOString() : null,
          components: [],
        }),
      });
      toast.success("Auftrag wurde angelegt.");
      onOpenChange(false);
      setNumber("");
      setCustomer("");
      await onSaved();
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Auftrag konnte nicht gespeichert werden.",
      );
    }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Auftrag anlegen</DialogTitle>
          <DialogDescription>
            Standalone-Auftrag mit Kunde und eingebautem Regler/Piloten.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Auftragsnummer">
            <Input
              value={number}
              onChange={(event) => setNumber(event.target.value)}
            />
          </Field>
          <Field label="Kundennummer">
            <Input
              value={customerNumber}
              onChange={(event) => setCustomerNumber(event.target.value)}
            />
          </Field>
          <Field label="Kunde" className="sm:col-span-2">
            <Input
              value={customer}
              onChange={(event) => setCustomer(event.target.value)}
            />
          </Field>
          <Field label="Equipmentnummer">
            <Input
              value={equipmentNumber}
              onChange={(event) => setEquipmentNumber(event.target.value)}
            />
          </Field>
          <Field label="Technischer Platz">
            <Input
              value={functionalLocation}
              onChange={(event) => setFunctionalLocation(event.target.value)}
            />
          </Field>
          <Field label="Regler / Pilot" className="sm:col-span-2">
            <Select
              value={equipmentId}
              onValueChange={(value) => value && setEquipmentId(value)}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Nicht hinterlegt</SelectItem>
                {equipment.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.designation} · {item.kind}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Geplanter Beginn">
            <Input
              type="datetime-local"
              value={start}
              onChange={(event) => setStart(event.target.value)}
            />
          </Field>
          <Field label="Kurztext" className="sm:col-span-2">
            <Textarea
              value={text}
              onChange={(event) => setText(event.target.value)}
            />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Abbrechen
          </Button>
          <Button disabled={!number.trim() || !customer.trim()} onClick={save}>
            Anlegen
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function OrderDialog({
  order,
  equipment,
  onClose,
  onSaved,
}: {
  order: WorkOrder;
  equipment: Equipment[];
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const [status, setStatus] = useState(order.status);
  const [equipmentId, setEquipmentId] = useState(
    order.equipment_type_id ?? "none",
  );
  const [parts, setParts] = useState<Part[]>([]);
  useEffect(() => {
    let active = true;
    api<Part[]>(`/api/v1/work-orders/${order.id}/compatible-parts`)
      .then((rows) => {
        if (active) setParts(rows);
      })
      .catch(() => {
        if (active) setParts([]);
      });
    return () => {
      active = false;
    };
  }, [order.id]);
  async function save() {
    try {
      await api(`/api/v1/work-orders/${order.id}`, {
        method: "PATCH",
        ...jsonBody({
          status,
          equipment_type_id: equipmentId === "none" ? null : equipmentId,
        }),
      });
      setParts(
        await api<Part[]>(`/api/v1/work-orders/${order.id}/compatible-parts`),
      );
      toast.success("Auftrag wurde aktualisiert.");
      await onSaved();
    } catch (reason) {
      toast.error(
        reason instanceof Error ? reason.message : "Speichern fehlgeschlagen.",
      );
    }
  }
  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>Auftrag {order.order_number}</DialogTitle>
          <DialogDescription>
            {order.customer_name} · {order.short_text || "ohne Kurztext"}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Status">
            <Select
              value={status}
              onValueChange={(value) => value && setStatus(value)}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[
                  "Offen",
                  "Freigegeben",
                  "In Bearbeitung",
                  "Technisch abgeschlossen",
                  "Abgeschlossen",
                ].map((entry) => (
                  <SelectItem key={entry} value={entry}>
                    {entry}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Regler / Pilot">
            <Select
              value={equipmentId}
              onValueChange={(value) => value && setEquipmentId(value)}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Nicht hinterlegt</SelectItem>
                {equipment.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.designation} · {item.kind}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        </div>
        <Button onClick={save}>Änderungen speichern</Button>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Wrench className="size-4" /> Passende Ersatzteile
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-2 sm:grid-cols-2">
            {parts.map((part) => (
              <div key={part.id} className="rounded-lg border p-3">
                <p className="font-medium">{part.part_name}</p>
                <p className="text-xs text-muted-foreground">
                  {part.original_article_number} · Bestand {part.stock_quantity}
                </p>
              </div>
            ))}
            {!parts.length && (
              <p className="text-sm text-muted-foreground">
                Für den hinterlegten Gerätetyp sind noch keine Ersatzteile
                zugeordnet.
              </p>
            )}
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`space-y-2 ${className}`}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}
function formatDate(value: string) {
  return new Intl.DateTimeFormat("de-DE", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(new Date(value));
}
