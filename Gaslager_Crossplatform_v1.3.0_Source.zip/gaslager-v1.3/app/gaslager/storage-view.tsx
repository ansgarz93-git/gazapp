"use client";

import { useEffect, useMemo, useState } from "react";
import { Pencil, Plus, Search, Warehouse } from "lucide-react";
import { toast } from "sonner";
import { api, jsonBody } from "./api";
import type { Drawer, Equipment } from "./types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

export function StorageView({
  refreshKey = 0,
  onChanged,
}: {
  refreshKey?: number;
  onChanged?: () => void;
}) {
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [drawers, setDrawers] = useState<Drawer[]>([]);
  const [search, setSearch] = useState("");
  const [equipmentForm, setEquipmentForm] = useState<Equipment | "new" | null>(
    null,
  );
  const [drawerForm, setDrawerForm] = useState<Drawer | "new" | null>(null);

  async function load() {
    try {
      const [equipmentRows, drawerRows] = await Promise.all([
        api<Equipment[]>("/api/v1/equipment"),
        api<Drawer[]>("/api/v1/drawers"),
      ]);
      setEquipment(equipmentRows);
      setDrawers(drawerRows);
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Lagerorte konnten nicht geladen werden.",
      );
    }
  }
  useEffect(() => {
    let active = true;
    Promise.all([
      api<Equipment[]>("/api/v1/equipment"),
      api<Drawer[]>("/api/v1/drawers"),
    ])
      .then(([equipmentRows, drawerRows]) => {
        if (active) {
          setEquipment(equipmentRows);
          setDrawers(drawerRows);
        }
      })
      .catch((reason) => {
        if (active)
          toast.error(
            reason instanceof Error
              ? reason.message
              : "Lagerorte konnten nicht geladen werden.",
          );
      });
    return () => {
      active = false;
    };
  }, [refreshKey]);
  const visibleEquipment = useMemo(() => {
    const term = search.toLowerCase().trim();
    return term
      ? equipment.filter((item) =>
          `${item.designation} ${item.series} ${item.kind}`
            .toLowerCase()
            .includes(term),
        )
      : equipment;
  }, [equipment, search]);
  async function changed() {
    await load();
    onChanged?.();
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative w-full max-w-xl">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Regler, Pilot oder Baureihe suchen"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setEquipmentForm("new")}>
            <Plus className="size-4" /> Gerätetyp
          </Button>
          <Button onClick={() => setDrawerForm("new")}>
            <Plus className="size-4" /> Schublade
          </Button>
        </div>
      </div>
      <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Regler und Piloten{" "}
              <Badge variant="secondary">{equipment.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="grid max-h-[65vh] gap-2 overflow-y-auto pr-2 sm:grid-cols-2">
            {visibleEquipment.map((item) => (
              <button
                key={item.id}
                onClick={() => setEquipmentForm(item)}
                className="rounded-xl border bg-card p-4 text-left transition hover:border-primary/50 hover:bg-accent/30"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold">{item.designation}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {item.series || "Keine Baureihe"}
                    </p>
                  </div>
                  <Badge
                    variant={item.kind === "Pilot" ? "outline" : "secondary"}
                  >
                    {item.kind}
                  </Badge>
                </div>
                <p className="mt-3 line-clamp-2 text-xs text-muted-foreground">
                  {item.status}
                </p>
              </button>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Schubladen <Badge variant="secondary">{drawers.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {drawers.map((drawer) => (
              <button
                key={drawer.id}
                onClick={() => setDrawerForm(drawer)}
                className="flex w-full items-center gap-3 rounded-xl border p-3 text-left transition hover:border-primary/50"
              >
                <div className="grid size-10 place-items-center rounded-lg bg-muted">
                  <Warehouse className="size-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">{drawer.code}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {drawer.equipment_type?.designation ??
                      "Gerät nicht gefunden"}
                    {drawer.location ? ` · ${drawer.location}` : ""}
                  </p>
                </div>
                <Pencil className="size-4 text-muted-foreground" />
              </button>
            ))}
            {!drawers.length && (
              <p className="py-14 text-center text-sm text-muted-foreground">
                Noch keine Schublade angelegt.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
      {equipmentForm && (
        <EquipmentDialog
          key={equipmentForm === "new" ? "new" : equipmentForm.id}
          item={equipmentForm}
          onClose={() => setEquipmentForm(null)}
          onSaved={changed}
        />
      )}
      {drawerForm && (
        <DrawerDialog
          key={drawerForm === "new" ? "new" : drawerForm.id}
          item={drawerForm}
          equipment={equipment}
          onClose={() => setDrawerForm(null)}
          onSaved={changed}
        />
      )}
    </div>
  );
}

function EquipmentDialog({
  item,
  onClose,
  onSaved,
}: {
  item: Equipment | "new";
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const existing = item === "new" ? null : item;
  const [manufacturer, setManufacturer] = useState(
    existing?.manufacturer ?? "Honeywell / RMG",
  );
  const [designation, setDesignation] = useState(existing?.designation ?? "");
  const [kind, setKind] = useState(existing?.kind ?? "Gasdruckregler");
  const [series, setSeries] = useState(existing?.series ?? "");
  const [status, setStatus] = useState(existing?.status ?? "Aktuell");
  const [notes, setNotes] = useState(existing?.notes ?? "");
  async function save() {
    try {
      await api(
        item === "new" ? "/api/v1/equipment" : `/api/v1/equipment/${item.id}`,
        {
          method: item === "new" ? "POST" : "PATCH",
          ...jsonBody({
            manufacturer,
            designation,
            kind,
            series,
            status,
            notes,
          }),
        },
      );
      toast.success("Gerätetyp wurde gespeichert.");
      onClose();
      await onSaved();
    } catch (reason) {
      toast.error(
        reason instanceof Error ? reason.message : "Speichern fehlgeschlagen.",
      );
    }
  }
  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {item === "new" ? "Gerätetyp anlegen" : "Gerätetyp bearbeiten"}
          </DialogTitle>
          <DialogDescription>
            Regler und Piloten bilden die feste Zuordnung für Schubladen und
            Ersatzteillisten.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Hersteller">
            <Input
              value={manufacturer}
              onChange={(event) => setManufacturer(event.target.value)}
            />
          </Field>
          <Field label="Bezeichnung">
            <Input
              value={designation}
              onChange={(event) => setDesignation(event.target.value)}
            />
          </Field>
          <Field label="Kategorie">
            <Select
              value={kind}
              onValueChange={(value) => value && setKind(value as Equipment["kind"])}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Gasdruckregler">Gasdruckregler</SelectItem>
                <SelectItem value="Pilot">Pilot</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Baureihe / Druckstufe">
            <Input
              value={series}
              onChange={(event) => setSeries(event.target.value)}
            />
          </Field>
          <Field label="Portfolio-Status" className="sm:col-span-2">
            <Input
              value={status}
              onChange={(event) => setStatus(event.target.value)}
            />
          </Field>
          <Field label="Notiz" className="sm:col-span-2">
            <Textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
            />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Abbrechen
          </Button>
          <Button
            onClick={save}
            disabled={!manufacturer.trim() || !designation.trim()}
          >
            Speichern
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function DrawerDialog({
  item,
  equipment,
  onClose,
  onSaved,
}: {
  item: Drawer | "new";
  equipment: Equipment[];
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const existing = item === "new" ? null : item;
  const [code, setCode] = useState(existing?.code ?? "");
  const [location, setLocation] = useState(existing?.location ?? "");
  const [equipmentId, setEquipmentId] = useState(
    existing?.equipment_type_id ?? equipment[0]?.id ?? "",
  );
  const [notes, setNotes] = useState(existing?.notes ?? "");
  async function save() {
    try {
      await api(
        item === "new" ? "/api/v1/drawers" : `/api/v1/drawers/${item.id}`,
        {
          method: item === "new" ? "POST" : "PATCH",
          ...jsonBody({
            code,
            location,
            equipment_type_id: equipmentId,
            notes,
          }),
        },
      );
      toast.success("Schublade wurde gespeichert.");
      onClose();
      await onSaved();
    } catch (reason) {
      toast.error(
        reason instanceof Error ? reason.message : "Speichern fehlgeschlagen.",
      );
    }
  }
  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {item === "new" ? "Schublade anlegen" : "Schublade bearbeiten"}
          </DialogTitle>
          <DialogDescription>
            Jede Schublade ist genau einem Regler- oder Pilottyp zugeordnet.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Field label="Schubladenkennung">
            <Input
              placeholder="z. B. R-402-01"
              value={code}
              onChange={(event) => setCode(event.target.value)}
            />
          </Field>
          <Field label="Raum / Schrank / Regal">
            <Input
              value={location}
              onChange={(event) => setLocation(event.target.value)}
            />
          </Field>
          <Field label="Regler / Pilot">
            <Select
              value={equipmentId}
              onValueChange={(value) => value && setEquipmentId(value)}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Gerätetyp wählen" />
              </SelectTrigger>
              <SelectContent>
                {equipment.map((entry) => (
                  <SelectItem key={entry.id} value={entry.id}>
                    {entry.designation} · {entry.kind}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Notiz">
            <Textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
            />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Abbrechen
          </Button>
          <Button onClick={save} disabled={!code.trim() || !equipmentId}>
            Speichern
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`space-y-2 ${className}`}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}
