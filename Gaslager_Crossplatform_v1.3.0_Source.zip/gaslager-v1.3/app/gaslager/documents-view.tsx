"use client";

import { useEffect, useState } from "react";
import {
  BookOpenText,
  ExternalLink,
  FileText,
  Link2,
  Plus,
  Trash2,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { api, jsonBody } from "./api";
import type { Equipment, TechnicalDocument } from "./types";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function DocumentsView({
  refreshKey = 0,
  onChanged,
}: {
  refreshKey?: number;
  onChanged?: () => void;
}) {
  const [documents, setDocuments] = useState<TechnicalDocument[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [remove, setRemove] = useState<TechnicalDocument | null>(null);
  async function load() {
    try {
      const [docs, types] = await Promise.all([
        api<TechnicalDocument[]>("/api/v1/documents"),
        api<Equipment[]>("/api/v1/equipment"),
      ]);
      setDocuments(docs);
      setEquipment(types);
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Unterlagen konnten nicht geladen werden.",
      );
    }
  }
  useEffect(() => {
    let active = true;
    Promise.all([
      api<TechnicalDocument[]>("/api/v1/documents"),
      api<Equipment[]>("/api/v1/equipment"),
    ])
      .then(([docs, types]) => {
        if (active) {
          setDocuments(docs);
          setEquipment(types);
        }
      })
      .catch((reason) => {
        if (active)
          toast.error(
            reason instanceof Error
              ? reason.message
              : "Unterlagen konnten nicht geladen werden.",
          );
      });
    return () => {
      active = false;
    };
  }, [refreshKey]);
  async function changed() {
    await load();
    onChanged?.();
  }
  async function confirmDelete() {
    if (!remove) return;
    try {
      await api(`/api/v1/documents/${remove.id}`, { method: "DELETE" });
      toast.success("Unterlage wurde entfernt.");
      setRemove(null);
      await changed();
    } catch (reason) {
      toast.error(
        reason instanceof Error ? reason.message : "Löschen fehlgeschlagen.",
      );
    }
  }
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Handbücher, Broschüren und PDF-Mehrfachverwendungslisten je Regler oder Pilot hochladen.
        </p>
        <Button onClick={() => setDialogOpen(true)}>
          <Plus className="size-4" /> Unterlage hinzufügen
        </Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {documents.map((document) => (
          <Card key={document.id}>
            <CardHeader>
              <div className="flex items-start justify-between gap-3">
                <div className="grid size-10 place-items-center rounded-lg bg-muted">
                  {document.download_url ? (
                    <FileText className="size-5 text-primary" />
                  ) : (
                    <Link2 className="size-5 text-primary" />
                  )}
                </div>
                {document.is_official_manufacturer_source && (
                  <Badge variant="secondary">Herstellerquelle</Badge>
                )}
              </div>
              <CardTitle className="pt-3 text-lg">{document.title}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">
                {document.equipment_type?.designation ?? "Alle Regler / Piloten"} ·{" "}
                {document.kind}
              </p>
              <div className="flex gap-2">
                {document.download_url && (
                  <Button asChild size="sm">
                    <a
                      href={document.download_url}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <BookOpenText className="size-4" /> PDF öffnen
                    </a>
                  </Button>
                )}
                {document.source_url && (
                  <Button asChild size="sm" variant="outline">
                    <a
                      href={document.source_url}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <ExternalLink className="size-4" /> Quelle
                    </a>
                  </Button>
                )}
                <Button
                  size="icon-sm"
                  variant="ghost"
                  className="ml-auto text-destructive"
                  onClick={() => setRemove(document)}
                  aria-label="Unterlage löschen"
                >
                  <Trash2 className="size-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {!documents.length && (
          <Card className="border-dashed md:col-span-2 xl:col-span-3">
            <CardContent className="flex min-h-60 flex-col items-center justify-center text-center text-muted-foreground">
              <BookOpenText className="mb-3 size-9 opacity-50" />
              <p>Noch keine Herstellerunterlage hinterlegt.</p>
            </CardContent>
          </Card>
        )}
      </div>
      {dialogOpen && (
        <DocumentDialog
          onOpenChange={setDialogOpen}
          equipment={equipment}
          onSaved={changed}
        />
      )}
      <AlertDialog
        open={Boolean(remove)}
        onOpenChange={(open) => !open && setRemove(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Unterlage entfernen?</AlertDialogTitle>
            <AlertDialogDescription>
              Die Zuordnung und eine eventuell hochgeladene PDF-Datei werden
              dauerhaft gelöscht.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function DocumentDialog({
  onOpenChange,
  equipment,
  onSaved,
}: {
  onOpenChange: (value: boolean) => void;
  equipment: Equipment[];
  onSaved: () => Promise<void>;
}) {
  const [mode, setMode] = useState("pdf");
  const [equipmentId, setEquipmentId] = useState("all");
  const [title, setTitle] = useState("");
  const [kind, setKind] = useState("Wartung / Ersatzteilliste");
  const [url, setUrl] = useState("");
  const [official, setOfficial] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      if (mode === "link") {
        await api("/api/v1/documents/link", {
          method: "POST",
          ...jsonBody({
            equipment_type_id: equipmentId === "all" ? null : equipmentId,
            title,
            kind,
            source_url: url,
            is_official_manufacturer_source: official,
          }),
        });
      } else {
        if (!file) throw new Error("Bitte eine PDF-Datei auswählen.");
        const data = new FormData();
        data.set("equipment_type_id", equipmentId === "all" ? "" : equipmentId);
        data.set("title", title);
        data.set("kind", kind);
        data.set("is_official_manufacturer_source", String(official));
        data.set("file", file);
        await api("/api/v1/documents/upload", { method: "POST", body: data });
      }
      toast.success("Unterlage wurde gespeichert.");
      setTitle("");
      setUrl("");
      setFile(null);
      onOpenChange(false);
      await onSaved();
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Unterlage konnte nicht gespeichert werden.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Unterlage hinzufügen</DialogTitle>
          <DialogDescription>
            PDF lokal auf dem Server speichern oder eine offizielle
            Herstellerseite verknüpfen.
          </DialogDescription>
        </DialogHeader>
        <Tabs value={mode} onValueChange={setMode}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="pdf">
              <Upload className="size-4" /> PDF hochladen
            </TabsTrigger>
            <TabsTrigger value="link">
              <Link2 className="size-4" /> Internetlink
            </TabsTrigger>
          </TabsList>
          <div className="mt-5 space-y-4">
            <Field label="Zuordnung">
              <Select
                value={equipmentId}
                onValueChange={(value) => value && setEquipmentId(value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Gerätetyp wählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle Regler / Piloten (allgemeine Unterlage)</SelectItem>
                  {equipment.map((item) => (
                    <SelectItem key={item.id} value={item.id}>
                      {item.designation} · {item.kind}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Titel">
              <Input
                value={title}
                onChange={(event) => setTitle(event.target.value)}
              />
            </Field>
            <Field label="Dokumentart">
              <Select
                value={kind}
                onValueChange={(value) => value && setKind(value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[
                    "Herstellerseite",
                    "Broschüre",
                    "Betriebsanleitung",
                    "Wartung / Ersatzteilliste",
                    "Mehrfachverwendungsliste (PDF)",
                    "Zeichnung",
                    "Zertifikat",
                    "Sonstiges",
                  ].map((item) => (
                    <SelectItem key={item} value={item}>
                      {item}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <TabsContent value="pdf">
              <Field label="PDF-Datei">
                <Input
                  type="file"
                  accept="application/pdf,.pdf"
                  onChange={(event) => setFile(event.target.files?.[0] ?? null)}
                />
              </Field>
            </TabsContent>
            <TabsContent value="link">
              <Field label="Vollständige Internetadresse">
                <Input
                  type="url"
                  placeholder="https://…"
                  value={url}
                  onChange={(event) => setUrl(event.target.value)}
                />
              </Field>
            </TabsContent>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <Label>Offizielle Herstellerquelle</Label>
              <Switch checked={official} onCheckedChange={setOfficial} />
            </div>
          </div>
        </Tabs>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Abbrechen
          </Button>
          <Button
            disabled={
              busy ||
              !equipmentId ||
              !title.trim() ||
              (mode === "link" ? !url.trim() : !file)
            }
            onClick={save}
          >
            {busy ? "Speichert …" : "Speichern"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
