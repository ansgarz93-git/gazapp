export type Equipment = {
  id: string;
  manufacturer: string;
  designation: string;
  kind: "Gasdruckregler" | "Pilot";
  series: string;
  status: string;
  notes: string;
};

export type Drawer = {
  id: string;
  code: string;
  location: string;
  equipment_type_id: string;
  notes: string;
  equipment_type?: Equipment;
};

export type PartBarcode = {
  id: string;
  value: string;
  symbology: string;
  part_id: string;
  is_primary: boolean;
};

export type Compatibility = {
  id: string;
  equipment_type_id: string;
  device_spare_part_number: string;
  notes: string;
  equipment_type?: Equipment;
};

export type Part = {
  id: string;
  manufacturer: string;
  original_article_number: string;
  part_name: string;
  unit: string;
  drawer_id?: string | null;
  stock_quantity: number;
  minimum_stock: number;
  reminder_enabled: boolean;
  notes: string;
  is_archived: boolean;
  is_low_stock: boolean;
  drawer?: Drawer | null;
  barcodes: PartBarcode[];
  compatibilities: Compatibility[];
  material_mapping?: {
    material_number: string;
    plant: string;
    storage_location: string;
    base_unit: string;
  } | null;
};

export type Movement = {
  id: string;
  part_id: string;
  kind: string;
  quantity: number;
  timestamp: string;
  reference: string;
  notes: string;
  stock_after: number;
  barcode_used: string;
  work_order_id?: string | null;
  part_name: string;
  article_number: string;
  created_by_name: string;
};

export type WorkOrder = {
  id: string;
  order_number: string;
  customer_number: string;
  customer_name: string;
  equipment_number: string;
  functional_location: string;
  equipment_type_id?: string | null;
  short_text: string;
  status: string;
  planned_start?: string | null;
  source_system: string;
  equipment_type?: Equipment | null;
  components: Array<{
    id: string;
    item_number: string;
    part_id?: string | null;
    material_number: string;
    description: string;
    required_quantity: number;
    withdrawn_quantity: number;
  }>;
};

export type TechnicalDocument = {
  id: string;
  equipment_type_id: string | null;
  title: string;
  kind: string;
  source_url: string;
  original_filename: string;
  is_official_manufacturer_source: boolean;
  added_at: string;
  equipment_type?: Equipment;
  download_url: string;
};

export type Dashboard = {
  part_count: number;
  stock_total: number;
  low_stock_count: number;
  open_order_count: number;
  movement_count_today: number;
  recent_movements: Movement[];
  low_stock_parts: Part[];
};

export type SystemSettings = {
  standalone_mode: boolean;
  sap_enabled: boolean;
  ih2go_enabled: boolean;
  api_version: string;
};
