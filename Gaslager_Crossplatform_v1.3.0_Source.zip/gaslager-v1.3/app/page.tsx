import GaslagerApp from "./gaslager-app";

export default function Home() {
  return <GaslagerApp />;
}
