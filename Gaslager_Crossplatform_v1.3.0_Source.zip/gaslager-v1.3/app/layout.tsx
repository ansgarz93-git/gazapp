import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Gaslager – Lagerverwaltung",
  description: "Zentrale Lagerverwaltung für RMG-/Honeywell-Ersatzteile",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de">
      <body className="antialiased">{children}</body>
    </html>
  );
}
