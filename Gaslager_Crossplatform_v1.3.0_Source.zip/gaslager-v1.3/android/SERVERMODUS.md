# Gaslager-Servermodus auf Android

## Zweck

Ein Android-Handy kann gleichzeitig Gaslager-Server, Datenbank, Barcodegerät und WLAN-Hotspot sein. Der komplette Lagerbetrieb bleibt im lokalen Hotspot und benötigt keine Internetverbindung. SAP und IH2Go sind dafür nicht erforderlich.

## Inbetriebnahme

1. APK installieren und Gaslager öffnen.
2. Die Benachrichtigungsberechtigung erlauben, damit der laufende Server sichtbar bleibt.
3. In der Anmeldung **Dieses Handy als Server** antippen.
4. **Hotspot-Einstellungen öffnen** antippen und den persönlichen WLAN-Hotspot aktivieren.
5. Weitere Geräte mit SSID und WLAN-Kennwort dieses Hotspots verbinden.
6. In Gaslager über das Zahnrad die Servereinstellungen öffnen und **Adresse aktualisieren** antippen.
7. Eine angezeigte Adresse im Browser des verbundenen Geräts öffnen.
8. Mit Benutzer `admin` und dem in der App angezeigten sechsstelligen Zugangscode anmelden.

Port `8080` und die IP-Adresse werden nur im lokalen Netz verwendet. Die IP kann sich nach einem Neustart oder Hotspotwechsel ändern. Die App zeigt deshalb keine fest angenommene Standardadresse, sondern die tatsächlich erkannten Adressen.

## Enthaltene Offline-Funktionen

- Ein- und Ausgang per Barcode oder Artikelnummer
- Original-Artikelnummern und mehrere Barcodes je Ersatzteil
- individuelle Mindestbestände mit einzeln aktivierbarer Erinnerung
- lokale Android-Benachrichtigung beim Erreichen des Mindestbestands
- Schubladen je Regler- oder Pilottyp
- Aufträge mit Kunde und zugeordnetem Regler/Piloten
- Freigabeprüfung der Ersatzteile bei Auftragsentnahmen
- RMG-Mehrfachverwendungsliste
- 66 vorbelegte Regler- und Pilottypen
- JSON-Sicherung und Wiederherstellung über die Weboberfläche

Herstellerlinks sind als Katalogverweise vorhanden, können ohne Internet aber nicht geöffnet werden. Bereits separat auf dem Gerät gespeicherte Dokumente bleiben davon unberührt.

## Datensicherung

In der Weboberfläche **Sicherung** öffnen und regelmäßig eine JSON-Sicherung herunterladen. Die Datei enthält Bestände, Barcodes, Schubladen, Aufträge und Regler-/Pilotzuordnungen. Vor einer Deinstallation der App muss eine aktuelle Sicherung auf ein anderes Gerät kopiert werden, da Android beim Deinstallieren die lokale Datenbank löscht.

## Sicherheit und Dauerbetrieb

- Hotspot-Kennwort und sechsstelligen Gaslager-Code nur berechtigten Personen geben.
- Den Zugangscode in den Servereinstellungen bei Bedarf neu erzeugen; bestehende Browseranmeldungen werden dadurch ungültig.
- Die Weboberfläche nur im eigenen Hotspot oder einem vertrauenswürdigen LAN verwenden. Sie nutzt dort bewusst HTTP, weil kein externer Zertifikatsdienst verfügbar ist.
- Die dauerhafte Gaslager-Serverbenachrichtigung nicht beenden.
- Gaslager in den Android-Akkueinstellungen von aggressiver Akkuoptimierung ausnehmen.
- Für Schicht- oder Dauerbetrieb Netzteil verwenden und automatische Hotspot-Abschaltung des Geräteherstellers deaktivieren.

## Fehlerbehebung

- **Keine Adresse sichtbar:** Hotspot einschalten, mindestens ein Gerät verbinden und **Adresse aktualisieren** antippen.
- **Browser erreicht die Seite nicht:** Prüfen, ob beide Geräte wirklich mit demselben Handy-Hotspot verbunden sind. VPN auf dem Client testweise ausschalten.
- **Hotspot schaltet sich ab:** In den Hotspot-Einstellungen die automatische Abschaltung deaktivieren.
- **Server stoppt im Standby:** Akkuoptimierung für Gaslager deaktivieren und die Serverbenachrichtigung geöffnet lassen.
- **Code vergessen:** In den Servereinstellungen einen neuen Zugangscode erzeugen.
