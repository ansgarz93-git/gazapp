# Gaslager Android 1.2

Native Android-App für den zentralen Gaslager-Server oder als eigenständiger Lager- und Webserver auf dem Handy.

## Bauen

- Android Studio mit JDK 17 installieren.
- Android SDK Platform 36 und Build Tools 36.1 installieren.
- Diesen Ordner als Projekt öffnen und Gradle synchronisieren.
- Debug-APK: `gradlew.bat assembleDebug` (Windows) beziehungsweise `./gradlew assembleDebug` (Linux/macOS).

Für produktive Updates muss jede Release-APK mit demselben privaten App-Schlüssel signiert werden. Die Vorlage `signing.properties.example` zeigt die benötigten Angaben. Den produktiven Keystore und seine Kennwörter niemals in Git oder ein öffentlich weitergegebenes Quellpaket aufnehmen.

Die App unterstützt Android 6.0 (API 23) und neuer. Sie verwendet das gebündelte ML-Kit-Modell, sodass der Barcode-Scanner nach der APK-Installation keinen separaten Modelldownload benötigt.

## Handy als Server und Hotspot

Der Servermodus benötigt weder Ubuntu noch SAP/IH2Go noch eine Internetverbindung. Er umfasst eine lokale SQLite-Datenbank, dieselbe Android-Oberfläche und eine responsive Weboberfläche für Windows-/Android-Browser.

1. App öffnen und in der Anmeldung **Dieses Handy als Server** wählen.
2. **Hotspot-Einstellungen öffnen** antippen und den Android-Hotspot einschalten. Mobilfunkdaten dürfen ausgeschaltet bleiben.
3. Windows-PC oder weiteres Mobilgerät mit diesem Hotspot verbinden.
4. In der Gaslager-App die Einstellungen öffnen. Dort stehen die lokale Adresse, Benutzer `admin` und der zufällige sechsstellige Zugangscode.
5. Die angezeigte Adresse, zum Beispiel `http://192.168.43.1:8080`, im Browser des verbundenen Geräts öffnen und anmelden.

Die Adresse kann je nach Hersteller anders lauten und wird deshalb von der App ermittelt. Der Server läuft als sichtbarer Vordergrunddienst weiter. Für zuverlässigen Dauerbetrieb sollte Gaslager von der Akkuoptimierung des Geräts ausgenommen und das Handy mit Strom versorgt werden. Der Hotspot muss vom Benutzer in Android eingeschaltet werden; normale Apps dürfen ihn aus Sicherheitsgründen nicht selbstständig aktivieren.

Alle Lagerfunktionen, der Gerätekatalog mit 66 Regler-/Pilottypen, Barcodes, Schubladen, Aufträge, Mehrfachverwendungen und JSON-Sicherungen funktionieren im Hotspot ohne Internet. Externe Herstellerlinks benötigen weiterhin Internet. Ausführliche Hinweise: [SERVERMODUS.md](SERVERMODUS.md).

## Offline und Synchronisierung

- Nach der ersten erfolgreichen Anmeldung speichert die App Bestand, Barcodes, Schubladen, Regler-/Pilotzuordnungen, Aufträge und Dokumentmetadaten lokal.
- Bekannte Originalbarcodes lassen sich offline scannen. Ein- und Ausgänge werden lokal vorgemerkt und verändern sofort den angezeigten Offline-Bestand.
- Der sichtbare **Sync**-Button überträgt wartende Buchungen und lädt anschließend den aktuellen Serverbestand.
- Eindeutige Buchungskennungen schützen beim erneuten Übertragen vor Doppelbuchungen.
- Zentral abgelegte PDFs bleiben nach dem ersten Öffnen auf dem Gerät verfügbar. Hersteller-Weblinks benötigen weiterhin eine Internetverbindung.
- Neue Ersatzteile und Barcodezuordnungen werden aus Sicherheitsgründen nur online angelegt.

Unter **Teile → Mehrfachverwendung** zeigt die App jedes Ersatzteil, das mindestens zwei freigegebene Regler-/Pilotzuordnungen besitzt, zusammen mit allen gerätespezifischen Ersatzteilnummern. Die Ansicht leitet keine Herstellerdaten ab.

## Ersteinrichtung

1. Android-Gerät mit demselben LAN/VPN wie den Ubuntu-Server verbinden.
2. App öffnen und Benachrichtigungs-/Kameraberechtigung erlauben.
3. Serveradresse aus der Ubuntu-Installation eintragen, zum Beispiel `http://192.168.1.50:8080`.
4. Mit den erzeugten Gaslager-Zugangsdaten anmelden.

Unter **Buchen** kann ein unbekannter Barcode online als neuer Artikel gespeichert oder einem bestehenden Ersatzteil als zusätzlicher Barcode zugeordnet werden.

Im Handy-Servermodus können neue Ersatzteile, Originalbarcodes, Regler-/Pilotzuordnungen, Schubladen und Aufträge zusätzlich über die eingebettete Weboberfläche angelegt werden. Buchungen aus App und Browser landen im selben lokalen Bestand.
