@echo off
setlocal
set "GRADLE_VERSION=9.3.1"
set "PROJECT_DIR=%~dp0"
set "GRADLE_LOCAL_DIR=%USERPROFILE%\.gradle\gaslager-gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_LOCAL_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat"

where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle -p "%PROJECT_DIR%" %*
  exit /b %ERRORLEVEL%
)

if not exist "%GRADLE_EXE%" (
  echo Gradle %GRADLE_VERSION% wird einmalig heruntergeladen ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $d='%GRADLE_LOCAL_DIR%'; New-Item -ItemType Directory -Force -Path $d | Out-Null; $z=Join-Path $d 'gradle.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $z; Expand-Archive -Path $z -DestinationPath $d -Force"
  if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%
)

call "%GRADLE_EXE%" -p "%PROJECT_DIR%" %*
exit /b %ERRORLEVEL%
