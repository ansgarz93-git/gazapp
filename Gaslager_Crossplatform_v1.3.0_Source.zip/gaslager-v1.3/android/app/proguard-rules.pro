# Für die erste intern verteilte Version bleibt Code-Minimierung deaktiviert.
