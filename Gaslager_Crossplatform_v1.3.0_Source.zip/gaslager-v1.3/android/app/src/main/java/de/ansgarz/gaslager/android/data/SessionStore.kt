package de.ansgarz.gaslager.android.data

import android.content.Context

class SessionStore(context: Context) {
    private val preferences = context.getSharedPreferences("gaslager_session", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = preferences.getString("server_url", "") ?: ""
        set(value) = preferences.edit().putString("server_url", value.trimEnd('/')).apply()

    var accessToken: String
        get() = preferences.getString("access_token", "") ?: ""
        set(value) = preferences.edit().putString("access_token", value).apply()

    fun clearToken() {
        preferences.edit().remove("access_token").apply()
    }
}
