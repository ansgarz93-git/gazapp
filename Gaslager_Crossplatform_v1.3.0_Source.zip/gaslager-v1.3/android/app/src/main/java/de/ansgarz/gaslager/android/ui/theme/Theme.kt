package de.ansgarz.gaslager.android.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GaslagerColors = darkColorScheme(
    primary = Color(0xFF66D9D0),
    onPrimary = Color(0xFF00201D),
    primaryContainer = Color(0xFF004F4A),
    onPrimaryContainer = Color(0xFF89F5EB),
    secondary = Color(0xFFFFC857),
    onSecondary = Color(0xFF2A1A00),
    secondaryContainer = Color(0xFF5C4100),
    onSecondaryContainer = Color(0xFFFFDEA1),
    background = Color(0xFF0D151B),
    onBackground = Color(0xFFE1EAF0),
    surface = Color(0xFF121C23),
    onSurface = Color(0xFFE1EAF0),
    surfaceVariant = Color(0xFF27343D),
    onSurfaceVariant = Color(0xFFBBC8D0),
    error = Color(0xFFFFB4AB),
    outline = Color(0xFF85949D),
)

@Composable
fun GaslagerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GaslagerColors,
        content = content,
    )
}
