package de.ansgarz.gaslager.android.data

data class Equipment(
    val id: String,
    val manufacturer: String,
    val designation: String,
    val kind: String,
)

data class Drawer(
    val id: String,
    val code: String,
    val location: String,
    val equipmentTypeId: String,
    val equipment: Equipment?,
)

data class PartBarcode(
    val id: String,
    val value: String,
    val symbology: String,
    val primary: Boolean,
)

data class Compatibility(
    val id: String,
    val equipmentTypeId: String,
    val deviceSparePartNumber: String,
    val equipment: Equipment?,
)

data class Part(
    val id: String,
    val manufacturer: String,
    val originalArticleNumber: String,
    val partName: String,
    val unit: String,
    val stockQuantity: Int,
    val minimumStock: Int,
    val reminderEnabled: Boolean,
    val isLowStock: Boolean,
    val notes: String,
    val drawer: Drawer?,
    val barcodes: List<PartBarcode>,
    val compatibilities: List<Compatibility>,
)

data class Movement(
    val id: String,
    val kind: String,
    val quantity: Int,
    val stockAfter: Int,
    val partName: String,
    val articleNumber: String,
    val timestamp: String,
)

data class WorkOrder(
    val id: String,
    val orderNumber: String,
    val customerName: String,
    val shortText: String,
    val status: String,
    val equipment: Equipment?,
)

data class TechnicalDocument(
    val id: String,
    val title: String,
    val kind: String,
    val sourceUrl: String,
    val downloadUrl: String,
    val equipment: Equipment?,
)

data class Dashboard(
    val partCount: Int,
    val stockTotal: Int,
    val lowStockCount: Int,
    val openOrderCount: Int,
    val movementsToday: Int,
    val recentMovements: List<Movement>,
    val lowStockParts: List<Part>,
)

data class BookingResult(
    val stockAfter: Int,
)
