@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
)

package de.ansgarz.gaslager.android.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddBox
import androidx.compose.material.icons.rounded.Assignment
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RemoveCircle
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import de.ansgarz.gaslager.android.data.Compatibility
import de.ansgarz.gaslager.android.data.Drawer
import de.ansgarz.gaslager.android.data.Equipment
import de.ansgarz.gaslager.android.data.Part
import de.ansgarz.gaslager.android.data.TechnicalDocument
import de.ansgarz.gaslager.android.data.WorkOrder
import de.ansgarz.gaslager.android.scanner.BarcodeCamera
import java.text.DateFormat
import java.util.Date

private enum class MainScreen(val label: String, val icon: ImageVector) {
    Dashboard("Übersicht", Icons.Rounded.Dashboard),
    Booking("Buchen", Icons.Rounded.QrCodeScanner),
    Parts("Teile", Icons.Rounded.Inventory2),
    Orders("Aufträge", Icons.Rounded.Assignment),
    Documents("Unterlagen", Icons.Rounded.Description),
}

@Composable
fun GaslagerApp(viewModel: GaslagerViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var screenName by rememberSaveable { mutableStateOf(MainScreen.Dashboard.name) }
    var cameraOpen by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    LaunchedEffect(state.error, state.message) {
        val notice = state.error.ifBlank { state.message }
        if (state.loggedIn && notice.isNotBlank()) {
            snackbar.showSnackbar(notice)
            viewModel.clearNotice()
        }
    }

    if (cameraOpen) {
        BarcodeCamera(
            onDetected = { value, symbology ->
                cameraOpen = false
                screenName = MainScreen.Booking.name
                viewModel.resolveBarcode(value, symbology)
            },
            onClose = { cameraOpen = false },
        )
        return
    }

    when {
        state.checkingSession -> LoadingScreen("Verbindung wird geprüft …")
        !state.loggedIn -> LoginScreen(
            state = state,
            onLogin = viewModel::login,
            onStartLocalServer = viewModel::startLocalServer,
            onOpenHotspot = viewModel::openHotspotSettings,
        )
        else -> {
            val screen = MainScreen.valueOf(screenName)
            Scaffold(
                snackbarHost = { SnackbarHost(snackbar) },
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("Gaslager", fontWeight = FontWeight.Bold)
                                Text(
                                    "${if (state.localServerModeActive) "Handy-Server" else if (state.isOffline) "Offline" else "Online"} · ${screen.label}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        },
                        actions = {
                            if (state.busy) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                            IconButton(onClick = viewModel::synchronize, enabled = !state.busy) {
                                Icon(
                                    if (state.isOffline) Icons.Rounded.CloudOff else Icons.Rounded.Sync,
                                    contentDescription = "Synchronisieren",
                                )
                            }
                            IconButton(onClick = {
                                viewModel.refreshLocalServerStatus()
                                showSettings = true
                            }) {
                                Icon(Icons.Rounded.Settings, contentDescription = "Einstellungen")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                    )
                },
                bottomBar = {
                    NavigationBar {
                        MainScreen.entries.forEach { item ->
                            NavigationBarItem(
                                selected = screen == item,
                                onClick = { screenName = item.name },
                                icon = { Icon(item.icon, contentDescription = null) },
                                label = { Text(item.label, maxLines = 1) },
                            )
                        }
                    }
                },
            ) { padding ->
                Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.TopCenter) {
                    when (screen) {
                        MainScreen.Dashboard -> DashboardScreen(state, viewModel::synchronize)
                        MainScreen.Booking -> BookingScreen(
                            state = state,
                            onScan = { cameraOpen = true },
                            onResolve = viewModel::resolveBarcode,
                            onClear = viewModel::clearScan,
                            onBook = viewModel::book,
                            onRegister = viewModel::registerPart,
                            onLinkBarcode = viewModel::linkBarcode,
                        )
                        MainScreen.Parts -> PartsScreen(state, viewModel::searchParts, viewModel::synchronize)
                        MainScreen.Orders -> OrdersScreen(state.workOrders)
                        MainScreen.Documents -> DocumentsScreen(state.documents, viewModel::openDocument)
                    }
                }
            }
            if (showSettings) {
                SettingsDialog(
                    state = state,
                    onRefresh = {
                        showSettings = false
                        viewModel.synchronize()
                    },
                    onLogout = {
                        showSettings = false
                        viewModel.logout()
                    },
                    onStartLocalServer = viewModel::startLocalServer,
                    onStopLocalServer = viewModel::stopLocalServer,
                    onOpenHotspot = viewModel::openHotspotSettings,
                    onRefreshServer = viewModel::refreshLocalServerStatus,
                    onRegeneratePassword = viewModel::regenerateLocalServerPassword,
                    onDismiss = { showSettings = false },
                )
            }
        }
    }
}

@Composable
private fun LoadingScreen(label: String) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            CircularProgressIndicator()
            Text(label, modifier = Modifier.padding(top = 18.dp))
        }
    }
}

@Composable
private fun LoginScreen(
    state: GaslagerState,
    onLogin: (String, String, String) -> Unit,
    onStartLocalServer: () -> Unit,
    onOpenHotspot: () -> Unit,
) {
    var server by rememberSaveable(state.serverUrl) {
        mutableStateOf(state.serverUrl.ifBlank { "http://192.168.1.100:8080" })
    }
    var username by rememberSaveable { mutableStateOf("admin") }
    var password by rememberSaveable { mutableStateOf("") }
    val focus = LocalFocusManager.current

    Surface(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Card(modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth()) {
                Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.large) {
                            Icon(Icons.Rounded.Inventory2, null, modifier = Modifier.padding(13.dp).size(32.dp))
                        }
                        Column(modifier = Modifier.padding(start = 14.dp)) {
                            Text("Gaslager", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            Text("RMG / Honeywell Ersatzteile")
                        }
                    }
                    Text("Mit dem Gaslager-Server im Firmennetz verbinden. SAP und IH2Go werden für den Betrieb nicht benötigt.")
                    OutlinedTextField(
                        value = server,
                        onValueChange = { server = it },
                        label = { Text("Serveradresse") },
                        supportingText = { Text("Beispiel: http://192.168.1.100:8080") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("Benutzer") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Passwort") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = {
                            focus.clearFocus()
                            if (server.isNotBlank() && username.isNotBlank() && password.isNotBlank()) onLogin(server, username, password)
                        }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Button(
                        onClick = { onLogin(server, username, password) },
                        enabled = !state.busy && server.isNotBlank() && username.isNotBlank() && password.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (state.busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text("Anmelden", modifier = Modifier.padding(start = if (state.busy) 10.dp else 0.dp))
                    }
                    HorizontalDivider()
                    Text("Dieses Handy als Server", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Startet Bestand, API und Weboberfläche direkt auf dem Android-Gerät. Das funktioniert auch im eigenen Hotspot ohne Internet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(
                        onClick = onStartLocalServer,
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Rounded.Dns, null)
                        Text(
                            if (state.localServerRunning) "Handy-Server verwenden" else "Handy-Server starten",
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                    OutlinedButton(onClick = onOpenHotspot, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.WifiTethering, null)
                        Text("Hotspot-Einstellungen öffnen", modifier = Modifier.padding(start = 8.dp))
                    }
                    if (state.error.isNotBlank()) Text(state.error, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun DashboardScreen(state: GaslagerState, onRefresh: () -> Unit) {
    val dashboard = state.dashboard
    LazyColumn(
        modifier = Modifier.fillMaxSize().widthIn(max = 980.dp),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Lagerstatus", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(
                        if (state.isOffline) "Lokaler Offline-Bestand" else "Mit dem Server synchronisiert",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, "Aktualisieren") }
            }
        }
        item { SyncStatusCard(state, onRefresh) }
        if (dashboard == null) {
            item { CircularProgressIndicator() }
        } else {
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("Ersatzteile", dashboard.partCount.toString(), Icons.Rounded.Inventory2)
                    MetricCard("Gesamtbestand", dashboard.stockTotal.toString(), Icons.Rounded.AddBox)
                    MetricCard("Unter Minimum", dashboard.lowStockCount.toString(), Icons.Rounded.WarningAmber, dashboard.lowStockCount > 0)
                    MetricCard("Offene Aufträge", dashboard.openOrderCount.toString(), Icons.Rounded.Assignment)
                    MetricCard("Buchungen heute", dashboard.movementsToday.toString(), Icons.Rounded.CheckCircle)
                }
            }
            item { SectionTitle("Mindestbestand") }
            if (dashboard.lowStockParts.isEmpty()) {
                item { EmptyCard("Alle aktiv überwachten Bestände liegen über ihrem Minimum.") }
            } else {
                items(dashboard.lowStockParts.take(8), key = { "low-${it.id}" }) { part -> PartCard(part) }
            }
            item { SectionTitle("Letzte Buchungen") }
            if (dashboard.recentMovements.isEmpty()) {
                item { EmptyCard("Noch keine Lagerbewegungen vorhanden.") }
            } else {
                items(dashboard.recentMovements.take(8), key = { it.id }) { movement ->
                    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (movement.kind == "Eingang") Icons.Rounded.AddBox else Icons.Rounded.RemoveCircle,
                                null,
                                tint = if (movement.kind == "Eingang") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                            )
                            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(movement.partName, fontWeight = FontWeight.SemiBold)
                                Text(movement.articleNumber, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${if (movement.kind == "Eingang") "+" else "−"}${movement.quantity}", fontWeight = FontWeight.Bold)
                                Text("Bestand ${movement.stockAfter}", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, icon: ImageVector, warning: Boolean = false) {
    Card(
        modifier = Modifier.width(168.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (warning) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Icon(icon, null, tint = if (warning) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.primary)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun BookingScreen(
    state: GaslagerState,
    onScan: () -> Unit,
    onResolve: (String, String) -> Unit,
    onClear: () -> Unit,
    onBook: (String, Int, String, String, String?) -> Unit,
    onRegister: (String, String, String, String?, String?, String, Int, Int, Boolean) -> Unit,
    onLinkBarcode: (String) -> Unit,
) {
    var barcode by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(state.scannedBarcode) { if (state.scannedBarcode.isNotBlank()) barcode = state.scannedBarcode }
    Column(
        modifier = Modifier.fillMaxSize().widthIn(max = 760.dp).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Barcode buchen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Originaletikett mit der Kamera erfassen oder einen USB-/Bluetooth-Scanner bzw. die manuelle Eingabe verwenden.")
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = barcode,
                onValueChange = { barcode = it },
                label = { Text("Original-Barcode") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onResolve(barcode, "Manuell") }),
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = { onResolve(barcode, "Manuell") }, enabled = barcode.isNotBlank()) {
                Icon(Icons.Rounded.Search, "Suchen")
            }
        }
        Button(onClick = onScan, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.CameraAlt, null)
            Text("Mit Kamera scannen", modifier = Modifier.padding(start = 9.dp))
        }
        if (state.scannedBarcode.isNotBlank()) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                AssistChip(onClick = {}, label = { Text(state.scannedBarcode, maxLines = 1, overflow = TextOverflow.Ellipsis) })
                TextButton(onClick = {
                    barcode = ""
                    onClear()
                }) { Text("Zurücksetzen") }
            }
        }
        when {
            state.busy && state.scannedBarcode.isNotBlank() && state.scannedPart == null && !state.unknownBarcode -> CircularProgressIndicator()
            state.scannedPart != null -> key(state.scannedPart.id) {
                BookingForm(state.scannedPart, state.workOrders, state.isOffline, onBook)
            }
            state.unknownBarcode -> key(state.scannedBarcode) {
                RegistrationForm(state, onRegister, onLinkBarcode)
            }
            else -> EmptyCard("Nach dem Scan erscheinen Ersatzteil, Schublade, Reglerzuordnung und Buchungsmaske hier.")
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun BookingForm(
    part: Part,
    workOrders: List<WorkOrder>,
    isOffline: Boolean,
    onBook: (String, Int, String, String, String?) -> Unit,
) {
    var kind by rememberSaveable { mutableStateOf("Ausgang") }
    var quantityText by rememberSaveable { mutableStateOf("1") }
    var reference by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }
    var selectedOrderId by rememberSaveable { mutableStateOf<String?>(null) }
    var showOrders by remember { mutableStateOf(false) }
    val selectedOrder = workOrders.firstOrNull { it.id == selectedOrderId }
    val quantity = quantityText.toIntOrNull() ?: 0

    Card(modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(part.partName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Art.-Nr. ${part.originalArticleNumber}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(part.drawer?.let { "Schublade ${it.code} · ${it.location}" } ?: "Noch keiner Schublade zugeordnet")
                }
                StockBadge(part)
            }
            if (part.compatibilities.isNotEmpty()) {
                Text(
                    part.compatibilities.joinToString("  ·  ") {
                        "${it.equipment?.designation ?: "Regler/Pilot"}: ${it.deviceSparePartNumber}"
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            HorizontalDivider()
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(selected = kind == "Eingang", onClick = { kind = "Eingang" }, label = { Text("Eingang") }, leadingIcon = { Icon(Icons.Rounded.AddBox, null) })
                FilterChip(selected = kind == "Ausgang", onClick = { kind = "Ausgang" }, label = { Text("Ausgang") }, leadingIcon = { Icon(Icons.Rounded.RemoveCircle, null) })
            }
            OutlinedTextField(
                value = quantityText,
                onValueChange = { quantityText = it.filter(Char::isDigit) },
                label = { Text("Menge") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(onClick = { showOrders = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Assignment, null)
                Text(selectedOrder?.let { "${it.orderNumber} · ${it.customerName}" } ?: "Auftrag wählen (optional)", modifier = Modifier.padding(start = 8.dp))
            }
            OutlinedTextField(value = reference, onValueChange = { reference = it }, label = { Text("Beleg / Referenz (optional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notiz (optional)") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = { onBook(kind, quantity, reference, notes, selectedOrderId) },
                enabled = quantity > 0 && (kind == "Eingang" || part.stockQuantity >= quantity),
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (isOffline) "$kind offline vormerken" else "$kind verbindlich buchen") }
            if (kind == "Ausgang" && quantity > part.stockQuantity) {
                Text("Kein negativer Bestand möglich.", color = MaterialTheme.colorScheme.error)
            }
        }
    }
    if (showOrders) {
        SelectionDialog(
            title = "Auftrag zuordnen",
            options = listOf("" to "Ohne Auftrag") + workOrders.map {
                it.id to "${it.orderNumber} · ${it.customerName}${it.equipment?.let { device -> " · ${device.designation}" } ?: ""}"
            },
            onSelect = {
                selectedOrderId = it.ifBlank { null }
                showOrders = false
            },
            onDismiss = { showOrders = false },
        )
    }
}

@Composable
private fun RegistrationForm(
    state: GaslagerState,
    onRegister: (String, String, String, String?, String?, String, Int, Int, Boolean) -> Unit,
    onLinkBarcode: (String) -> Unit,
) {
    var manufacturer by rememberSaveable { mutableStateOf("Honeywell / RMG") }
    var articleNumber by rememberSaveable { mutableStateOf("") }
    var partName by rememberSaveable { mutableStateOf("") }
    var drawerId by rememberSaveable { mutableStateOf<String?>(null) }
    var equipmentId by rememberSaveable { mutableStateOf<String?>(null) }
    var deviceNumber by rememberSaveable { mutableStateOf("") }
    var stockText by rememberSaveable { mutableStateOf("0") }
    var minimumText by rememberSaveable { mutableStateOf("0") }
    var reminder by rememberSaveable { mutableStateOf(true) }
    var drawerDialog by remember { mutableStateOf(false) }
    var equipmentDialog by remember { mutableStateOf(false) }
    var existingPartDialog by remember { mutableStateOf(false) }
    val drawer = state.drawers.firstOrNull { it.id == drawerId }
    val equipment = state.equipment.firstOrNull { it.id == equipmentId }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Unbekannten Barcode anlegen", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Der gelesene Originalcode wird unverändert gespeichert: ${state.scannedBarcode}")
            OutlinedButton(onClick = { existingPartDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Inventory2, null)
                Text("Vorhandenem Ersatzteil zuordnen", modifier = Modifier.padding(start = 8.dp))
            }
            HorizontalDivider()
            Text("Oder neues Ersatzteil anlegen", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(value = manufacturer, onValueChange = { manufacturer = it }, label = { Text("Hersteller") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = articleNumber, onValueChange = { articleNumber = it }, label = { Text("Original-Artikelnummer") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = partName, onValueChange = { partName = it }, label = { Text("Bezeichnung") }, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { drawerDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Text(drawer?.let { "Schublade ${it.code} · ${it.equipment?.designation.orEmpty()}" } ?: "Schublade wählen (optional)")
            }
            OutlinedButton(onClick = { equipmentDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Text(equipment?.let { "${it.kind}: ${it.designation}" } ?: "Regler / Pilot wählen (optional)")
            }
            if (equipmentId != null) {
                OutlinedTextField(
                    value = deviceNumber,
                    onValueChange = { deviceNumber = it },
                    label = { Text("Ersatzteilnummer des Reglers/Piloten") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = stockText,
                    onValueChange = { stockText = it.filter(Char::isDigit) },
                    label = { Text("Anfangsbestand") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = minimumText,
                    onValueChange = { minimumText = it.filter(Char::isDigit) },
                    label = { Text("Mindestbestand") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Erinnerung aktivieren", fontWeight = FontWeight.SemiBold)
                    Text("Warnung bei Erreichen des Minimums", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = reminder, onCheckedChange = { reminder = it })
            }
            Button(
                onClick = {
                    onRegister(
                        manufacturer,
                        articleNumber,
                        partName,
                        drawerId,
                        equipmentId,
                        deviceNumber,
                        stockText.toIntOrNull() ?: 0,
                        minimumText.toIntOrNull() ?: 0,
                        reminder,
                    )
                },
                enabled = manufacturer.isNotBlank() && articleNumber.isNotBlank() && partName.isNotBlank() && (equipmentId == null || deviceNumber.isNotBlank()),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Ersatzteil samt Barcode speichern") }
        }
    }
    if (drawerDialog) {
        SelectionDialog(
            title = "Schublade wählen",
            options = listOf("" to "Keine Schublade") + state.drawers.map { it.id to "${it.code} · ${it.location} · ${it.equipment?.designation.orEmpty()}" },
            onSelect = { drawerId = it.ifBlank { null }; drawerDialog = false },
            onDismiss = { drawerDialog = false },
        )
    }
    if (equipmentDialog) {
        SelectionDialog(
            title = "Regler oder Pilot wählen",
            options = listOf("" to "Keine Zuordnung") + state.equipment.map { it.id to "${it.kind} · ${it.manufacturer} ${it.designation}" },
            onSelect = { equipmentId = it.ifBlank { null }; equipmentDialog = false },
            onDismiss = { equipmentDialog = false },
        )
    }
    if (existingPartDialog) {
        SelectionDialog(
            title = "Vorhandenes Ersatzteil",
            options = state.parts.map { it.id to "${it.partName} · ${it.originalArticleNumber}" },
            onSelect = {
                existingPartDialog = false
                onLinkBarcode(it)
            },
            onDismiss = { existingPartDialog = false },
        )
    }
}

@Composable
private fun PartsScreen(state: GaslagerState, onSearch: (String) -> Unit, onRefresh: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var multipleUse by rememberSaveable { mutableStateOf(false) }
    val parts = state.parts
    val multipleUseParts = parts.filter { part ->
        part.compatibilities.map(Compatibility::equipmentTypeId).distinct().size > 1
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().widthIn(max = 980.dp),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text(
                if (multipleUse) "RMG-Mehrfachverwendung" else "Ersatzteilbestand",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )
            Text(
                if (multipleUse) {
                    "Ein Originalteil mit allen freigegebenen Zuordnungen zu Reglern und Piloten"
                } else {
                    "Suche nach Artikelnummer, Bezeichnung, Barcode oder Reglernummer"
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = !multipleUse,
                    onClick = { multipleUse = false },
                    label = { Text("Bestand") },
                    leadingIcon = { Icon(Icons.Rounded.Inventory2, null) },
                )
                FilterChip(
                    selected = multipleUse,
                    onClick = { multipleUse = true },
                    label = { Text("Mehrfachverwendung") },
                    leadingIcon = { Icon(Icons.Rounded.Assignment, null) },
                )
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Suchen") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onSearch(query) }),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { if (query.isBlank()) onRefresh() else onSearch(query) }) { Icon(Icons.Rounded.Refresh, "Aktualisieren") }
            }
        }
        if (multipleUse) {
            item {
                OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Die Liste entsteht ausschließlich aus den in Gaslager hinterlegten RMG/Honeywell-Kompatibilitäten. Original-Artikel- und Ersatzteilnummern werden nicht abgeleitet.",
                        modifier = Modifier.padding(15.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (multipleUseParts.isEmpty()) {
                item {
                    EmptyCard("Noch keine freigegebene Mehrfachverwendung vorhanden. Hinterlege bei einem Ersatzteil mindestens zwei Regler-/Pilotzuordnungen oder importiere die offizielle RMG-Liste.")
                }
            }
            items(multipleUseParts, key = { "multiple-${it.id}" }) { part -> MultipleUseCard(part) }
        } else {
            if (parts.isEmpty()) item { EmptyCard("Keine Ersatzteile gefunden.") }
            items(parts, key = { it.id }) { part -> PartCard(part) }
        }
    }
}

@Composable
private fun MultipleUseCard(part: Part) {
    val assignments = part.compatibilities.sortedWith(
        compareBy({ it.equipment?.kind.orEmpty() }, { it.equipment?.designation.orEmpty() }, Compatibility::deviceSparePartNumber)
    )
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(part.partName, fontWeight = FontWeight.Bold)
                    Text(
                        "Original-Art.-Nr. ${part.originalArticleNumber}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                StockBadge(part)
            }
            Text(
                "${assignments.map(Compatibility::equipmentTypeId).distinct().size} Regler/Piloten",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
            )
            assignments.forEachIndexed { index, assignment ->
                if (index > 0) HorizontalDivider()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            assignment.equipment?.let { "${it.kind}: ${it.designation}" } ?: "Regler/Pilot",
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            assignment.equipment?.manufacturer.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        assignment.deviceSparePartNumber,
                        modifier = Modifier.padding(start = 12.dp),
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            Text(
                part.drawer?.let { "Schublade ${it.code} · ${it.location}" } ?: "Keine Schublade zugeordnet",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun PartCard(part: Part) {
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(part.partName, fontWeight = FontWeight.SemiBold)
                    Text("${part.manufacturer} · ${part.originalArticleNumber}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StockBadge(part)
            }
            Text(part.drawer?.let { "Schublade ${it.code} · ${it.location}" } ?: "Keine Schublade", style = MaterialTheme.typography.bodySmall)
            if (part.barcodes.isNotEmpty()) Text("Barcode: ${part.barcodes.first().value}", style = MaterialTheme.typography.bodySmall)
            if (part.compatibilities.isNotEmpty()) {
                Text(
                    part.compatibilities.joinToString(" · ") { "${it.equipment?.designation ?: "Zuordnung"}: ${it.deviceSparePartNumber}" },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun StockBadge(part: Part) {
    val warning = part.reminderEnabled && part.isLowStock
    Surface(
        color = if (warning) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), horizontalAlignment = Alignment.End) {
            Text("${part.stockQuantity} ${part.unit}", fontWeight = FontWeight.Bold)
            Text("Min. ${part.minimumStock}", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun OrdersScreen(orders: List<WorkOrder>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().widthIn(max = 980.dp),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Arbeitsaufträge", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Standalone-Aufträge mit Kunde und hinterlegtem Reglertyp", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (orders.isEmpty()) item { EmptyCard("Keine offenen Aufträge. Neue Aufträge werden in der Weboberfläche angelegt.") }
        items(orders, key = { it.id }) { order ->
            OutlinedCard {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(order.orderNumber, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        AssistChip(onClick = {}, label = { Text(order.status) })
                    }
                    Text(order.customerName, fontWeight = FontWeight.SemiBold)
                    if (order.shortText.isNotBlank()) Text(order.shortText)
                    Text(
                        order.equipment?.let { "${it.kind}: ${it.manufacturer} ${it.designation}" } ?: "Kein Regler/Pilot zugeordnet",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun DocumentsScreen(documents: List<TechnicalDocument>, onOpen: (TechnicalDocument) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().widthIn(max = 980.dp),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Herstellerunterlagen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Offizielle Links und PDF-Unterlagen; geöffnete PDFs bleiben offline verfügbar", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (documents.isEmpty()) item { EmptyCard("Noch keine Unterlagen hinterlegt. PDFs und Herstellerlinks lassen sich in der Weboberfläche ergänzen.") }
        items(documents, key = { it.id }) { document ->
            OutlinedCard(modifier = Modifier.fillMaxWidth().clickable { onOpen(document) }) {
                Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Description, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(32.dp))
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 13.dp)) {
                        Text(document.title, fontWeight = FontWeight.SemiBold)
                        Text(
                            listOfNotNull(document.kind.takeIf(String::isNotBlank), document.equipment?.designation).joinToString(" · "),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text("Öffnen", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun SettingsDialog(
    state: GaslagerState,
    onRefresh: () -> Unit,
    onLogout: () -> Unit,
    onStartLocalServer: () -> Unit,
    onStopLocalServer: () -> Unit,
    onOpenHotspot: () -> Unit,
    onRefreshServer: () -> Unit,
    onRegeneratePassword: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Settings, null) },
        title = { Text("System") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Aktive Verbindung", style = MaterialTheme.typography.labelMedium)
                Text(state.serverUrl)
                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (state.isOffline) Icons.Rounded.CloudOff else Icons.Rounded.CloudDone,
                        null,
                        tint = if (state.isOffline) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        if (state.isOffline) "Offline-Modus aktiv" else "Online",
                        modifier = Modifier.padding(start = 8.dp),
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Text("Ausstehende Buchungen: ${state.pendingSyncCount}")
                Text(
                    state.lastSyncedAt?.let { "Letzte Synchronisierung: ${formatSyncTime(it)}" } ?: "Noch nicht synchronisiert",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text("SAP: deaktiviert · IH2Go: deaktiviert", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Sync, null)
                    Text("Jetzt synchronisieren", modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Logout, null)
                    Text("Abmelden / Server wechseln", modifier = Modifier.padding(start = 8.dp))
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Dns, null, tint = if (state.localServerRunning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                        Text("Android-Server", fontWeight = FontWeight.Bold)
                        Text(
                            if (state.localServerRunning) "Läuft lokal auf Port ${state.localServerPort}" else "Gestoppt",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Switch(
                        checked = state.localServerRunning,
                        onCheckedChange = { enabled -> if (enabled) onStartLocalServer() else onStopLocalServer() },
                    )
                }
                Text(
                    "Benutzer: ${state.localServerUsername} · Zugangscode: ${state.localServerPassword}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                if (state.localServerUrls.isEmpty()) {
                    Text(
                        "Noch keine LAN-Adresse erkannt. Hotspot einschalten und anschließend Adresse aktualisieren.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall,
                    )
                } else {
                    Text("Weboberfläche im Hotspot/LAN:", style = MaterialTheme.typography.labelMedium)
                    state.localServerUrls.forEach { url -> Text(url, color = MaterialTheme.colorScheme.primary) }
                }
                if (state.localServerError.isNotBlank()) {
                    Text(state.localServerError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedButton(onClick = onOpenHotspot, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.WifiTethering, null)
                    Text("Hotspot-Einstellungen", modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(onClick = onRefreshServer, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Refresh, null)
                    Text("Adresse aktualisieren", modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(onClick = onRegeneratePassword, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Key, null)
                    Text("Neuen Zugangscode erstellen", modifier = Modifier.padding(start = 8.dp))
                }
                Text(
                    "Die Weboberfläche ist vollständig in der APK gespeichert. Für Bestand, Buchungen, Barcodes und Sicherungen ist keine Internetverbindung erforderlich.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Schließen") } },
    )
}

@Composable
private fun SyncStatusCard(state: GaslagerState, onSync: () -> Unit) {
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(15.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                if (state.isOffline) Icons.Rounded.CloudOff else Icons.Rounded.CloudDone,
                contentDescription = null,
                tint = if (state.isOffline) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(30.dp),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(if (state.isOffline) "Offline nutzbar" else "Online", fontWeight = FontWeight.SemiBold)
                Text(
                    when {
                        state.pendingSyncCount > 0 -> "${state.pendingSyncCount} Buchung${if (state.pendingSyncCount == 1) "" else "en"} wartet auf Übertragung"
                        state.lastSyncedAt != null -> "Stand: ${formatSyncTime(state.lastSyncedAt)}"
                        else -> "Noch nicht synchronisiert"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            OutlinedButton(onClick = onSync, enabled = !state.busy) {
                Icon(Icons.Rounded.Sync, null)
                Text("Sync", modifier = Modifier.padding(start = 6.dp))
            }
        }
    }
}

private fun formatSyncTime(value: Long): String = DateFormat.getDateTimeInstance(
    DateFormat.SHORT,
    DateFormat.SHORT,
).format(Date(value))

@Composable
private fun SelectionDialog(
    title: String,
    options: List<Pair<String, String>>,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Menu, null) },
        title = { Text(title) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxHeight(0.65f)) {
                items(options, key = { it.first.ifBlank { "none" } }) { option ->
                    Text(
                        option.second,
                        modifier = Modifier.fillMaxWidth().clickable { onSelect(option.first) }.padding(vertical = 13.dp),
                    )
                    HorizontalDivider()
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}

@Composable
private fun SectionTitle(value: String) {
    Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun EmptyCard(message: String) {
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Text(message, modifier = Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
