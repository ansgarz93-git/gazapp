package de.ansgarz.gaslager.android.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class ApiException(message: String, val statusCode: Int) : Exception(message)

class ApiClient(private val session: SessionStore) {
    suspend fun login(serverUrl: String, username: String, password: String): String {
        val normalized = normalizeServer(serverUrl)
        session.serverUrl = normalized
        val result = requestObject(
            path = "/api/v1/auth/login",
            method = "POST",
            body = JSONObject().put("username", username).put("password", password),
            authenticated = false,
        )
        return result.getString("access_token").also { session.accessToken = it }
    }

    suspend fun checkSession() {
        requestObject("/api/v1/auth/me")
    }

    suspend fun dashboard(): Dashboard = parseDashboard(requestObject("/api/v1/dashboard"))

    suspend fun parts(query: String = ""): List<Part> {
        val suffix = if (query.isBlank()) "" else "?q=${encode(query)}"
        return requestArray("/api/v1/parts$suffix").objects().map(::parsePart)
    }

    suspend fun part(id: String): Part = parsePart(requestObject("/api/v1/parts/${encode(id)}"))

    suspend fun resolveBarcode(value: String): Part =
        parsePart(requestObject("/api/v1/barcodes/resolve?value=${encode(value)}"))

    suspend fun equipment(): List<Equipment> =
        requestArray("/api/v1/equipment").objects().map(::parseEquipment)

    suspend fun drawers(): List<Drawer> =
        requestArray("/api/v1/drawers").objects().map(::parseDrawer)

    suspend fun workOrders(): List<WorkOrder> =
        requestArray("/api/v1/work-orders?open_only=true").objects().map(::parseWorkOrder)

    suspend fun documents(): List<TechnicalDocument> =
        requestArray("/api/v1/documents").objects().map(::parseDocument)

    suspend fun download(path: String): ByteArray = withContext(Dispatchers.IO) {
        val connection = URI.create(normalizeServer(session.serverUrl) + path).toURL().openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 10_000
            connection.readTimeout = 30_000
            connection.setRequestProperty("Authorization", "Bearer ${session.accessToken}")
            val status = connection.responseCode
            if (status !in 200..299) {
                val detail = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw ApiException(
                    runCatching { JSONObject(detail).optString("detail") }.getOrNull().orEmpty()
                        .ifBlank { "Dokument konnte nicht geladen werden ($status)." },
                    status,
                )
            }
            connection.inputStream.use { it.readBytes() }
        } finally {
            connection.disconnect()
        }
    }

    suspend fun book(
        partId: String,
        barcode: String,
        kind: String,
        quantity: Int,
        reference: String,
        notes: String,
        workOrderId: String?,
        idempotencyKey: String? = null,
    ): BookingResult {
        val body = JSONObject()
            .put("part_id", partId)
            .put("barcode", barcode)
            .put("kind", kind)
            .put("quantity", quantity)
            .put("reference", reference)
            .put("notes", notes)
            .put("work_order_id", workOrderId ?: JSONObject.NULL)
            .put("idempotency_key", idempotencyKey ?: JSONObject.NULL)
        return BookingResult(requestObject("/api/v1/movements", "POST", body).getInt("stock_after"))
    }

    suspend fun createPart(
        manufacturer: String,
        articleNumber: String,
        partName: String,
        barcode: String,
        symbology: String,
        drawerId: String?,
        equipmentTypeId: String?,
        deviceSparePartNumber: String,
        initialStock: Int,
        minimumStock: Int,
        reminderEnabled: Boolean,
    ): Part {
        val barcodes = JSONArray().put(
            JSONObject().put("value", barcode).put("symbology", symbology).put("is_primary", true)
        )
        val compatibilities = JSONArray()
        if (!equipmentTypeId.isNullOrBlank() && deviceSparePartNumber.isNotBlank()) {
            compatibilities.put(
                JSONObject()
                    .put("equipment_type_id", equipmentTypeId)
                    .put("device_spare_part_number", deviceSparePartNumber)
                    .put("notes", "")
            )
        }
        val body = JSONObject()
            .put("manufacturer", manufacturer)
            .put("original_article_number", articleNumber)
            .put("part_name", partName)
            .put("unit", "Stück")
            .put("drawer_id", drawerId ?: JSONObject.NULL)
            .put("initial_stock", initialStock)
            .put("minimum_stock", minimumStock)
            .put("reminder_enabled", reminderEnabled)
            .put("notes", "")
            .put("barcodes", barcodes)
            .put("compatibilities", compatibilities)
        return parsePart(requestObject("/api/v1/parts", "POST", body))
    }

    suspend fun addBarcode(partId: String, barcode: String, symbology: String) {
        val body = JSONObject()
            .put("value", barcode)
            .put("symbology", symbology)
            .put("is_primary", false)
        requestObject("/api/v1/parts/${encode(partId)}/barcodes", "POST", body)
    }

    private suspend fun requestObject(
        path: String,
        method: String = "GET",
        body: JSONObject? = null,
        authenticated: Boolean = true,
    ): JSONObject = JSONObject(request(path, method, body?.toString(), authenticated))

    private suspend fun requestArray(path: String): JSONArray = JSONArray(request(path, "GET", null, true))

    private suspend fun request(path: String, method: String, body: String?, authenticated: Boolean): String =
        withContext(Dispatchers.IO) {
            val base = normalizeServer(session.serverUrl)
            val connection = URI.create(base + path).toURL().openConnection() as HttpURLConnection
            try {
                connection.requestMethod = method
                connection.connectTimeout = 10_000
                connection.readTimeout = 20_000
                connection.setRequestProperty("Accept", "application/json")
                if (authenticated) {
                    if (session.accessToken.isBlank()) throw ApiException("Anmeldung erforderlich.", 401)
                    connection.setRequestProperty("Authorization", "Bearer ${session.accessToken}")
                }
                if (body != null) {
                    connection.doOutput = true
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    connection.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                }
                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (status !in 200..299) {
                    val detail = runCatching { JSONObject(response).optString("detail") }.getOrNull().orEmpty()
                    throw ApiException(detail.ifBlank { "Serverfehler $status" }, status)
                }
                response
            } finally {
                connection.disconnect()
            }
        }

    private fun normalizeServer(value: String): String {
        val candidate = value.trim().trimEnd('/')
        val uri = runCatching { URI.create(candidate) }.getOrNull()
        if (uri == null || uri.scheme !in setOf("http", "https") || uri.host.isNullOrBlank()) {
            throw ApiException("Serveradresse muss mit http:// oder https:// beginnen.", 0)
        }
        return candidate
    }

    private fun encode(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
}

private fun JSONArray.objects(): List<JSONObject> = buildList {
    for (index in 0 until length()) add(getJSONObject(index))
}

private fun JSONObject.objectOrNull(name: String): JSONObject? =
    if (isNull(name)) null else optJSONObject(name)

private fun parseEquipment(json: JSONObject) = Equipment(
    id = json.getString("id"),
    manufacturer = json.optString("manufacturer"),
    designation = json.optString("designation"),
    kind = json.optString("kind"),
)

private fun parseDrawer(json: JSONObject) = Drawer(
    id = json.getString("id"),
    code = json.optString("code"),
    location = json.optString("location"),
    equipmentTypeId = json.optString("equipment_type_id"),
    equipment = json.objectOrNull("equipment_type")?.let(::parseEquipment),
)

private fun parsePart(json: JSONObject): Part {
    val barcodeJson = json.optJSONArray("barcodes") ?: JSONArray()
    val compatibilityJson = json.optJSONArray("compatibilities") ?: JSONArray()
    return Part(
        id = json.getString("id"),
        manufacturer = json.optString("manufacturer"),
        originalArticleNumber = json.optString("original_article_number"),
        partName = json.optString("part_name"),
        unit = json.optString("unit", "Stück"),
        stockQuantity = json.optInt("stock_quantity"),
        minimumStock = json.optInt("minimum_stock"),
        reminderEnabled = json.optBoolean("reminder_enabled"),
        isLowStock = json.optBoolean("is_low_stock"),
        notes = json.optString("notes"),
        drawer = json.objectOrNull("drawer")?.let(::parseDrawer),
        barcodes = barcodeJson.objects().map {
            PartBarcode(it.getString("id"), it.optString("value"), it.optString("symbology"), it.optBoolean("is_primary"))
        },
        compatibilities = compatibilityJson.objects().map {
            Compatibility(
                id = it.getString("id"),
                equipmentTypeId = it.optString("equipment_type_id"),
                deviceSparePartNumber = it.optString("device_spare_part_number"),
                equipment = it.objectOrNull("equipment_type")?.let(::parseEquipment),
            )
        },
    )
}

private fun parseMovement(json: JSONObject) = Movement(
    id = json.getString("id"),
    kind = json.optString("kind"),
    quantity = json.optInt("quantity"),
    stockAfter = json.optInt("stock_after"),
    partName = json.optString("part_name"),
    articleNumber = json.optString("article_number"),
    timestamp = json.optString("timestamp"),
)

private fun parseWorkOrder(json: JSONObject) = WorkOrder(
    id = json.getString("id"),
    orderNumber = json.optString("order_number"),
    customerName = json.optString("customer_name"),
    shortText = json.optString("short_text"),
    status = json.optString("status"),
    equipment = json.objectOrNull("equipment_type")?.let(::parseEquipment),
)

private fun parseDocument(json: JSONObject) = TechnicalDocument(
    id = json.getString("id"),
    title = json.optString("title"),
    kind = json.optString("kind"),
    sourceUrl = json.optString("source_url"),
    downloadUrl = json.optString("download_url"),
    equipment = json.objectOrNull("equipment_type")?.let(::parseEquipment),
)

private fun parseDashboard(json: JSONObject) = Dashboard(
    partCount = json.optInt("part_count"),
    stockTotal = json.optInt("stock_total"),
    lowStockCount = json.optInt("low_stock_count"),
    openOrderCount = json.optInt("open_order_count"),
    movementsToday = json.optInt("movement_count_today"),
    recentMovements = (json.optJSONArray("recent_movements") ?: JSONArray()).objects().map(::parseMovement),
    lowStockParts = (json.optJSONArray("low_stock_parts") ?: JSONArray()).objects().map(::parsePart),
)
