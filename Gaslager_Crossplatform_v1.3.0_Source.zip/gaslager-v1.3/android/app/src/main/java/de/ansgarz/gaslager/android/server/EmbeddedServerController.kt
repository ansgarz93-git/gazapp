package de.ansgarz.gaslager.android.server

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

object EmbeddedServerController {
    fun start(context: Context) {
        EmbeddedServerSettings(context).enabled = true
        val intent = Intent(context, EmbeddedServerService::class.java).setAction(EmbeddedServerService.ACTION_START)
        ContextCompat.startForegroundService(context, intent)
    }

    fun stop(context: Context) {
        EmbeddedServerSettings(context).enabled = false
        context.startService(
            Intent(context, EmbeddedServerService::class.java).setAction(EmbeddedServerService.ACTION_STOP)
        )
    }

    fun openHotspotSettings(context: Context) {
        val tether = Intent("android.settings.TETHER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(tether) }.getOrElse {
            context.startActivity(
                Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
