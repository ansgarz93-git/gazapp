package de.ansgarz.gaslager.android.server

import android.content.Context
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom

class EmbeddedServerSettings(context: Context) {
    private val preferences = context.getSharedPreferences("embedded_server", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = preferences.getBoolean("enabled", false)
        set(value) = preferences.edit().putBoolean("enabled", value).apply()

    val port: Int
        get() = preferences.getInt("port", DEFAULT_PORT).coerceIn(1024, 65535)

    val username: String
        get() = "admin"

    val password: String
        get() = preferences.getString("password", null) ?: generatePassword().also {
            preferences.edit().putString("password", it).apply()
        }

    val accessToken: String
        get() = preferences.getString("access_token", null) ?: generateToken().also {
            preferences.edit().putString("access_token", it).apply()
        }

    fun regeneratePassword(): String = generatePassword().also {
        preferences.edit()
            .putString("password", it)
            .putString("access_token", generateToken())
            .apply()
    }

    fun localUrls(): List<String> = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { network -> network.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .filter { !it.isLoopbackAddress && !it.isLinkLocalAddress && it.isSiteLocalAddress }
            .map { "http://${it.hostAddress}:$port" }
            .distinct()
            .sortedWith(compareBy<String> { !it.startsWith("http://192.168.") }.thenBy { it })
    }.getOrDefault(emptyList())

    private fun generatePassword(): String = SecureRandom().nextInt(1_000_000).toString().padStart(6, '0')

    private fun generateToken(): String = ByteArray(32).also(SecureRandom()::nextBytes)
        .joinToString("") { "%02x".format(it.toInt() and 0xff) }

    companion object {
        const val DEFAULT_PORT = 8080
    }
}
