package de.ansgarz.gaslager.android.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.UUID

data class OfflineSnapshot(
    val savedAt: Long,
    val dashboard: Dashboard,
    val parts: List<Part>,
    val equipment: List<Equipment>,
    val drawers: List<Drawer>,
    val workOrders: List<WorkOrder>,
    val documents: List<TechnicalDocument>,
)

data class PendingBooking(
    val id: String = UUID.randomUUID().toString(),
    val partId: String,
    val barcode: String,
    val kind: String,
    val quantity: Int,
    val reference: String,
    val notes: String,
    val workOrderId: String?,
    val createdAt: Long = System.currentTimeMillis(),
)

class OfflineStore(context: Context) {
    private val directory = File(context.filesDir, "offline").apply { mkdirs() }
    private val snapshotFile = File(directory, "snapshot.json")
    private val pendingFile = File(directory, "pending-bookings.json")
    val documentDirectory: File = File(context.filesDir, "technical-documents").apply { mkdirs() }

    @Synchronized
    fun loadSnapshot(): OfflineSnapshot? = runCatching {
        if (!snapshotFile.isFile) return null
        decodeOfflineSnapshot(JSONObject(snapshotFile.readText(StandardCharsets.UTF_8)))
    }.getOrNull()

    @Synchronized
    fun saveSnapshot(snapshot: OfflineSnapshot) {
        writeAtomically(snapshotFile, encodeOfflineSnapshot(snapshot).toString())
    }

    @Synchronized
    fun pendingBookings(): List<PendingBooking> = runCatching {
        if (!pendingFile.isFile) return emptyList()
        decodePending(JSONArray(pendingFile.readText(StandardCharsets.UTF_8)))
    }.getOrDefault(emptyList())

    @Synchronized
    fun enqueue(booking: PendingBooking) {
        savePending(pendingBookings() + booking)
    }

    @Synchronized
    fun removePending(id: String) {
        savePending(pendingBookings().filterNot { it.id == id })
    }

    fun documentFile(document: TechnicalDocument): File {
        val safeTitle = document.title.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "Unterlage" }
        return File(documentDirectory, "${document.id}-$safeTitle.pdf")
    }

    private fun savePending(bookings: List<PendingBooking>) {
        writeAtomically(pendingFile, encodePending(bookings).toString())
    }

    private fun writeAtomically(target: File, contents: String) {
        val temporary = File(target.parentFile, "${target.name}.tmp")
        temporary.writeText(contents, StandardCharsets.UTF_8)
        if (!temporary.renameTo(target)) {
            target.writeText(contents, StandardCharsets.UTF_8)
            temporary.delete()
        }
    }
}

internal fun encodeOfflineSnapshot(snapshot: OfflineSnapshot) = JSONObject()
    .put("version", 1)
    .put("saved_at", snapshot.savedAt)
    .put("dashboard", encodeDashboard(snapshot.dashboard))
    .put("parts", snapshot.parts.toJsonArray(::encodePart))
    .put("equipment", snapshot.equipment.toJsonArray(::encodeEquipment))
    .put("drawers", snapshot.drawers.toJsonArray(::encodeDrawer))
    .put("work_orders", snapshot.workOrders.toJsonArray(::encodeWorkOrder))
    .put("documents", snapshot.documents.toJsonArray(::encodeDocument))

internal fun decodeOfflineSnapshot(json: JSONObject) = OfflineSnapshot(
    savedAt = json.optLong("saved_at"),
    dashboard = decodeDashboard(json.getJSONObject("dashboard")),
    parts = json.optJSONArray("parts").objectsOrEmpty().map(::decodePart),
    equipment = json.optJSONArray("equipment").objectsOrEmpty().map(::decodeEquipment),
    drawers = json.optJSONArray("drawers").objectsOrEmpty().map(::decodeDrawer),
    workOrders = json.optJSONArray("work_orders").objectsOrEmpty().map(::decodeWorkOrder),
    documents = json.optJSONArray("documents").objectsOrEmpty().map(::decodeDocument),
)

private fun encodePending(bookings: List<PendingBooking>) = bookings.toJsonArray { booking ->
    JSONObject()
        .put("id", booking.id)
        .put("part_id", booking.partId)
        .put("barcode", booking.barcode)
        .put("kind", booking.kind)
        .put("quantity", booking.quantity)
        .put("reference", booking.reference)
        .put("notes", booking.notes)
        .put("work_order_id", booking.workOrderId ?: JSONObject.NULL)
        .put("created_at", booking.createdAt)
}

private fun decodePending(json: JSONArray): List<PendingBooking> = json.objectsOrEmpty().map {
    PendingBooking(
        id = it.getString("id"),
        partId = it.getString("part_id"),
        barcode = it.optString("barcode"),
        kind = it.getString("kind"),
        quantity = it.getInt("quantity"),
        reference = it.optString("reference"),
        notes = it.optString("notes"),
        workOrderId = it.stringOrNull("work_order_id"),
        createdAt = it.optLong("created_at"),
    )
}

private fun encodeEquipment(value: Equipment) = JSONObject()
    .put("id", value.id)
    .put("manufacturer", value.manufacturer)
    .put("designation", value.designation)
    .put("kind", value.kind)

private fun decodeEquipment(json: JSONObject) = Equipment(
    id = json.getString("id"),
    manufacturer = json.optString("manufacturer"),
    designation = json.optString("designation"),
    kind = json.optString("kind"),
)

private fun encodeDrawer(value: Drawer) = JSONObject()
    .put("id", value.id)
    .put("code", value.code)
    .put("location", value.location)
    .put("equipment_type_id", value.equipmentTypeId)
    .put("equipment", value.equipment?.let(::encodeEquipment) ?: JSONObject.NULL)

private fun decodeDrawer(json: JSONObject) = Drawer(
    id = json.getString("id"),
    code = json.optString("code"),
    location = json.optString("location"),
    equipmentTypeId = json.optString("equipment_type_id"),
    equipment = json.objectOrNull("equipment")?.let(::decodeEquipment),
)

private fun encodePart(value: Part) = JSONObject()
    .put("id", value.id)
    .put("manufacturer", value.manufacturer)
    .put("original_article_number", value.originalArticleNumber)
    .put("part_name", value.partName)
    .put("unit", value.unit)
    .put("stock_quantity", value.stockQuantity)
    .put("minimum_stock", value.minimumStock)
    .put("reminder_enabled", value.reminderEnabled)
    .put("is_low_stock", value.isLowStock)
    .put("notes", value.notes)
    .put("drawer", value.drawer?.let(::encodeDrawer) ?: JSONObject.NULL)
    .put("barcodes", value.barcodes.toJsonArray { barcode ->
        JSONObject()
            .put("id", barcode.id)
            .put("value", barcode.value)
            .put("symbology", barcode.symbology)
            .put("primary", barcode.primary)
    })
    .put("compatibilities", value.compatibilities.toJsonArray { compatibility ->
        JSONObject()
            .put("id", compatibility.id)
            .put("equipment_type_id", compatibility.equipmentTypeId)
            .put("device_spare_part_number", compatibility.deviceSparePartNumber)
            .put("equipment", compatibility.equipment?.let(::encodeEquipment) ?: JSONObject.NULL)
    })

private fun decodePart(json: JSONObject): Part = Part(
    id = json.getString("id"),
    manufacturer = json.optString("manufacturer"),
    originalArticleNumber = json.optString("original_article_number"),
    partName = json.optString("part_name"),
    unit = json.optString("unit", "Stück"),
    stockQuantity = json.optInt("stock_quantity"),
    minimumStock = json.optInt("minimum_stock"),
    reminderEnabled = json.optBoolean("reminder_enabled"),
    isLowStock = json.optBoolean("is_low_stock"),
    notes = json.optString("notes"),
    drawer = json.objectOrNull("drawer")?.let(::decodeDrawer),
    barcodes = json.optJSONArray("barcodes").objectsOrEmpty().map {
        PartBarcode(
            id = it.getString("id"),
            value = it.optString("value"),
            symbology = it.optString("symbology"),
            primary = it.optBoolean("primary"),
        )
    },
    compatibilities = json.optJSONArray("compatibilities").objectsOrEmpty().map {
        Compatibility(
            id = it.getString("id"),
            equipmentTypeId = it.optString("equipment_type_id"),
            deviceSparePartNumber = it.optString("device_spare_part_number"),
            equipment = it.objectOrNull("equipment")?.let(::decodeEquipment),
        )
    },
)

private fun encodeMovement(value: Movement) = JSONObject()
    .put("id", value.id)
    .put("kind", value.kind)
    .put("quantity", value.quantity)
    .put("stock_after", value.stockAfter)
    .put("part_name", value.partName)
    .put("article_number", value.articleNumber)
    .put("timestamp", value.timestamp)

private fun decodeMovement(json: JSONObject) = Movement(
    id = json.getString("id"),
    kind = json.optString("kind"),
    quantity = json.optInt("quantity"),
    stockAfter = json.optInt("stock_after"),
    partName = json.optString("part_name"),
    articleNumber = json.optString("article_number"),
    timestamp = json.optString("timestamp"),
)

private fun encodeWorkOrder(value: WorkOrder) = JSONObject()
    .put("id", value.id)
    .put("order_number", value.orderNumber)
    .put("customer_name", value.customerName)
    .put("short_text", value.shortText)
    .put("status", value.status)
    .put("equipment", value.equipment?.let(::encodeEquipment) ?: JSONObject.NULL)

private fun decodeWorkOrder(json: JSONObject) = WorkOrder(
    id = json.getString("id"),
    orderNumber = json.optString("order_number"),
    customerName = json.optString("customer_name"),
    shortText = json.optString("short_text"),
    status = json.optString("status"),
    equipment = json.objectOrNull("equipment")?.let(::decodeEquipment),
)

private fun encodeDocument(value: TechnicalDocument) = JSONObject()
    .put("id", value.id)
    .put("title", value.title)
    .put("kind", value.kind)
    .put("source_url", value.sourceUrl)
    .put("download_url", value.downloadUrl)
    .put("equipment", value.equipment?.let(::encodeEquipment) ?: JSONObject.NULL)

private fun decodeDocument(json: JSONObject) = TechnicalDocument(
    id = json.getString("id"),
    title = json.optString("title"),
    kind = json.optString("kind"),
    sourceUrl = json.optString("source_url"),
    downloadUrl = json.optString("download_url"),
    equipment = json.objectOrNull("equipment")?.let(::decodeEquipment),
)

private fun encodeDashboard(value: Dashboard) = JSONObject()
    .put("part_count", value.partCount)
    .put("stock_total", value.stockTotal)
    .put("low_stock_count", value.lowStockCount)
    .put("open_order_count", value.openOrderCount)
    .put("movements_today", value.movementsToday)
    .put("recent_movements", value.recentMovements.toJsonArray(::encodeMovement))
    .put("low_stock_parts", value.lowStockParts.toJsonArray(::encodePart))

private fun decodeDashboard(json: JSONObject) = Dashboard(
    partCount = json.optInt("part_count"),
    stockTotal = json.optInt("stock_total"),
    lowStockCount = json.optInt("low_stock_count"),
    openOrderCount = json.optInt("open_order_count"),
    movementsToday = json.optInt("movements_today"),
    recentMovements = json.optJSONArray("recent_movements").objectsOrEmpty().map(::decodeMovement),
    lowStockParts = json.optJSONArray("low_stock_parts").objectsOrEmpty().map(::decodePart),
)

private fun JSONObject.objectOrNull(name: String): JSONObject? =
    if (isNull(name)) null else optJSONObject(name)

private fun JSONObject.stringOrNull(name: String): String? =
    if (isNull(name)) null else optString(name).takeIf(String::isNotBlank)

private fun JSONArray?.objectsOrEmpty(): List<JSONObject> = buildList {
    if (this@objectsOrEmpty == null) return@buildList
    for (index in 0 until length()) add(getJSONObject(index))
}

private fun <T> List<T>.toJsonArray(encoder: (T) -> JSONObject): JSONArray = JSONArray().also { array ->
    forEach { array.put(encoder(it)) }
}
