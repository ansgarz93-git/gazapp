package de.ansgarz.gaslager.android.ui

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import de.ansgarz.gaslager.android.data.Part

object LowStockNotifier {
    private const val CHANNEL_ID = "gaslager_mindestbestand"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Mindestbestände",
                    NotificationManager.IMPORTANCE_HIGH,
                ).apply {
                    description = "Warnung, sobald ein Ersatzteil seinen Mindestbestand erreicht"
                }
            )
        }
    }

    fun notify(context: Context, part: Part) {
        createChannel(context)
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("Mindestbestand erreicht")
            .setContentText("${part.partName}: ${part.stockQuantity} ${part.unit} (Minimum ${part.minimumStock})")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(part.id.hashCode(), notification)
    }
}
