package de.ansgarz.gaslager.android.server

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import de.ansgarz.gaslager.android.MainActivity
import de.ansgarz.gaslager.android.R
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class EmbeddedServerService : Service() {
    private lateinit var settings: EmbeddedServerSettings
    private var httpServer: EmbeddedHttpServer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val statusScheduler = Executors.newSingleThreadScheduledExecutor()
    private var lastNotificationText = ""

    override fun onCreate() {
        super.onCreate()
        settings = EmbeddedServerSettings(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            settings.enabled = false
            shutdown()
            stopSelf()
            return START_NOT_STICKY
        }

        settings.enabled = true
        startAsForeground(buildNotification("Server wird gestartet …"))
        if (httpServer == null) {
            runCatching {
                val server = EmbeddedHttpServer(this, settings, EmbeddedServerStore(this))
                server.start()
                httpServer = server
                acquireLocks()
                updateStatus()
                statusScheduler.scheduleWithFixedDelay(::updateStatus, 3, 3, TimeUnit.SECONDS)
            }.onFailure { error ->
                EmbeddedServerRuntime.update(
                    EmbeddedServerStatus(false, settings.port, settings.localUrls(), error.message ?: "Server konnte nicht gestartet werden."),
                )
                updateNotification("Fehler: ${error.message ?: "Serverstart fehlgeschlagen"}")
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun acquireLocks() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:server").apply {
            setReferenceCounted(false)
            acquire()
        }
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        wifiLock = wifiManager.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "$packageName:server-wifi").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun updateStatus() {
        val urls = settings.localUrls()
        EmbeddedServerRuntime.update(EmbeddedServerStatus(true, settings.port, urls))
        val text = urls.firstOrNull() ?: "Port ${settings.port} · Hotspot einschalten"
        updateNotification(text)
    }

    private fun shutdown() {
        runCatching { httpServer?.stop() }
        httpServer = null
        statusScheduler.shutdownNow()
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
        wakeLock = null
        wifiLock = null
        EmbeddedServerRuntime.update(EmbeddedServerStatus(false, settings.port, settings.localUrls()))
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Gaslager-Server",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Dauerbetrieb der lokalen Gaslager-Weboberfläche"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, EmbeddedServerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Gaslager-Server läuft")
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Server stoppen", stopIntent)
            .build()
    }

    private fun startAsForeground(notification: Notification) {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun updateNotification(text: String) {
        if (text == lastNotificationText) return
        lastNotificationText = text
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(text))
    }

    companion object {
        const val ACTION_START = "de.ansgarz.gaslager.START_SERVER"
        const val ACTION_STOP = "de.ansgarz.gaslager.STOP_SERVER"
        private const val CHANNEL_ID = "gaslager_server"
        private const val NOTIFICATION_ID = 4102
    }
}
