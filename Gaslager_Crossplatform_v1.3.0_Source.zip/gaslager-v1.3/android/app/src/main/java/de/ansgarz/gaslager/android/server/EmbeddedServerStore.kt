package de.ansgarz.gaslager.android.server

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import de.ansgarz.gaslager.android.data.BookingResult
import de.ansgarz.gaslager.android.data.Compatibility
import de.ansgarz.gaslager.android.data.Dashboard
import de.ansgarz.gaslager.android.data.Drawer
import de.ansgarz.gaslager.android.data.Equipment
import de.ansgarz.gaslager.android.data.Movement
import de.ansgarz.gaslager.android.data.OfflineSnapshot
import de.ansgarz.gaslager.android.data.OfflineStore
import de.ansgarz.gaslager.android.data.Part
import de.ansgarz.gaslager.android.data.PartBarcode
import de.ansgarz.gaslager.android.data.TechnicalDocument
import de.ansgarz.gaslager.android.data.WorkOrder
import de.ansgarz.gaslager.android.data.decodeOfflineSnapshot
import de.ansgarz.gaslager.android.data.encodeOfflineSnapshot
import de.ansgarz.gaslager.android.ui.LowStockNotifier
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

class EmbeddedStoreException(message: String, val statusCode: Int = 400) : Exception(message)

data class EmbeddedBookingResult(
    val movement: Movement,
    val stockAfter: Int,
)

class EmbeddedServerStore(context: Context) {
    private val appContext = context.applicationContext
    private val database = ServerDatabase(appContext)

    init {
        initializeIfNeeded()
    }

    @Synchronized
    fun snapshot(): OfflineSnapshot = readState().snapshot

    @Synchronized
    fun parts(query: String = ""): List<Part> {
        val values = readState().snapshot.parts
        if (query.isBlank()) return values
        val needle = query.trim().lowercase(Locale.GERMANY)
        return values.filter { part ->
            listOf(part.manufacturer, part.originalArticleNumber, part.partName, part.notes, part.drawer?.code.orEmpty())
                .any { needle in it.lowercase(Locale.GERMANY) } ||
                part.barcodes.any { needle in it.value.lowercase(Locale.GERMANY) } ||
                part.compatibilities.any {
                    needle in it.deviceSparePartNumber.lowercase(Locale.GERMANY) ||
                        needle in it.equipment?.designation.orEmpty().lowercase(Locale.GERMANY)
                }
        }
    }

    @Synchronized
    fun part(id: String): Part = readState().snapshot.parts.firstOrNull { it.id == id }
        ?: throw EmbeddedStoreException("Ersatzteil wurde nicht gefunden.", 404)

    @Synchronized
    fun resolveBarcode(value: String): Part {
        val key = normalizeBarcode(value)
        return readState().snapshot.parts.firstOrNull { part ->
            part.barcodes.any { normalizeBarcode(it.value) == key }
        } ?: throw EmbeddedStoreException("Barcode wurde nicht gefunden.", 404)
    }

    @Synchronized
    fun createPart(body: JSONObject): Part = mutate { state ->
        val articleNumber = body.optString("original_article_number").trim()
        val name = body.optString("part_name").trim()
        if (articleNumber.isBlank()) throw EmbeddedStoreException("Original-Artikelnummer fehlt.")
        if (name.isBlank()) throw EmbeddedStoreException("Bezeichnung fehlt.")

        val drawerId = body.nullableString("drawer_id")
        val drawer = drawerId?.let { id -> state.snapshot.drawers.firstOrNull { it.id == id } }
        if (drawerId != null && drawer == null) throw EmbeddedStoreException("Schublade wurde nicht gefunden.", 404)

        val barcodeValues = body.optJSONArray("barcodes").jsonObjects().mapNotNull { json ->
            val value = json.optString("value").trim()
            if (value.isBlank()) null else PartBarcode(
                id = UUID.randomUUID().toString(),
                value = value,
                symbology = json.optString("symbology"),
                primary = json.optBoolean("is_primary"),
            )
        }
        for (barcode in barcodeValues) ensureBarcodeAvailable(state.snapshot.parts, barcode.value)

        val compatibilities = body.optJSONArray("compatibilities").jsonObjects().mapNotNull { json ->
            val equipmentId = json.optString("equipment_type_id").trim()
            val spareNumber = json.optString("device_spare_part_number").trim()
            if (equipmentId.isBlank() || spareNumber.isBlank()) return@mapNotNull null
            val equipment = state.snapshot.equipment.firstOrNull { it.id == equipmentId }
                ?: throw EmbeddedStoreException("Regler/Pilot wurde nicht gefunden.", 404)
            Compatibility(UUID.randomUUID().toString(), equipmentId, spareNumber, equipment)
        }

        val stock = body.optInt("initial_stock").coerceAtLeast(0)
        val minimum = body.optInt("minimum_stock").coerceAtLeast(0)
        val part = Part(
            id = UUID.randomUUID().toString(),
            manufacturer = body.optString("manufacturer", "Honeywell / RMG").trim().ifBlank { "Honeywell / RMG" },
            originalArticleNumber = articleNumber,
            partName = name,
            unit = body.optString("unit", "Stück").trim().ifBlank { "Stück" },
            stockQuantity = stock,
            minimumStock = minimum,
            reminderEnabled = body.optBoolean("reminder_enabled", true),
            isLowStock = stock <= minimum,
            notes = body.optString("notes"),
            drawer = drawer,
            barcodes = barcodeValues,
            compatibilities = compatibilities,
        )
        val parts = state.snapshot.parts + part
        state.snapshot = refreshDashboard(state.snapshot.copy(parts = parts), parts)
        part
    }

    @Synchronized
    fun updatePart(id: String, body: JSONObject): Part = mutate { state ->
        val current = state.snapshot.parts.firstOrNull { it.id == id }
            ?: throw EmbeddedStoreException("Ersatzteil wurde nicht gefunden.", 404)
        val drawer = if (body.has("drawer_id")) {
            body.nullableString("drawer_id")?.let { drawerId ->
                state.snapshot.drawers.firstOrNull { it.id == drawerId }
                    ?: throw EmbeddedStoreException("Schublade wurde nicht gefunden.", 404)
            }
        } else current.drawer
        val minimum = if (body.has("minimum_stock")) body.optInt("minimum_stock").coerceAtLeast(0) else current.minimumStock
        val updated = current.copy(
            manufacturer = body.optStringIfPresent("manufacturer") ?: current.manufacturer,
            originalArticleNumber = body.optStringIfPresent("original_article_number") ?: current.originalArticleNumber,
            partName = body.optStringIfPresent("part_name") ?: current.partName,
            unit = body.optStringIfPresent("unit") ?: current.unit,
            minimumStock = minimum,
            reminderEnabled = if (body.has("reminder_enabled")) body.optBoolean("reminder_enabled") else current.reminderEnabled,
            isLowStock = current.stockQuantity <= minimum,
            notes = body.optStringIfPresent("notes") ?: current.notes,
            drawer = drawer,
        )
        val parts = state.snapshot.parts.map { if (it.id == id) updated else it }
        state.snapshot = refreshDashboard(state.snapshot.copy(parts = parts), parts)
        updated
    }

    @Synchronized
    fun addBarcode(partId: String, body: JSONObject): Part = mutate { state ->
        val value = body.optString("value").trim()
        if (value.isBlank()) throw EmbeddedStoreException("Barcodewert fehlt.")
        ensureBarcodeAvailable(state.snapshot.parts, value)
        val current = state.snapshot.parts.firstOrNull { it.id == partId }
            ?: throw EmbeddedStoreException("Ersatzteil wurde nicht gefunden.", 404)
        val barcode = PartBarcode(
            id = UUID.randomUUID().toString(),
            value = value,
            symbology = body.optString("symbology"),
            primary = body.optBoolean("is_primary"),
        )
        val updated = current.copy(barcodes = current.barcodes + barcode)
        state.snapshot = state.snapshot.copy(
            savedAt = System.currentTimeMillis(),
            parts = state.snapshot.parts.map { if (it.id == partId) updated else it },
        )
        updated
    }

    @Synchronized
    fun addCompatibility(partId: String, body: JSONObject): Part = mutate { state ->
        val equipmentId = body.optString("equipment_type_id").trim()
        val spareNumber = body.optString("device_spare_part_number").trim()
        if (spareNumber.isBlank()) throw EmbeddedStoreException("Gerätespezifische Ersatzteilnummer fehlt.")
        val equipment = state.snapshot.equipment.firstOrNull { it.id == equipmentId }
            ?: throw EmbeddedStoreException("Regler/Pilot wurde nicht gefunden.", 404)
        val current = state.snapshot.parts.firstOrNull { it.id == partId }
            ?: throw EmbeddedStoreException("Ersatzteil wurde nicht gefunden.", 404)
        if (current.compatibilities.any {
                it.equipmentTypeId == equipmentId && it.deviceSparePartNumber.equals(spareNumber, true)
            }
        ) throw EmbeddedStoreException("Diese Mehrfachverwendung ist bereits hinterlegt.", 409)
        val compatibility = Compatibility(UUID.randomUUID().toString(), equipmentId, spareNumber, equipment)
        val updated = current.copy(compatibilities = current.compatibilities + compatibility)
        state.snapshot = state.snapshot.copy(
            savedAt = System.currentTimeMillis(),
            parts = state.snapshot.parts.map { if (it.id == partId) updated else it },
        )
        updated
    }

    @Synchronized
    fun book(body: JSONObject): EmbeddedBookingResult {
        val result = mutate { state ->
            val idempotencyKey = body.nullableString("idempotency_key")
            if (idempotencyKey != null && state.processed.has(idempotencyKey)) {
                val stockAfter = state.processed.getInt(idempotencyKey)
                val part = state.snapshot.parts.firstOrNull { it.id == body.optString("part_id") }
                    ?: throw EmbeddedStoreException("Ersatzteil wurde nicht gefunden.", 404)
                return@mutate EmbeddedBookingResult(
                    Movement("repeat-$idempotencyKey", body.optString("kind"), body.optInt("quantity"), stockAfter,
                        part.partName, part.originalArticleNumber, timestamp()),
                    stockAfter,
                )
            }

            val partId = body.optString("part_id")
            val current = state.snapshot.parts.firstOrNull { it.id == partId }
                ?: throw EmbeddedStoreException("Ersatzteil wurde nicht gefunden.", 404)
            val kind = body.optString("kind")
            if (kind !in setOf("Eingang", "Ausgang")) throw EmbeddedStoreException("Buchungsart ist ungültig.")
            val quantity = body.optInt("quantity")
            if (quantity <= 0) throw EmbeddedStoreException("Menge muss größer als null sein.")

            val workOrderId = body.nullableString("work_order_id")
            val workOrder = workOrderId?.let { id -> state.snapshot.workOrders.firstOrNull { it.id == id } }
            if (workOrderId != null && workOrder == null) throw EmbeddedStoreException("Auftrag wurde nicht gefunden.", 404)
            if (kind == "Ausgang" && workOrder?.equipment != null &&
                current.compatibilities.none { it.equipmentTypeId == workOrder.equipment.id }
            ) {
                throw EmbeddedStoreException("Ersatzteil ist nicht für den Regler/Piloten des Auftrags freigegeben.", 409)
            }

            val stockAfter = if (kind == "Eingang") current.stockQuantity + quantity else current.stockQuantity - quantity
            if (stockAfter < 0) throw EmbeddedStoreException("Bestand reicht für diese Entnahme nicht aus.", 409)
            val updated = current.copy(stockQuantity = stockAfter, isLowStock = stockAfter <= current.minimumStock)
            val movement = Movement(
                id = UUID.randomUUID().toString(),
                kind = kind,
                quantity = quantity,
                stockAfter = stockAfter,
                partName = current.partName,
                articleNumber = current.originalArticleNumber,
                timestamp = timestamp(),
            )
            val parts = state.snapshot.parts.map { if (it.id == partId) updated else it }
            state.snapshot = refreshDashboard(
                snapshot = state.snapshot.copy(parts = parts),
                parts = parts,
                movement = movement,
            )
            if (idempotencyKey != null) state.processed.put(idempotencyKey, stockAfter)
            EmbeddedBookingResult(movement, stockAfter)
        }
        if (!result.movement.id.startsWith("repeat-")) {
            snapshot().parts.firstOrNull { it.id == body.optString("part_id") }
                ?.takeIf { it.reminderEnabled && it.isLowStock }
                ?.let { LowStockNotifier.notify(appContext, it) }
        }
        return result
    }

    @Synchronized
    fun createEquipment(body: JSONObject): Equipment = mutate { state ->
        val designation = body.optString("designation").trim()
        val kind = body.optString("kind").trim()
        if (designation.isBlank()) throw EmbeddedStoreException("Gerätetyp fehlt.")
        if (kind !in setOf("Gasdruckregler", "Pilot")) throw EmbeddedStoreException("Kategorie muss Gasdruckregler oder Pilot sein.")
        if (state.snapshot.equipment.any { it.designation.equals(designation, true) && it.kind == kind }) {
            throw EmbeddedStoreException("Dieser Regler/Pilot ist bereits vorhanden.", 409)
        }
        val equipment = Equipment(
            UUID.randomUUID().toString(),
            body.optString("manufacturer", "Honeywell / RMG").ifBlank { "Honeywell / RMG" },
            designation,
            kind,
        )
        state.snapshot = state.snapshot.copy(savedAt = System.currentTimeMillis(), equipment = state.snapshot.equipment + equipment)
        equipment
    }

    @Synchronized
    fun createDrawer(body: JSONObject): Drawer = mutate { state ->
        val code = body.optString("code").trim()
        val equipmentId = body.optString("equipment_type_id").trim()
        if (code.isBlank()) throw EmbeddedStoreException("Schubladencode fehlt.")
        if (state.snapshot.drawers.any { it.code.equals(code, true) }) {
            throw EmbeddedStoreException("Schubladencode ist bereits vergeben.", 409)
        }
        val equipment = state.snapshot.equipment.firstOrNull { it.id == equipmentId }
            ?: throw EmbeddedStoreException("Regler/Pilot wurde nicht gefunden.", 404)
        val drawer = Drawer(
            UUID.randomUUID().toString(),
            code,
            body.optString("location"),
            equipmentId,
            equipment,
        )
        state.snapshot = state.snapshot.copy(savedAt = System.currentTimeMillis(), drawers = state.snapshot.drawers + drawer)
        drawer
    }

    @Synchronized
    fun createWorkOrder(body: JSONObject): WorkOrder = mutate { state ->
        val orderNumber = body.optString("order_number").trim()
        if (orderNumber.isBlank()) throw EmbeddedStoreException("Auftragsnummer fehlt.")
        if (state.snapshot.workOrders.any { it.orderNumber.equals(orderNumber, true) }) {
            throw EmbeddedStoreException("Auftragsnummer ist bereits vorhanden.", 409)
        }
        val equipmentId = body.nullableString("equipment_type_id")
        val equipment = equipmentId?.let { id -> state.snapshot.equipment.firstOrNull { it.id == id } }
        if (equipmentId != null && equipment == null) throw EmbeddedStoreException("Regler/Pilot wurde nicht gefunden.", 404)
        val order = WorkOrder(
            UUID.randomUUID().toString(),
            orderNumber,
            body.optString("customer_name"),
            body.optString("short_text"),
            body.optString("status", "Offen").ifBlank { "Offen" },
            equipment,
        )
        val orders = state.snapshot.workOrders + order
        state.snapshot = refreshDashboard(state.snapshot.copy(workOrders = orders), state.snapshot.parts)
        order
    }

    @Synchronized
    fun exportState(): JSONObject {
        val state = readState()
        return JSONObject()
            .put("format", "gaslager-android-server")
            .put("version", 1)
            .put("exported_at", System.currentTimeMillis())
            .put("snapshot", encodeOfflineSnapshot(state.snapshot))
            .put("processed", JSONObject(state.processed.toString()))
    }

    @Synchronized
    fun importState(value: JSONObject) {
        if (value.optString("format") != "gaslager-android-server") {
            throw EmbeddedStoreException("Datei ist keine Gaslager-Serversicherung.")
        }
        val snapshotJson = value.optJSONObject("snapshot") ?: throw EmbeddedStoreException("Sicherung enthält keinen Datenbestand.")
        val snapshot = decodeOfflineSnapshot(snapshotJson).copy(savedAt = System.currentTimeMillis())
        val state = StoredState(refreshDashboard(snapshot, snapshot.parts), value.optJSONObject("processed") ?: JSONObject())
        writeState(state)
    }

    private fun initializeIfNeeded() {
        val db = database.writableDatabase
        val count = db.rawQuery("SELECT COUNT(*) FROM server_state", null).use { cursor ->
            cursor.moveToFirst()
            cursor.getInt(0)
        }
        if (count > 0) return
        val snapshot = OfflineStore(appContext).loadSnapshot() ?: seededSnapshot()
        writeState(StoredState(refreshDashboard(snapshot, snapshot.parts), JSONObject()))
    }

    private fun seededSnapshot(): OfflineSnapshot {
        val rows = appContext.assets.open("equipment_catalog.csv").bufferedReader(StandardCharsets.UTF_8).useLines { lines ->
            lines.drop(1).mapNotNull { line ->
                val cells = line.split(';')
                if (cells.size < 3) null else Equipment(
                    id = UUID.nameUUIDFromBytes("${cells[0]}|${cells[1]}|${cells[2]}".toByteArray()).toString(),
                    manufacturer = cells[0].trim(),
                    designation = cells[1].trim(),
                    kind = cells[2].trim(),
                )
            }.toList()
        }
        val regulatorUrl = "https://process.honeywell.com/us/en/products/gas/regulators-and-safety-accessories"
        val pilotUrl = "$regulatorUrl/pilot-for-gas-pressure-regulators"
        val documents = rows.map { equipment ->
            TechnicalDocument(
                id = UUID.nameUUIDFromBytes("document|${equipment.id}".toByteArray()).toString(),
                title = "${equipment.designation} – offizielle Herstellerquelle",
                kind = "Herstellerseite",
                sourceUrl = if (equipment.kind == "Pilot") pilotUrl else regulatorUrl,
                downloadUrl = "",
                equipment = equipment,
            )
        }
        return OfflineSnapshot(
            savedAt = System.currentTimeMillis(),
            dashboard = Dashboard(0, 0, 0, 0, 0, emptyList(), emptyList()),
            parts = emptyList(),
            equipment = rows,
            drawers = emptyList(),
            workOrders = emptyList(),
            documents = documents,
        )
    }

    private fun ensureBarcodeAvailable(parts: List<Part>, value: String) {
        val key = normalizeBarcode(value)
        if (parts.any { part -> part.barcodes.any { normalizeBarcode(it.value) == key } }) {
            throw EmbeddedStoreException("Barcode ist bereits einem Ersatzteil zugeordnet.", 409)
        }
    }

    private fun refreshDashboard(
        snapshot: OfflineSnapshot,
        parts: List<Part>,
        movement: Movement? = null,
    ): OfflineSnapshot {
        val lowStock = parts.filter { it.reminderEnabled && it.stockQuantity <= it.minimumStock }
        val movements = listOfNotNull(movement) + snapshot.dashboard.recentMovements
        return snapshot.copy(
            savedAt = System.currentTimeMillis(),
            dashboard = snapshot.dashboard.copy(
                partCount = parts.size,
                stockTotal = parts.sumOf(Part::stockQuantity),
                lowStockCount = lowStock.size,
                openOrderCount = snapshot.workOrders.count { it.status !in setOf("Abgeschlossen", "Storniert") },
                movementsToday = snapshot.dashboard.movementsToday + if (movement == null) 0 else 1,
                recentMovements = movements.distinctBy(Movement::id).take(50),
                lowStockParts = lowStock,
            ),
        )
    }

    private inline fun <T> mutate(block: (StoredState) -> T): T {
        val db = database.writableDatabase
        db.beginTransaction()
        return try {
            val state = readState(db)
            val result = block(state)
            writeState(state, db)
            db.setTransactionSuccessful()
            result
        } finally {
            db.endTransaction()
        }
    }

    private fun readState(db: SQLiteDatabase = database.readableDatabase): StoredState {
        return db.rawQuery("SELECT snapshot_json, processed_json FROM server_state WHERE id = 1", null).use { cursor ->
            if (!cursor.moveToFirst()) throw EmbeddedStoreException("Lokale Serverdatenbank ist nicht initialisiert.", 500)
            StoredState(
                decodeOfflineSnapshot(JSONObject(cursor.getString(0))),
                JSONObject(cursor.getString(1)),
            )
        }
    }

    private fun writeState(state: StoredState, db: SQLiteDatabase = database.writableDatabase) {
        val values = ContentValues().apply {
            put("id", 1)
            put("snapshot_json", encodeOfflineSnapshot(state.snapshot).toString())
            put("processed_json", state.processed.toString())
            put("updated_at", System.currentTimeMillis())
        }
        db.insertWithOnConflict("server_state", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private data class StoredState(
        var snapshot: OfflineSnapshot,
        val processed: JSONObject,
    )

    private class ServerDatabase(context: Context) : SQLiteOpenHelper(context, "gaslager-server.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                """CREATE TABLE server_state (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    snapshot_json TEXT NOT NULL,
                    processed_json TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                )""".trimIndent()
            )
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
    }
}

private fun normalizeBarcode(value: String): String {
    val cleaned = value.trim().replace("\u200B", "")
    return if (cleaned.length > 3 && cleaned[0] == ']' && cleaned[2].isDigit()) cleaned.substring(3) else cleaned
}

private fun timestamp(): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.GERMANY).apply {
    timeZone = TimeZone.getDefault()
}.format(Date())

private fun JSONObject.nullableString(name: String): String? =
    if (!has(name) || isNull(name)) null else optString(name).trim().takeIf(String::isNotBlank)

private fun JSONObject.optStringIfPresent(name: String): String? =
    if (!has(name) || isNull(name)) null else optString(name).trim()

private fun JSONArray?.jsonObjects(): List<JSONObject> = buildList {
    if (this@jsonObjects == null) return@buildList
    for (index in 0 until length()) optJSONObject(index)?.let(::add)
}
