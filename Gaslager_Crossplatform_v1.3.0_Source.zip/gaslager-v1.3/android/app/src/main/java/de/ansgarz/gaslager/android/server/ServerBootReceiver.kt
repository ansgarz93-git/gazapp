package de.ansgarz.gaslager.android.server

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ServerBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED && EmbeddedServerSettings(context).enabled) {
            EmbeddedServerController.start(context)
        }
    }
}
