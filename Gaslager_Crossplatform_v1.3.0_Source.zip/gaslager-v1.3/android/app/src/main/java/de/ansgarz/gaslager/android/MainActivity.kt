package de.ansgarz.gaslager.android

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import de.ansgarz.gaslager.android.ui.GaslagerApp
import de.ansgarz.gaslager.android.ui.LowStockNotifier
import de.ansgarz.gaslager.android.ui.theme.GaslagerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LowStockNotifier.createChannel(this)

        val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            GaslagerTheme {
                GaslagerApp()
            }
        }
    }
}
