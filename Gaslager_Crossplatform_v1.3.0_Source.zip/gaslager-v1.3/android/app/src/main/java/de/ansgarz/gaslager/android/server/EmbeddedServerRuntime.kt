package de.ansgarz.gaslager.android.server

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EmbeddedServerStatus(
    val running: Boolean = false,
    val port: Int = 8080,
    val urls: List<String> = emptyList(),
    val error: String = "",
)

object EmbeddedServerRuntime {
    private val mutableStatus = MutableStateFlow(EmbeddedServerStatus())
    val status: StateFlow<EmbeddedServerStatus> = mutableStatus.asStateFlow()

    internal fun update(value: EmbeddedServerStatus) {
        mutableStatus.value = value
    }
}
