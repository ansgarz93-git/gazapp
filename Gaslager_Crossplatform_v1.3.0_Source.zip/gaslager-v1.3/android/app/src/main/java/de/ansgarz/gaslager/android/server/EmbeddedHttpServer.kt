package de.ansgarz.gaslager.android.server

import android.content.Context
import de.ansgarz.gaslager.android.data.Compatibility
import de.ansgarz.gaslager.android.data.Dashboard
import de.ansgarz.gaslager.android.data.Drawer
import de.ansgarz.gaslager.android.data.Equipment
import de.ansgarz.gaslager.android.data.Movement
import de.ansgarz.gaslager.android.data.Part
import de.ansgarz.gaslager.android.data.TechnicalDocument
import de.ansgarz.gaslager.android.data.WorkOrder
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class EmbeddedHttpServer(
    context: Context,
    private val settings: EmbeddedServerSettings,
    private val store: EmbeddedServerStore,
) {
    private val appContext = context.applicationContext
    private var socket: ServerSocket? = null
    private var workers: ExecutorService? = null
    @Volatile private var running = false

    fun start() {
        if (running) return
        val serverSocket = ServerSocket(settings.port).apply { reuseAddress = true }
        socket = serverSocket
        workers = Executors.newCachedThreadPool()
        running = true
        thread(name = "gaslager-http-accept", isDaemon = true) {
            while (running) {
                val client = runCatching { serverSocket.accept() }.getOrNull() ?: break
                workers?.execute { handle(client) }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { socket?.close() }
        workers?.shutdownNow()
        socket = null
        workers = null
    }

    private fun handle(client: Socket) {
        client.use { connection ->
            runCatching {
                connection.soTimeout = 30_000
                val request = readRequest(BufferedInputStream(connection.getInputStream()))
                val response = route(request)
                writeResponse(BufferedOutputStream(connection.getOutputStream()), response)
            }.onFailure { error ->
                runCatching {
                    val status = if (error is EmbeddedStoreException) error.statusCode else 500
                    writeResponse(
                        BufferedOutputStream(connection.getOutputStream()),
                        jsonResponse(status, JSONObject().put("detail", error.message ?: "Interner Serverfehler")),
                    )
                }
            }
        }
    }

    private fun route(request: HttpRequest): HttpResponse {
        if (request.method == "OPTIONS") return HttpResponse(204, "text/plain", ByteArray(0))
        if (request.path == "/" && request.method == "GET") {
            val bytes = appContext.assets.open("server/index.html").use { it.readBytes() }
            return HttpResponse(200, "text/html; charset=utf-8", bytes)
        }
        if (request.path == "/favicon.ico") return HttpResponse(204, "image/x-icon", ByteArray(0))
        if (request.path == "/api/v1/health" && request.method == "GET") {
            return jsonResponse(200, JSONObject().put("status", "ok").put("mode", "android-server"))
        }
        if (request.path == "/api/v1/auth/login" && request.method == "POST") {
            val body = request.jsonBody()
            if (body.optString("username") != settings.username ||
                !secureEquals(body.optString("password"), settings.password)
            ) throw EmbeddedStoreException("Benutzername oder Zugangscode ist falsch.", 401)
            return jsonResponse(
                200,
                JSONObject()
                    .put("access_token", settings.accessToken)
                    .put("token_type", "bearer")
                    .put("expires_in", 31_536_000),
            )
        }
        if (!request.isAuthorized(settings.accessToken)) throw EmbeddedStoreException("Anmeldung erforderlich.", 401)

        return when {
            request.path == "/api/v1/auth/me" && request.method == "GET" -> jsonResponse(
                200,
                JSONObject().put("username", settings.username).put("display_name", "Administrator").put("is_admin", true),
            )
            request.path == "/api/v1/dashboard" && request.method == "GET" ->
                jsonResponse(200, dashboardJson(store.snapshot().dashboard))
            request.path == "/api/v1/parts" && request.method == "GET" ->
                jsonResponse(200, store.parts(request.query["q"].orEmpty()).jsonArray(::partJson))
            request.path == "/api/v1/parts" && request.method == "POST" ->
                jsonResponse(201, partJson(store.createPart(request.jsonBody())))
            request.path.matches(Regex("/api/v1/parts/[^/]+")) && request.method == "GET" -> {
                val id = request.path.substringAfterLast('/')
                jsonResponse(200, partJson(store.part(id)))
            }
            request.path.matches(Regex("/api/v1/parts/[^/]+")) && request.method == "PATCH" -> {
                val id = request.path.substringAfterLast('/')
                jsonResponse(200, partJson(store.updatePart(id, request.jsonBody())))
            }
            request.path.matches(Regex("/api/v1/parts/[^/]+/barcodes")) && request.method == "POST" -> {
                val id = request.path.removeSuffix("/barcodes").substringAfterLast('/')
                jsonResponse(201, partJson(store.addBarcode(id, request.jsonBody())))
            }
            request.path.matches(Regex("/api/v1/parts/[^/]+/compatibilities")) && request.method == "POST" -> {
                val id = request.path.removeSuffix("/compatibilities").substringAfterLast('/')
                jsonResponse(201, partJson(store.addCompatibility(id, request.jsonBody())))
            }
            request.path == "/api/v1/barcodes/resolve" && request.method == "GET" ->
                jsonResponse(200, partJson(store.resolveBarcode(request.query["value"].orEmpty())))
            request.path == "/api/v1/equipment" && request.method == "GET" ->
                jsonResponse(200, store.snapshot().equipment.jsonArray(::equipmentJson))
            request.path == "/api/v1/equipment" && request.method == "POST" ->
                jsonResponse(201, equipmentJson(store.createEquipment(request.jsonBody())))
            request.path == "/api/v1/drawers" && request.method == "GET" ->
                jsonResponse(200, store.snapshot().drawers.jsonArray(::drawerJson))
            request.path == "/api/v1/drawers" && request.method == "POST" ->
                jsonResponse(201, drawerJson(store.createDrawer(request.jsonBody())))
            request.path == "/api/v1/work-orders" && request.method == "GET" -> {
                val openOnly = request.query["open_only"].equals("true", true)
                val orders = store.snapshot().workOrders.filter { !openOnly || it.status !in setOf("Abgeschlossen", "Storniert") }
                jsonResponse(200, orders.jsonArray(::workOrderJson))
            }
            request.path == "/api/v1/work-orders" && request.method == "POST" ->
                jsonResponse(201, workOrderJson(store.createWorkOrder(request.jsonBody())))
            request.path.matches(Regex("/api/v1/work-orders/[^/]+/compatible-parts")) && request.method == "GET" -> {
                val orderId = request.path.removeSuffix("/compatible-parts").substringAfterLast('/')
                val order = store.snapshot().workOrders.firstOrNull { it.id == orderId }
                    ?: throw EmbeddedStoreException("Auftrag wurde nicht gefunden.", 404)
                val equipmentId = order.equipment?.id
                val parts = if (equipmentId == null) store.snapshot().parts else store.snapshot().parts.filter { part ->
                    part.compatibilities.any { it.equipmentTypeId == equipmentId }
                }
                jsonResponse(200, parts.jsonArray(::partJson))
            }
            request.path == "/api/v1/documents" && request.method == "GET" ->
                jsonResponse(200, store.snapshot().documents.jsonArray(::documentJson))
            request.path == "/api/v1/movements" && request.method == "POST" -> {
                val result = store.book(request.jsonBody())
                jsonResponse(201, movementJson(result.movement).put("stock_after", result.stockAfter))
            }
            request.path == "/api/v1/server/status" && request.method == "GET" -> jsonResponse(
                200,
                JSONObject()
                    .put("running", true)
                    .put("port", settings.port)
                    .put("urls", JSONArray(settings.localUrls()))
                    .put("internet_required", false),
            )
            request.path == "/api/v1/server/export" && request.method == "GET" -> HttpResponse(
                200,
                "application/json; charset=utf-8",
                store.exportState().toString(2).toByteArray(StandardCharsets.UTF_8),
                mapOf("Content-Disposition" to "attachment; filename=gaslager-android-server-backup.json"),
            )
            request.path == "/api/v1/server/import" && request.method == "POST" -> {
                store.importState(request.jsonBody())
                jsonResponse(200, JSONObject().put("status", "imported"))
            }
            else -> throw EmbeddedStoreException("Endpunkt wurde nicht gefunden.", 404)
        }
    }

    private fun readRequest(input: BufferedInputStream): HttpRequest {
        val requestLine = readLine(input)?.trim().orEmpty()
        val parts = requestLine.split(' ')
        if (parts.size < 2) throw EmbeddedStoreException("Ungültige HTTP-Anfrage.", 400)
        val method = parts[0].uppercase(Locale.ROOT)
        val target = parts[1]
        val headers = linkedMapOf<String, String>()
        var headerCount = 0
        while (headerCount < 100) {
            val line = readLine(input) ?: throw EmbeddedStoreException("Unvollständige HTTP-Anfrage.", 400)
            if (line.isEmpty()) break
            val separator = line.indexOf(':')
            if (separator > 0) headers[line.substring(0, separator).trim().lowercase(Locale.ROOT)] = line.substring(separator + 1).trim()
            headerCount += 1
        }
        val contentLength = headers["content-length"]?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        if (contentLength > MAX_BODY_BYTES) throw EmbeddedStoreException("Anfrage ist zu groß.", 413)
        val body = ByteArray(contentLength)
        var offset = 0
        while (offset < contentLength) {
            val read = input.read(body, offset, contentLength - offset)
            if (read < 0) throw EmbeddedStoreException("Unvollständiger Anfrageinhalt.", 400)
            offset += read
        }
        val uri = URI.create("http://localhost$target")
        return HttpRequest(
            method = method,
            path = uri.path,
            query = parseQuery(uri.rawQuery),
            headers = headers,
            body = body,
        )
    }

    private fun readLine(input: BufferedInputStream): String? {
        val bytes = ArrayList<Byte>(128)
        while (bytes.size < MAX_LINE_BYTES) {
            val value = input.read()
            if (value < 0) return if (bytes.isEmpty()) null else bytes.toByteArray().toString(StandardCharsets.ISO_8859_1)
            if (value == '\n'.code) break
            if (value != '\r'.code) bytes += value.toByte()
        }
        if (bytes.size >= MAX_LINE_BYTES) throw EmbeddedStoreException("HTTP-Kopfzeile ist zu lang.", 431)
        return bytes.toByteArray().toString(StandardCharsets.ISO_8859_1)
    }

    private fun writeResponse(output: BufferedOutputStream, response: HttpResponse) {
        val reason = STATUS_TEXT[response.status] ?: "OK"
        val headers = linkedMapOf(
            "Content-Type" to response.contentType,
            "Content-Length" to response.body.size.toString(),
            "Connection" to "close",
            "Cache-Control" to "no-store",
            "Access-Control-Allow-Origin" to "*",
            "Access-Control-Allow-Headers" to "Authorization, Content-Type",
            "Access-Control-Allow-Methods" to "GET, POST, PATCH, OPTIONS",
            "X-Content-Type-Options" to "nosniff",
            "Content-Security-Policy" to "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'",
        ).apply { putAll(response.headers) }
        output.write("HTTP/1.1 ${response.status} $reason\r\n".toByteArray(StandardCharsets.ISO_8859_1))
        headers.forEach { (name, value) ->
            output.write("$name: $value\r\n".toByteArray(StandardCharsets.ISO_8859_1))
        }
        output.write("\r\n".toByteArray(StandardCharsets.ISO_8859_1))
        output.write(response.body)
        output.flush()
    }

    private fun jsonResponse(status: Int, value: JSONObject): HttpResponse =
        HttpResponse(status, "application/json; charset=utf-8", value.toString().toByteArray(StandardCharsets.UTF_8))

    private fun jsonResponse(status: Int, value: JSONArray): HttpResponse =
        HttpResponse(status, "application/json; charset=utf-8", value.toString().toByteArray(StandardCharsets.UTF_8))

    private data class HttpRequest(
        val method: String,
        val path: String,
        val query: Map<String, String>,
        val headers: Map<String, String>,
        val body: ByteArray,
    ) {
        fun jsonBody(): JSONObject = runCatching {
            JSONObject(body.toString(StandardCharsets.UTF_8).ifBlank { "{}" })
        }.getOrElse { throw EmbeddedStoreException("Ungültiger JSON-Inhalt.") }

        fun isAuthorized(token: String): Boolean {
            val supplied = headers["authorization"]?.removePrefix("Bearer ")?.trim().orEmpty()
            return secureEquals(supplied, token)
        }
    }

    private data class HttpResponse(
        val status: Int,
        val contentType: String,
        val body: ByteArray,
        val headers: Map<String, String> = emptyMap(),
    )

    companion object {
        private const val MAX_BODY_BYTES = 4 * 1024 * 1024
        private const val MAX_LINE_BYTES = 16 * 1024
        private val STATUS_TEXT = mapOf(
            200 to "OK", 201 to "Created", 204 to "No Content", 400 to "Bad Request",
            401 to "Unauthorized", 404 to "Not Found", 409 to "Conflict", 413 to "Payload Too Large",
            431 to "Request Header Fields Too Large", 500 to "Internal Server Error",
        )
    }
}

private fun parseQuery(raw: String?): Map<String, String> {
    if (raw.isNullOrBlank()) return emptyMap()
    return raw.split('&').associate { pair ->
        val parts = pair.split('=', limit = 2)
        decode(parts[0]) to decode(parts.getOrElse(1) { "" })
    }
}

private fun decode(value: String): String = URLDecoder.decode(value, StandardCharsets.UTF_8.name())

private fun secureEquals(left: String, right: String): Boolean = MessageDigest.isEqual(
    left.toByteArray(StandardCharsets.UTF_8),
    right.toByteArray(StandardCharsets.UTF_8),
)

private fun equipmentJson(value: Equipment) = JSONObject()
    .put("id", value.id)
    .put("manufacturer", value.manufacturer)
    .put("designation", value.designation)
    .put("kind", value.kind)

private fun drawerJson(value: Drawer) = JSONObject()
    .put("id", value.id)
    .put("code", value.code)
    .put("location", value.location)
    .put("equipment_type_id", value.equipmentTypeId)
    .put("equipment_type", value.equipment?.let(::equipmentJson) ?: JSONObject.NULL)

private fun compatibilityJson(value: Compatibility) = JSONObject()
    .put("id", value.id)
    .put("equipment_type_id", value.equipmentTypeId)
    .put("device_spare_part_number", value.deviceSparePartNumber)
    .put("equipment_type", value.equipment?.let(::equipmentJson) ?: JSONObject.NULL)

private fun partJson(value: Part) = JSONObject()
    .put("id", value.id)
    .put("manufacturer", value.manufacturer)
    .put("original_article_number", value.originalArticleNumber)
    .put("part_name", value.partName)
    .put("unit", value.unit)
    .put("stock_quantity", value.stockQuantity)
    .put("minimum_stock", value.minimumStock)
    .put("reminder_enabled", value.reminderEnabled)
    .put("is_low_stock", value.isLowStock)
    .put("notes", value.notes)
    .put("drawer", value.drawer?.let(::drawerJson) ?: JSONObject.NULL)
    .put("barcodes", value.barcodes.jsonArray { barcode ->
        JSONObject()
            .put("id", barcode.id)
            .put("value", barcode.value)
            .put("symbology", barcode.symbology)
            .put("is_primary", barcode.primary)
    })
    .put("compatibilities", value.compatibilities.jsonArray(::compatibilityJson))

private fun movementJson(value: Movement) = JSONObject()
    .put("id", value.id)
    .put("kind", value.kind)
    .put("quantity", value.quantity)
    .put("stock_after", value.stockAfter)
    .put("part_name", value.partName)
    .put("article_number", value.articleNumber)
    .put("timestamp", value.timestamp)

private fun workOrderJson(value: WorkOrder) = JSONObject()
    .put("id", value.id)
    .put("order_number", value.orderNumber)
    .put("customer_name", value.customerName)
    .put("short_text", value.shortText)
    .put("status", value.status)
    .put("equipment_type_id", value.equipment?.id ?: JSONObject.NULL)
    .put("equipment_type", value.equipment?.let(::equipmentJson) ?: JSONObject.NULL)

private fun documentJson(value: TechnicalDocument) = JSONObject()
    .put("id", value.id)
    .put("title", value.title)
    .put("kind", value.kind)
    .put("source_url", value.sourceUrl)
    .put("download_url", value.downloadUrl)
    .put("equipment_type", value.equipment?.let(::equipmentJson) ?: JSONObject.NULL)

private fun dashboardJson(value: Dashboard) = JSONObject()
    .put("part_count", value.partCount)
    .put("stock_total", value.stockTotal)
    .put("low_stock_count", value.lowStockCount)
    .put("open_order_count", value.openOrderCount)
    .put("movement_count_today", value.movementsToday)
    .put("recent_movements", value.recentMovements.jsonArray(::movementJson))
    .put("low_stock_parts", value.lowStockParts.jsonArray(::partJson))

private fun <T> List<T>.jsonArray(mapper: (T) -> JSONObject): JSONArray = JSONArray().also { array ->
    forEach { array.put(mapper(it)) }
}
