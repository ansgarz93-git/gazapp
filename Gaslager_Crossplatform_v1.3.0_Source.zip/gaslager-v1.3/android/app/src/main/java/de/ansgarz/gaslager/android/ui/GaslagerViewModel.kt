package de.ansgarz.gaslager.android.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import de.ansgarz.gaslager.android.data.ApiClient
import de.ansgarz.gaslager.android.data.ApiException
import de.ansgarz.gaslager.android.data.Dashboard
import de.ansgarz.gaslager.android.data.Drawer
import de.ansgarz.gaslager.android.data.Equipment
import de.ansgarz.gaslager.android.data.Movement
import de.ansgarz.gaslager.android.data.OfflineSnapshot
import de.ansgarz.gaslager.android.data.OfflineStore
import de.ansgarz.gaslager.android.data.Part
import de.ansgarz.gaslager.android.data.PendingBooking
import de.ansgarz.gaslager.android.data.SessionStore
import de.ansgarz.gaslager.android.data.TechnicalDocument
import de.ansgarz.gaslager.android.data.WorkOrder
import de.ansgarz.gaslager.android.server.EmbeddedServerController
import de.ansgarz.gaslager.android.server.EmbeddedServerRuntime
import de.ansgarz.gaslager.android.server.EmbeddedServerSettings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.net.URI
import java.util.Calendar

data class GaslagerState(
    val checkingSession: Boolean = true,
    val loggedIn: Boolean = false,
    val busy: Boolean = false,
    val serverUrl: String = "",
    val localServerRunning: Boolean = false,
    val localServerEnabled: Boolean = false,
    val localServerUrls: List<String> = emptyList(),
    val localServerPort: Int = 8080,
    val localServerUsername: String = "admin",
    val localServerPassword: String = "",
    val localServerError: String = "",
    val localServerModeActive: Boolean = false,
    val error: String = "",
    val message: String = "",
    val isOffline: Boolean = false,
    val pendingSyncCount: Int = 0,
    val lastSyncedAt: Long? = null,
    val dashboard: Dashboard? = null,
    val parts: List<Part> = emptyList(),
    val allParts: List<Part> = emptyList(),
    val equipment: List<Equipment> = emptyList(),
    val drawers: List<Drawer> = emptyList(),
    val workOrders: List<WorkOrder> = emptyList(),
    val documents: List<TechnicalDocument> = emptyList(),
    val scannedBarcode: String = "",
    val scannedSymbology: String = "",
    val scannedPart: Part? = null,
    val unknownBarcode: Boolean = false,
)

class GaslagerViewModel(application: Application) : AndroidViewModel(application) {
    private val session = SessionStore(application)
    private val api = ApiClient(session)
    private val offlineStore = OfflineStore(application)
    private val embeddedSettings = EmbeddedServerSettings(application)
    private var baseSnapshot: OfflineSnapshot? = offlineStore.loadSnapshot()
    private var partQuery = ""
    private val _state = MutableStateFlow(
        GaslagerState(
            serverUrl = session.serverUrl,
            localServerEnabled = embeddedSettings.enabled,
            localServerUrls = embeddedSettings.localUrls(),
            localServerPort = embeddedSettings.port,
            localServerUsername = embeddedSettings.username,
            localServerPassword = embeddedSettings.password,
            localServerModeActive = isEmbeddedServerUrl(session.serverUrl),
        )
    )
    val state: StateFlow<GaslagerState> = _state.asStateFlow()

    init {
        if (embeddedSettings.enabled) EmbeddedServerController.start(application)
        viewModelScope.launch {
            EmbeddedServerRuntime.status.collect { status ->
                _state.update {
                    it.copy(
                        localServerRunning = status.running,
                        localServerEnabled = embeddedSettings.enabled,
                        localServerUrls = status.urls.ifEmpty { embeddedSettings.localUrls() },
                        localServerPort = status.port,
                        localServerUsername = embeddedSettings.username,
                        localServerPassword = embeddedSettings.password,
                        localServerError = status.error,
                        localServerModeActive = isEmbeddedServerUrl(session.serverUrl),
                    )
                }
            }
        }
        val hasSession = session.serverUrl.isNotBlank() && session.accessToken.isNotBlank()
        val local = baseSnapshot
        if (hasSession && local != null) {
            publishSnapshot(
                snapshot = local,
                pending = offlineStore.pendingBookings(),
                offlineMode = true,
                checkingSession = false,
                loggedIn = true,
            )
        } else if (!hasSession) {
            _state.update { it.copy(checkingSession = false) }
        }

        if (hasSession) {
            viewModelScope.launch {
                if (isEmbeddedServerUrl(session.serverUrl)) awaitEmbeddedServer()
                synchronizeNow(showSuccess = false)
            }
        }
    }

    fun login(serverUrl: String, username: String, password: String) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true, error = "", serverUrl = serverUrl.trimEnd('/')) }
            try {
                api.login(serverUrl, username, password)
                _state.update {
                    it.copy(
                        loggedIn = true,
                        checkingSession = false,
                        busy = false,
                        serverUrl = session.serverUrl,
                        localServerModeActive = isEmbeddedServerUrl(session.serverUrl),
                    )
                }
                synchronizeNow(showSuccess = false)
            } catch (error: Exception) {
                _state.update { it.copy(busy = false, checkingSession = false, error = readable(error)) }
            }
        }
    }

    fun logout() {
        session.clearToken()
        partQuery = ""
        _state.value = localServerState(checkingSession = false)
    }

    fun startLocalServer() {
        if (_state.value.busy) return
        EmbeddedServerController.start(getApplication())
        viewModelScope.launch {
            _state.update { it.copy(busy = true, checkingSession = false, error = "", message = "Android-Server wird gestartet …") }
            var lastError: Exception? = null
            repeat(50) {
                if (EmbeddedServerRuntime.status.value.running) {
                    try {
                        api.login(
                            "http://127.0.0.1:${embeddedSettings.port}",
                            embeddedSettings.username,
                            embeddedSettings.password,
                        )
                        _state.update {
                            it.copy(
                                loggedIn = true,
                                busy = false,
                                serverUrl = session.serverUrl,
                                localServerModeActive = true,
                                localServerEnabled = true,
                                message = "Android-Server läuft auch ohne Internetverbindung.",
                            )
                        }
                        synchronizeNow(showSuccess = false)
                        return@launch
                    } catch (error: Exception) {
                        lastError = error
                    }
                }
                delay(100)
            }
            _state.update {
                it.copy(
                    busy = false,
                    loggedIn = false,
                    error = lastError?.let(::readable) ?: EmbeddedServerRuntime.status.value.error.ifBlank {
                        "Android-Server konnte nicht gestartet werden."
                    },
                )
            }
        }
    }

    fun stopLocalServer() {
        val wasActive = isEmbeddedServerUrl(session.serverUrl)
        EmbeddedServerController.stop(getApplication())
        if (wasActive) logout() else _state.update { it.copy(localServerEnabled = false, localServerRunning = false) }
    }

    fun openHotspotSettings() = EmbeddedServerController.openHotspotSettings(getApplication())

    fun refreshLocalServerStatus() {
        _state.update {
            it.copy(
                localServerUrls = embeddedSettings.localUrls(),
                localServerRunning = EmbeddedServerRuntime.status.value.running,
                localServerError = EmbeddedServerRuntime.status.value.error,
            )
        }
    }

    fun regenerateLocalServerPassword() {
        val password = embeddedSettings.regeneratePassword()
        _state.update { it.copy(localServerPassword = password, message = "Neuer Zugangscode wurde erstellt.") }
        if (isEmbeddedServerUrl(session.serverUrl)) {
            session.clearToken()
            startLocalServer()
        }
    }

    fun refreshAll() = synchronize()

    fun synchronize() {
        if (_state.value.busy) return
        viewModelScope.launch { synchronizeNow(showSuccess = true) }
    }

    private suspend fun synchronizeNow(showSuccess: Boolean) {
        _state.update { it.copy(busy = true, error = "") }
        try {
            api.checkSession()
            var currentBase = baseSnapshot
            val queuedAtStart = offlineStore.pendingBookings()

            for (booking in queuedAtStart.sortedBy(PendingBooking::createdAt)) {
                try {
                    val result = api.book(
                        partId = booking.partId,
                        barcode = booking.barcode,
                        kind = booking.kind,
                        quantity = booking.quantity,
                        reference = booking.reference,
                        notes = booking.notes,
                        workOrderId = booking.workOrderId,
                        idempotencyKey = booking.id,
                    )
                    currentBase = currentBase?.let { applyConfirmedBooking(it, booking, result.stockAfter) }
                    currentBase?.let(offlineStore::saveSnapshot)
                    baseSnapshot = currentBase
                    offlineStore.removePending(booking.id)
                } catch (error: ApiException) {
                    if (error.statusCode == 401) throw error
                    val fresh = runCatching { fetchSnapshot() }.getOrNull()
                    if (fresh != null) {
                        baseSnapshot = fresh
                        offlineStore.saveSnapshot(fresh)
                    }
                    val available = fresh ?: currentBase
                    if (available != null) {
                        publishSnapshot(
                            snapshot = available,
                            pending = offlineStore.pendingBookings(),
                            offlineMode = false,
                            checkingSession = false,
                            loggedIn = true,
                            error = "Buchung ${booking.kind} konnte nicht synchronisiert werden: ${readable(error)}",
                        )
                    } else {
                        _state.update { it.copy(busy = false, checkingSession = false, error = readable(error)) }
                    }
                    return
                }
            }

            val snapshot = fetchSnapshot()
            baseSnapshot = snapshot
            offlineStore.saveSnapshot(snapshot)
            val uploaded = queuedAtStart.size
            publishSnapshot(
                snapshot = snapshot,
                pending = offlineStore.pendingBookings(),
                offlineMode = false,
                checkingSession = false,
                loggedIn = true,
                message = when {
                    uploaded > 0 -> "$uploaded Offline-Buchung${if (uploaded == 1) "" else "en"} synchronisiert."
                    showSuccess -> "Daten sind synchronisiert."
                    else -> ""
                },
            )
        } catch (error: ApiException) {
            if (error.statusCode == 401) {
                session.clearToken()
                _state.update {
                    it.copy(
                        busy = false,
                        checkingSession = false,
                        loggedIn = false,
                        error = "Sitzung ist abgelaufen. Bitte erneut anmelden.",
                    )
                }
            } else {
                enterOffline(error)
            }
        } catch (error: Exception) {
            enterOffline(error)
        }
    }

    private suspend fun fetchSnapshot(): OfflineSnapshot {
        val dashboard = api.dashboard()
        val parts = api.parts()
        val equipment = api.equipment()
        val drawers = api.drawers()
        val workOrders = api.workOrders()
        val documents = api.documents()
        return OfflineSnapshot(
            savedAt = System.currentTimeMillis(),
            dashboard = dashboard,
            parts = parts,
            equipment = equipment,
            drawers = drawers,
            workOrders = workOrders,
            documents = documents,
        )
    }

    fun searchParts(query: String) {
        partQuery = query.trim()
        _state.update { current -> current.copy(parts = filterParts(current.allParts, partQuery), error = "") }
    }

    fun resolveBarcode(value: String, symbology: String = "") {
        if (value.isBlank()) return
        viewModelScope.launch {
            _state.update {
                it.copy(
                    busy = true,
                    scannedBarcode = value,
                    scannedSymbology = symbology,
                    scannedPart = null,
                    unknownBarcode = false,
                    error = "",
                )
            }

            val localPart = _state.value.allParts.firstOrNull { part ->
                part.barcodes.any { localBarcodeKey(it.value) == localBarcodeKey(value) }
            }
            if (localPart != null) {
                _state.update {
                    it.copy(
                        busy = false,
                        scannedPart = localPart,
                        message = if (it.isOffline) "${localPart.partName} im Offline-Bestand erkannt." else "${localPart.partName} erkannt.",
                    )
                }
                return@launch
            }
            if (_state.value.isOffline) {
                _state.update {
                    it.copy(
                        busy = false,
                        error = "Barcode ist im lokalen Offline-Bestand nicht vorhanden. Bitte synchronisieren.",
                    )
                }
                return@launch
            }

            try {
                val part = api.resolveBarcode(value)
                _state.update { it.copy(busy = false, scannedPart = part, message = "${part.partName} erkannt.") }
            } catch (error: ApiException) {
                if (error.statusCode == 404) {
                    _state.update { it.copy(busy = false, unknownBarcode = true, message = "Barcode ist noch nicht angelegt.") }
                } else if (error.statusCode == 401) {
                    handleError(error)
                } else {
                    _state.update { it.copy(busy = false, error = readable(error)) }
                }
            } catch (error: Exception) {
                enterOffline(error)
                _state.update {
                    it.copy(
                        scannedBarcode = value,
                        scannedSymbology = symbology,
                        scannedPart = null,
                        unknownBarcode = false,
                        error = "Server nicht erreichbar. Der Barcode ist im Offline-Bestand nicht vorhanden.",
                    )
                }
            }
        }
    }

    fun clearScan() {
        _state.update {
            it.copy(
                scannedBarcode = "",
                scannedSymbology = "",
                scannedPart = null,
                unknownBarcode = false,
                message = "",
                error = "",
            )
        }
    }

    fun book(kind: String, quantity: Int, reference: String, notes: String, workOrderId: String?) {
        val part = state.value.scannedPart ?: return
        if (quantity <= 0 || (kind == "Ausgang" && part.stockQuantity < quantity)) return
        val snapshot = baseSnapshot
        if (snapshot == null) {
            _state.update { it.copy(error = "Noch kein lokaler Datenbestand verfügbar. Bitte zuerst synchronisieren.") }
            return
        }

        val booking = PendingBooking(
            partId = part.id,
            barcode = state.value.scannedBarcode,
            kind = kind,
            quantity = quantity,
            reference = reference,
            notes = notes,
            workOrderId = workOrderId,
        )
        offlineStore.enqueue(booking)
        val pending = offlineStore.pendingBookings()
        publishSnapshot(
            snapshot = snapshot,
            pending = pending,
            offlineMode = state.value.isOffline,
            checkingSession = false,
            loggedIn = true,
            message = if (state.value.isOffline) {
                "$kind offline vorgemerkt. Mit Synchronisieren übertragen."
            } else {
                "$kind lokal vorgemerkt. Übertragung läuft."
            },
        )

        val updated = _state.value.allParts.firstOrNull { it.id == part.id }
        if (updated != null && updated.reminderEnabled && updated.isLowStock) {
            LowStockNotifier.notify(getApplication(), updated)
        }
        if (!_state.value.isOffline) {
            viewModelScope.launch { synchronizeNow(showSuccess = false) }
        }
    }

    fun registerPart(
        manufacturer: String,
        articleNumber: String,
        partName: String,
        drawerId: String?,
        equipmentTypeId: String?,
        deviceSparePartNumber: String,
        initialStock: Int,
        minimumStock: Int,
        reminderEnabled: Boolean,
    ) {
        if (_state.value.isOffline) {
            _state.update { it.copy(error = "Neue Ersatzteile können nur online angelegt werden. Bitte synchronisieren.") }
            return
        }
        val barcode = state.value.scannedBarcode
        viewModelScope.launch {
            _state.update { it.copy(busy = true, error = "") }
            try {
                val part = api.createPart(
                    manufacturer,
                    articleNumber,
                    partName,
                    barcode,
                    state.value.scannedSymbology,
                    drawerId,
                    equipmentTypeId,
                    deviceSparePartNumber,
                    initialStock,
                    minimumStock,
                    reminderEnabled,
                )
                _state.update { it.copy(busy = false, scannedPart = part, unknownBarcode = false, message = "Ersatzteil wurde angelegt.") }
                synchronizeNow(showSuccess = false)
            } catch (error: ApiException) {
                handleError(error)
            } catch (error: Exception) {
                enterOffline(error)
            }
        }
    }

    fun linkBarcode(partId: String) {
        if (_state.value.isOffline) {
            _state.update { it.copy(error = "Barcodes können nur online zugeordnet werden. Bitte synchronisieren.") }
            return
        }
        val barcode = state.value.scannedBarcode
        if (barcode.isBlank()) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, error = "") }
            try {
                api.addBarcode(partId, barcode, state.value.scannedSymbology)
                val part = api.part(partId)
                _state.update {
                    it.copy(
                        busy = false,
                        scannedPart = part,
                        unknownBarcode = false,
                        message = "Barcode wurde ${part.partName} zugeordnet.",
                    )
                }
                synchronizeNow(showSuccess = false)
            } catch (error: ApiException) {
                handleError(error)
            } catch (error: Exception) {
                enterOffline(error)
            }
        }
    }

    fun clearNotice() {
        _state.update { it.copy(error = "", message = "") }
    }

    fun openDocument(document: TechnicalDocument) {
        if (document.downloadUrl.isBlank() && document.sourceUrl.isBlank()) {
            _state.update { it.copy(error = "Für dieses Dokument ist noch keine Datei oder Herstellerseite hinterlegt.") }
            return
        }
        viewModelScope.launch {
            try {
                val app = getApplication<Application>()
                val file = offlineStore.documentFile(document)
                val intent = when {
                    file.isFile -> {
                        val uri = FileProvider.getUriForFile(app, "${app.packageName}.files", file)
                        Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    document.downloadUrl.isNotBlank() && !_state.value.isOffline -> {
                        _state.update { it.copy(busy = true, error = "") }
                        file.writeBytes(api.download(document.downloadUrl))
                        val uri = FileProvider.getUriForFile(app, "${app.packageName}.files", file)
                        Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    _state.value.isOffline -> {
                        _state.update { it.copy(error = "Diese Unterlage wurde noch nicht offline gespeichert. Einmal online öffnen oder synchronisieren.") }
                        return@launch
                    }
                    else -> Intent(Intent.ACTION_VIEW, Uri.parse(document.sourceUrl))
                }
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                app.startActivity(intent)
                _state.update { it.copy(busy = false) }
            } catch (error: ApiException) {
                handleError(error)
            } catch (error: Exception) {
                _state.update { it.copy(busy = false, error = readable(error)) }
            }
        }
    }

    private fun publishSnapshot(
        snapshot: OfflineSnapshot,
        pending: List<PendingBooking>,
        offlineMode: Boolean,
        checkingSession: Boolean,
        loggedIn: Boolean,
        error: String = "",
        message: String = "",
    ) {
        baseSnapshot = snapshot
        val projected = projectSnapshot(snapshot, pending)
        _state.update { current ->
            current.copy(
                checkingSession = checkingSession,
                loggedIn = loggedIn,
                busy = false,
                serverUrl = session.serverUrl,
                localServerModeActive = isEmbeddedServerUrl(session.serverUrl),
                error = error,
                message = message,
                isOffline = offlineMode,
                pendingSyncCount = pending.size,
                lastSyncedAt = snapshot.savedAt.takeIf { it > 0 },
                dashboard = projected.dashboard,
                parts = filterParts(projected.parts, partQuery),
                allParts = projected.parts,
                equipment = projected.equipment,
                drawers = projected.drawers,
                workOrders = projected.workOrders,
                documents = projected.documents,
                scannedPart = current.scannedPart?.let { selected -> projected.parts.firstOrNull { it.id == selected.id } },
            )
        }
    }

    private fun enterOffline(error: Exception) {
        val snapshot = baseSnapshot ?: offlineStore.loadSnapshot()
        if (snapshot != null && session.accessToken.isNotBlank()) {
            publishSnapshot(
                snapshot = snapshot,
                pending = offlineStore.pendingBookings(),
                offlineMode = true,
                checkingSession = false,
                loggedIn = true,
                error = "Offline-Modus aktiv. ${readable(error)}",
            )
        } else {
            _state.update {
                it.copy(
                    busy = false,
                    checkingSession = false,
                    loggedIn = false,
                    isOffline = true,
                    error = "Server nicht erreichbar und noch kein Offline-Bestand vorhanden.",
                )
            }
        }
    }

    private fun handleError(error: Exception) {
        if (error is ApiException && error.statusCode == 401) {
            session.clearToken()
            _state.update { it.copy(busy = false, loggedIn = false, error = "Sitzung ist abgelaufen. Bitte erneut anmelden.") }
        } else {
            _state.update { it.copy(busy = false, error = readable(error)) }
        }
    }

    private fun readable(error: Exception): String =
        error.message?.takeIf { it.isNotBlank() } ?: "Der Server ist nicht erreichbar. Netzwerk und Adresse prüfen."

    private suspend fun awaitEmbeddedServer() {
        repeat(50) {
            if (EmbeddedServerRuntime.status.value.running) return
            delay(100)
        }
    }

    private fun localServerState(checkingSession: Boolean): GaslagerState = GaslagerState(
        checkingSession = checkingSession,
        serverUrl = session.serverUrl,
        localServerRunning = EmbeddedServerRuntime.status.value.running,
        localServerEnabled = embeddedSettings.enabled,
        localServerUrls = embeddedSettings.localUrls(),
        localServerPort = embeddedSettings.port,
        localServerUsername = embeddedSettings.username,
        localServerPassword = embeddedSettings.password,
        localServerError = EmbeddedServerRuntime.status.value.error,
        localServerModeActive = isEmbeddedServerUrl(session.serverUrl),
    )
}

private fun isEmbeddedServerUrl(value: String): Boolean = runCatching {
    URI.create(value).host in setOf("127.0.0.1", "localhost", "::1")
}.getOrDefault(false)

internal fun projectSnapshot(snapshot: OfflineSnapshot, pending: List<PendingBooking>): OfflineSnapshot {
    var parts = snapshot.parts
    val localMovements = mutableListOf<Movement>()
    for (booking in pending.sortedBy(PendingBooking::createdAt)) {
        val part = parts.firstOrNull { it.id == booking.partId } ?: continue
        val nextStock = if (booking.kind == "Eingang") {
            part.stockQuantity + booking.quantity
        } else {
            (part.stockQuantity - booking.quantity).coerceAtLeast(0)
        }
        val updated = part.copy(
            stockQuantity = nextStock,
            isLowStock = nextStock <= part.minimumStock,
        )
        parts = parts.map { if (it.id == updated.id) updated else it }
        localMovements += Movement(
            id = "offline-${booking.id}",
            kind = booking.kind,
            quantity = booking.quantity,
            stockAfter = nextStock,
            partName = part.partName,
            articleNumber = part.originalArticleNumber,
            timestamp = booking.createdAt.toString(),
        )
    }
    return snapshot.copy(
        dashboard = rebuildDashboard(snapshot.dashboard, parts, localMovements, pending.count { it.createdAt >= startOfToday() }),
        parts = parts,
    )
}

private fun applyConfirmedBooking(snapshot: OfflineSnapshot, booking: PendingBooking, stockAfter: Int): OfflineSnapshot {
    val original = snapshot.parts.firstOrNull { it.id == booking.partId } ?: return snapshot
    val updated = original.copy(stockQuantity = stockAfter, isLowStock = stockAfter <= original.minimumStock)
    val parts = snapshot.parts.map { if (it.id == updated.id) updated else it }
    val movement = Movement(
        id = "confirmed-${booking.id}",
        kind = booking.kind,
        quantity = booking.quantity,
        stockAfter = stockAfter,
        partName = original.partName,
        articleNumber = original.originalArticleNumber,
        timestamp = booking.createdAt.toString(),
    )
    return snapshot.copy(
        savedAt = System.currentTimeMillis(),
        dashboard = rebuildDashboard(snapshot.dashboard, parts, listOf(movement), 1),
        parts = parts,
    )
}

private fun rebuildDashboard(
    base: Dashboard,
    parts: List<Part>,
    additionalMovements: List<Movement>,
    additionalToday: Int,
): Dashboard {
    val lowStock = parts.filter { it.reminderEnabled && it.isLowStock }
    return base.copy(
        partCount = parts.size,
        stockTotal = parts.sumOf(Part::stockQuantity),
        lowStockCount = lowStock.size,
        movementsToday = base.movementsToday + additionalToday,
        recentMovements = (additionalMovements.asReversed() + base.recentMovements).take(20),
        lowStockParts = lowStock,
    )
}

internal fun filterParts(parts: List<Part>, query: String): List<Part> {
    if (query.isBlank()) return parts
    val needle = query.lowercase()
    return parts.filter { part ->
        listOf(part.manufacturer, part.originalArticleNumber, part.partName, part.notes, part.drawer?.code.orEmpty())
            .any { needle in it.lowercase() } ||
            part.barcodes.any { needle in it.value.lowercase() } ||
            part.compatibilities.any {
                needle in it.deviceSparePartNumber.lowercase() ||
                    needle in it.equipment?.designation.orEmpty().lowercase()
            }
    }
}

internal fun localBarcodeKey(value: String): String {
    val cleaned = value.trim().replace("\u200B", "")
    return if (cleaned.length > 3 && cleaned[0] == ']' && cleaned[2].isDigit()) cleaned.substring(3) else cleaned
}

private fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis
