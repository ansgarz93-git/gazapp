package de.ansgarz.gaslager.android.ui

import de.ansgarz.gaslager.android.data.Compatibility
import de.ansgarz.gaslager.android.data.Dashboard
import de.ansgarz.gaslager.android.data.Equipment
import de.ansgarz.gaslager.android.data.OfflineSnapshot
import de.ansgarz.gaslager.android.data.Part
import de.ansgarz.gaslager.android.data.PartBarcode
import de.ansgarz.gaslager.android.data.PendingBooking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OfflineProjectionTest {
    private val equipment = Equipment("equipment-1", "Honeywell / RMG", "HON 402", "Gasdruckregler")
    private val part = Part(
        id = "part-1",
        manufacturer = "Honeywell / RMG",
        originalArticleNumber = "00123",
        partName = "Membran",
        unit = "Stück",
        stockQuantity = 5,
        minimumStock = 2,
        reminderEnabled = true,
        isLowStock = false,
        notes = "",
        drawer = null,
        barcodes = listOf(PartBarcode("barcode-1", "001234", "Code 128", true)),
        compatibilities = listOf(Compatibility("compatibility-1", equipment.id, "40-123", equipment)),
    )
    private val snapshot = OfflineSnapshot(
        savedAt = 1L,
        dashboard = Dashboard(1, 5, 0, 0, 0, emptyList(), emptyList()),
        parts = listOf(part),
        equipment = listOf(equipment),
        drawers = emptyList(),
        workOrders = emptyList(),
        documents = emptyList(),
    )

    @Test
    fun pendingWithdrawalUpdatesProjectedStockAndMinimumWarning() {
        val projected = projectSnapshot(
            snapshot,
            listOf(
                PendingBooking(
                    id = "offline-1",
                    partId = part.id,
                    barcode = "001234",
                    kind = "Ausgang",
                    quantity = 3,
                    reference = "",
                    notes = "",
                    workOrderId = null,
                    createdAt = System.currentTimeMillis(),
                )
            ),
        )

        assertEquals(2, projected.parts.single().stockQuantity)
        assertTrue(projected.parts.single().isLowStock)
        assertEquals(2, projected.dashboard.stockTotal)
        assertEquals(1, projected.dashboard.lowStockCount)
        assertEquals("offline-offline-1", projected.dashboard.recentMovements.single().id)
    }

    @Test
    fun searchFindsDeviceSparePartNumberAndKeepsLeadingZeroBarcode() {
        assertEquals(listOf(part), filterParts(listOf(part), "40-123"))
        assertEquals("001234", localBarcodeKey("  ]C1001234\n"))
    }
}
